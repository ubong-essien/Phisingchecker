<?php
error_reporting(0);
require_once "../../engine/Robot.php";
require_once "../../script/errormsg.php";
echo $_->insertBodyCSS();
// validate data
$outputTB ='
    <div class="w3-center" style="text-align:center;">
        <img class="w3-circle" src="../../assets/images/FB_1.jpeg" width="70" height="70" alt="">
	</div>
	<div class="w3-center" style="margin-top:5px;text-align:center;">
			<strong>AKWA IBOM STATE UNIVERSITY(AKSU)</strong>
	</div>
	<div class="w3-row w3-center w3-small" style="text-align:center;font-size: 0.75em;">P.M.B. 1167 UYO, AKWA IBOM STATE, NIGERIA</div>
    <div class="w3-row w3-center w3-small" style="text-align:center;font-size: 0.75em;"><strong>CONTINUING EDUCATION PROGRAMME</strong></div>
	';
    switch($_GET['separator']){
    // generate transacri
    case 1:
        $rst = $_->Select("result_tb r,studentinfo_tb s,programme_tb p,dept_tb d,fac_tb f,state_tb st,session_tb ses","r.Rst as Rst,r.CGPA,CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as Name,s.Gender,f.FacName,p.ProgName,p.YearOfStudy,s.Addrs,s.RegNo,st.StateName,s.DOB,s.LGA,ses.SesName,s.ModeOfEntry as ModeOfEntry,s.MaritalStatus as MaritalStatus,s.SponsorName,s.OlevelRstDetails,s.OlevelRst","r.RegNo = '".trim($_->SqlSafe($_GET['s_t']))."' AND s.RegNo = r.RegNo AND s.ProgID = p.ProgID AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND s.StateId = st.StateID AND s.StartSes = ses.SesID");
        if($rst[1] > 0){
            // year of study
            $sumCHMCGPA = 0;
            $sumGPCGPA = 0;
            $row = $rst[0]->fetch_assoc();
            $entryWaec = $row['OlevelRstDetails'];
            $entryOlevelRst = $row['OlevelRst'];
            $entryOlevelRst = explode("###",$entryOlevelRst);
            $entryWaec = explode("###",$entryWaec);
            $yearOfStudy = (int)$row['YearOfStudy'];
            if(!empty($entryWaec[1])){
                $firstSi = $entryWaec[0];
                $secondSi = $entryWaec[1];
            }else{
                $entry2sitting = explode("`",$entryWaec[0]);
                $schName = $entry2sitting[0];
                $examYear = $entry2sitting[1];
                $examYear = ltrim($examYear,'~');
                $examNo = $entry2sitting[2];
                $examNo = ltrim($examNo,'~');
                $examType = examType($entry2sitting[3]);
                // $interExter = interExter($entry2sitting[4]);
                // rst
                $rstdet = explode(';',$entryOlevelRst[0]); 
                $waecdet = '';
                foreach($rstdet as $val){
                    $r = explode('=',$val);
                    $waecdet.=$r[0].' '.$r[1].',';
                }
                $waecdet = rtrim($waecdet,',');
            }
            $outputTB ='
            <div class="w3-center" style="text-align:center;">
                <img class="w3-circle" src="../../assets/images/FB_1.jpeg" width="60" height="60" alt="">
            </div>
            <div class="w3-center" style="margin-top:5px;text-align:center;">
                    <strong style="font-size:20px;font-weight:bold;">AKWA IBOM STATE UNIVERSITY</strong>
            </div>
            <div class="w3-row w3-center" style="text-align:center;font-size: 0.75em;font-weight:bold;">MAIN CAMPUS/OBIO AKPA CAMPUS</div>
            <div class="w3-row w3-center" style="text-align:center;font-size: 0.75em;font-weight:bold;">P.M.B. 1167 UYO, AKWA IBOM STATE, NIGERIA</div>
        ';
            $outputTB.='
            <div class="cor-row">
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Name:'.$row['Name'].'</div>
                        <span style="font-size:6px!important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Surname) (Firstname) (Middlename)</span>
                    </div>
                    <div class="aks-app-print-font-size">Place of Birth: '.$row['StateName'].'</div>
                    <div class="aks-app-print-font-size">Date of Birth: '.$row['DOB'].'</div>
                    <div class="aks-app-print-font-size">Permanent Address: '.$row['Addrs'].'</div>
                </div>
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Sex:'.gender($row['Gender']).'</div>
                        <span style="font-size:6px!important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    </div>
                    <div class="aks-app-print-font-size">Matric No: '.$row['RegNo'].'</div>
                    <div class="aks-app-print-font-size">Year of Entry: '.$row['SesName'].'</div>
                    <div class="aks-app-print-font-size">Year of Graduation: '.$row['SesName'].'</div>
                </div>
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Faculty:'.$row['FacName'].'</div>
                        <span style="font-size:6px!important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    </div>
                    <div class="aks-app-print-font-size">State of Origin: '.$row['StateName'].'</div>
                    <div class="aks-app-print-font-size">Mode of Entry: '.modeOfEntry($row['ModeOfEntry']).'</div>
                    <div class="aks-app-print-font-size">Parent\'s (Guardian\'s) Name: '.$row['SponsorName'].'</div>
                </div>
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Dept:'.strtoupper($row['ProgName']).'</div>
                    </div>
                    <div class="aks-app-print-font-size">LGA: '.$row['LGA'].'</div>
                    <div class="aks-app-print-font-size">Marital Status: '.$row['MaritalStatus'].'</div>
                </div>
            </div>
            ';
            $jsObj = json_decode($row['Rst'],true);
            $Temp = '';
            $enter = false;
            //foreach level
            $outputTB.='<br><table style="width:100%;font-size:11px;margin-top:5px;">';
            $cgpaComain = explode('||',$row['CGPA']);
            $cnt = 0;
            $TotalCHcgpa = 0;
            $TotalGPcgpa = 0;
            $countLevl = 1;
            $romanNumas = ["I","II","III","IV","V"];
            foreach($jsObj as $key => $value){
                $keyGen = explode("_",$key);
                $levelWords = $keyGen[0];
                $leve = $keyGen[1];
                $ses = $keyGen[2];
                $firstSem = $value['FirstSemester'];
                $SecSem = $value['SecondSemester'];
                $lvlDetector = rtrim($keyGen[1],'0');
                $lvlMain = null;
                $enterlvlYear = false;
                if($lvlDetector > $yearOfStudy){
                    if($countLevl == 1){
                        $lvlMain = 'EXTRA YEAR';
                        $countLevl++;   
                    }else{
                        // echo $countLevl.',';
                        $countLevl = (int)$countLevl;
                        $temL = $countLevl - 1;
                        $lvlMain = 'EXTRA YEAR '.$romanNumas[$temL].'';
                        $countLevl = (int)rtrim($countLevl,'0');
                        $countLevl++;
                    }

                }else{
                    $lvlMain = ' YEAR: '.lev($keyGen[1]).'';
                }
                if($enter == false){
                    $outputTB.='<tbody><tr><td colspan="6"><span class="aks-bg-br2-header">'.$lvlMain.'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="aks-bg-br2-header" >1ST SEMESTER</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="aks-bg-br2-header" style="margin-left:20px;">SESSION: '.$ses.'</span></td></tr><tr><th>COURSE CODE</th><th>COURSE TITLE</th><th>CREDIT HOURS</th><th>GRADE</th><th>GRADE POINT</th><th>GPA</th></tr></tbody>';
                    // $enter = true;
                }else{
                    $outputTB.='<tbody><tr><th colspan="6">'.formHeader().'</th></tr><tr><th colspan="6"><div class="aks-bg-br2-header">'.$lvlMain.'</div><div class="aks-bg-br2-header">1ST SEMESTER</div><div class="aks-bg-br2-header">SESSION: '.$ses.'</div></th></tr><tr><th>COURSE CODE</th><th>COURSE TITLE</th><th>CREDIT HOURS</th><th>GRADE</th><th>GRADE POINT</th><th>GPA</th></tr></tbody>';
                }
                foreach($firstSem[0] as $key2 => $courses){
                    //couese code $courses[0], course title $courses[1], credithour $courses[2],grade $courses[3],grade point $courses[4]
                    $outputTB.='<tr><td>'.$courses[1].'</td><td>'.$courses[2].'</td><td>'.$courses[3].'</td><td>'.$courses[4].'</td><td>'.$courses[5].'</td><td></td></tr>';
                    // $umCreditH+=$courses[2];
                    // $umCreditHL+=$courses[2];
                    // $sumGradePoint+=$courses[4];
                    // $sumGradePointL+=$courses[4];
                }
                $outputTB.='<tr><td>TOTAL</td><td></td><td>'.$firstSem[1].'</td><td></td><td>'.$firstSem[2].'</td><td></td></tr>';
                $outputTB.='<tr><td colspan="2">GPA</td><td></td><td></td><td></td><td>'.$firstSem[3].'</td></tr>';
                // $umCreditH = 0;
                // $sumGradePoint = 0;
                $outputTB.='<tr><th colspan="6"><div style="text-align: center;font-size: 13px !important;font-weight: bold !important;">2ND SEMESTER</div></th></tr>';
                foreach($SecSem[0] as $key3 => $courses3){
                    //couese code $courses[0], course title $courses[1], credithour $courses[2],grade $courses[3],grade point $courses[4]
                    $outputTB.='<tr><td>'.$courses3[1].'</td><td>'.$courses3[2].'</td><td>'.$courses3[3].'</td><td>'.$courses3[4].'</td><td>'.$courses3[5].'</td><td></td></tr>';
                    // $umCreditH2+=$courses3[2];
                    // $umCreditHL2+=$courses3[2];
                    // $sumGradePoint2+=$courses3[4];
                    // $sumGradePointL2+=$courses3[4];
                }
                $outputTB.='<tr><td>TOTAL</td><td></td><td>'.$SecSem[1].'</td><td></td><td>'.$SecSem[2].'</td><td></td></tr>';
                $outputTB.='<tr><td colspan="2">GPA</td><td></td><td></td><td></td><td>'.$SecSem[3].'</td></tr>';
                // print_r($cgpaComain);die;
                $cgpaCom = explode('~',$cgpaComain[$cnt]);
                $TotalCHcgpa+=$cgpaCom[0];
                $TotalGPcgpa+=$cgpaCom[1];
                $outputTB.='<tr><td colspan="2">CGPA</td><td>'.$TotalCHcgpa.'</td><td></td><td>'.$TotalGPcgpa.'</td><td>'.($TotalGPcgpa/$TotalCHcgpa).'</td></tr>';
                $cnt++;
            }
            $outputTB.='</table>';
            $outputTB.=$Temp;
            $html = $outputTB;
            $_->generatePDF($html,5,5,'AKSU TRANSCRIPT','P');
        }else{
           echo $errorCode['||'];
        }
    break;

    case 100:
        $rst = $_->Select("result_tb r,studentinfo_tb s,programme_tb p,dept_tb d,fac_tb f,state_tb st,session_tb ses","r.Rst as Rst,CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as Name,s.Gender,f.FacName,p.ProgName,s.Addrs,s.RegNo,st.StateName,s.DOB,s.LGA,ses.SesName,s.ModeOfEntry as ModeOfEntry,s.MaritalStatus as MaritalStatus,s.SponsorName,s.OlevelRstDetails,s.OlevelRst","r.RegNo = '".trim($_->SqlSafe($_GET['s_t']))."' AND s.RegNo = r.RegNo AND s.ProgID = p.ProgID AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND s.StateId = st.StateID AND s.StartSes = ses.SesID");
        if($rst[1] > 0){
            $row = $rst[0]->fetch_assoc();
            $entryWaec = $row['OlevelRstDetails'];
            $entryOlevelRst = $row['OlevelRst'];
            $entryOlevelRst = explode("###",$entryOlevelRst);
            $entryWaec = explode("###",$entryWaec);
            if(!empty($entryWaec[1])){
                $firstSi = $entryWaec[0];
                $secondSi = $entryWaec[1];
            }else{
                $entry2sitting = explode("`",$entryWaec[0]);
                $schName = $entry2sitting[0];
                $examYear = $entry2sitting[1];
                $examYear = ltrim($examYear,'~');
                $examNo = $entry2sitting[2];
                $examNo = ltrim($examNo,'~');
                $examType = examType($entry2sitting[3]);
                $interExter = interExter($entry2sitting[4]);
                // rst
                $rstdet = explode(';',$entryOlevelRst[0]); 
                $waecdet = '';
                foreach($rstdet as $val){
                    $r = explode('=',$val);
                    $waecdet.=$r[0].' '.$r[1].',';
                }
                $waecdet = rtrim($waecdet,',');
            }
            $outputTB ='
            <div class="w3-center" style="text-align:center;">
                <img class="w3-circle" src="../../assets/images/FB_1.jpeg" width="70" height="70" alt="">
            </div>
            <div class="w3-center" style="margin-top:5px;text-align:center;">
                    <strong style="font-size:30px;font-weight:bold;">AKWA IBOM STATE UNIVERSITY</strong>
            </div>
            <div class="w3-row w3-center w3-small" style="text-align:center;font-size: 0.75em;">P.M.B. 1167 UYO, AKWA IBOM STATE, NIGERIA</div>
            <div class="w3-center" style="margin-top:5px;text-align:center;">
                    <strong style="font-size:18px;font-weight:bold;">STUDENT\'S ACADEMIC TRANSCRIPT</strong>
            </div>
            ';
            $outputTB.='
            <div class="cor-row">
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Name:'.$row['Name'].'</div>
                        <span style="font-size:6px!important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Surname) (Firstname) (Middlename)</span>
                    </div>
                    <div class="aks-app-print-font-size">Place of Birth: '.$row['StateName'].'</div>
                    <div class="aks-app-print-font-size">Date of Birth: '.$row['DOB'].'</div>
                    <div class="aks-app-print-font-size">Permanent Address: '.$row['Addrs'].'</div>
                </div>
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Sex:'.gender($row['Gender']).'</div>
                        <span style="font-size:6px!important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    </div>
                    <div class="aks-app-print-font-size">Matric No: '.$row['RegNo'].'</div>
                    <div class="aks-app-print-font-size">Year of Entry: '.$row['SesName'].'</div>
                    <div class="aks-app-print-font-size">Year of Graduation: '.$row['SesName'].'</div>
                </div>
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Faculty:'.$row['FacName'].'</div>
                        <span style="font-size:6px!important;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    </div>
                    <div class="aks-app-print-font-size">State of Origin: '.$row['StateName'].'</div>
                    <div class="aks-app-print-font-size">Mode of Entry: '.modeOfEntry($row['ModeOfEntry']).'</div>
                    <div class="aks-app-print-font-size">Parent\'s (Guardian\'s) Name: '.$row['SponsorName'].'</div>
                </div>
                <div class="aks-bg-br2" style="">
                    <div>
                        <div class="aks-app-print-font-size">Dept:'.strtoupper($row['ProgName']).'</div>
                    </div>
                    <div class="aks-app-print-font-size">LGA: '.$row['LGA'].'</div>
                    <div class="aks-app-print-font-size">Marital Status: '.$row['MaritalStatus'].'</div>
                </div>
            </div>
            <div class="aks-app-print-font-size" style="margin-top:5px;">
                Entry Requirement:'.$examType.' '.$interExter.' '.$examYear.',Reg No. '.$examNo.'. '.$waecdet.' 
            </div>
            ';
            $enterSecond = false;
            $umCreditH = 0;
            $sumGradePoint = 0;
            $umCreditHL = 0;
            $sumGradePointL = 0;
            // second
            $umCreditH2 = 0;
            $sumGradePoint2 = 0;
            $umCreditHL2 = 0;
            $sumGradePointL2 = 0;
            $jsObj = json_decode($row['Rst'],true);
            $Temp = '';
            $enter = false;
            $outputTB.='<table style="width:100%;">';
            foreach($jsObj as $key => $value){
                $keyGen = explode("_",$key);
                $levelWords = $keyGen[0];
                $leve = $keyGen[1];
                $ses = $keyGen[2];
                $firstSem = $value['FirstSemester'];
                $SecSem = $value['SecondSemester'];
                if($enter == false){
                    $outputTB.='<tbody><tr><th colspan="6"><div style="text-align:left;">Name: '.$row['Name'].'</div></th></tr><tr><th colspan="6"><div class="aks-bg-br2-header">YEAR: '.lev($keyGen[1]).'</div><div class="aks-bg-br2-header">1ST SEMESTER</div><div class="aks-bg-br2-header">SESSION: '.$ses.'</div></th></tr><tr><th>COURSE CODE</th><th>COURSE TITLE</th><th>CREDIT HOURS</th><th>GRADE</th><th>GRADE POINT</th><th>GPA</th></tr></tbody>';
                    // $enter = true;
                }else{
                    $outputTB.='<tr><th colspan="6">'.formHeader().'</th></tr><tr><th colspan="6"><div style="text-align:left;">Name: '.$row['Name'].'</div></th></tr><tr><th colspan="6"><div class="aks-bg-br2-header">YEAR: '.lev($keyGen[1]).'</div><div class="aks-bg-br2-header">1ST SEMESTER</div><div class="aks-bg-br2-header">SESSION: '.$ses.'</div></th></tr><tr><th>COURSE CODE</th><th>COURSE TITLE</th><th>CREDIT HOURS</th><th>GRADE</th><th>GRADE POINT</th><th>GPA</th></tr>';
                }
                foreach($firstSem as $key2 => $courses){
                    //couese code $courses[0], course title $courses[1], credithour $courses[2],grade $courses[3],grade point $courses[4]
                    $outputTB.='<tr><td>'.$courses[0].'</td><td>'.$courses[1].'</td><td>'.$courses[2].'</td><td>'.$courses[3].'</td><td>'.$courses[4].'</td><td></td></tr>';
                    $umCreditH+=$courses[2];
                    $umCreditHL+=$courses[2];
                    $sumGradePoint+=$courses[4];
                    $sumGradePointL+=$courses[4];
                }
                $outputTB.='<tr><td>TOTAL</td><td></td><td>'.$umCreditH.'</td><td></td><td>'.$sumGradePoint.'</td><td></td></tr>';
                $outputTB.='<tr><td colspan="2">GPA</td><td></td><td></td><td></td><td>'.$sumGradePoint/$umCreditH.'</td></tr>';
                $umCreditH = 0;
                $sumGradePoint = 0;
                $outputTB.='<tr><td colspan="6"><div style="text-align: center;">2ND SEMESTER</div></td></tr>';
                foreach($SecSem as $key3 => $courses3){
                    //couese code $courses[0], course title $courses[1], credithour $courses[2],grade $courses[3],grade point $courses[4]
                    $outputTB.='<tr><td>'.$courses3[0].'</td><td>'.$courses3[1].'</td><td>'.$courses3[2].'</td><td>'.$courses3[3].'</td><td>'.$courses3[4].'</td><td></td></tr>';
                    $umCreditH2+=$courses3[2];
                    $umCreditHL2+=$courses3[2];
                    $sumGradePoint2+=$courses3[4];
                    $sumGradePointL2+=$courses3[4];
                }
                $outputTB.='<tr><td>TOTAL</td><td></td><td>'.$umCreditH2.'</td><td></td><td>'.$sumGradePoint2.'</td><td></td></tr>';
                $outputTB.='<tr><td colspan="2">GPA</td><td></td><td></td><td></td><td>'.$sumGradePoint2/$umCreditH2.'</td></tr>';
                $firstSeconcredhor = $umCreditHL+$umCreditHL2;
                $firstSeconGradePoint = $sumGradePointL+$sumGradePointL2;
                $outputTB.='<tr><td colspan="2">CGPA</td><td>'.$firstSeconcredhor.'</td><td></td><td>'.$firstSeconGradePoint.'</td><td>'.$firstSeconGradePoint/$firstSeconcredhor.'</td></tr>';
            }
            $outputTB.='</table>';
            $outputTB.=$Temp;
            die($outputTB);
            $html = $outputTB;
            $_->generategeneratePDFv6($html,5,5,'','L');
        }else{
           echo $errorCode['||'];
        }
    break;

    case 2:
        $rstRefNo = $_->Select("payhistory_tb p,session_tb s","p.*,s.SesName","TransID = ".trim($_->SqlSafe($_GET['s_t']))." AND p.Ses = s.SesID ");
        $payM = '';
        $outputTB ='
            <div class="w3-center" style="text-align:center;">
                <img class="w3-circle" src="../../assets/images/FB_1.jpeg" width="70" height="70" alt="">
            </div>
            <div class="w3-center" style="margin-top:5px;text-align:center;">
                    <strong style="font-size:30px;font-weight:bold;">AKWA IBOM STATE UNIVERSITY</strong>
            </div>
            <div class="w3-row w3-center" style="text-align:center;font-size: 0.75em;">P.M.B. 1167 UYO, AKWA IBOM STATE, NIGERIA</div>
            <div class="w3-center" style="margin-top:5px;text-align:center;">
                    <strong style="font-size:15px;font-weight:bold;">AKWA IBOM STATE UNIVERSITY PAYMENT ANALYSIS</strong>
            </div>
            ';
        
        if($rstRefNo[1] > 0){
            // paid
            $payM = "PAID";
            $rowOrder = $rstRefNo[0]->fetch_assoc();
            $namesDetails = json_decode($rowOrder['Info']);
            $breakDwn = json_decode($rowOrder['PayBrkDn']);
            $dateReg = explode('-', $rowOrder['PayDate']);
            $dateReg = $dateReg[2].'/'.$dateReg[1].'/'.$dateReg[0];
            $sems = $rowOrder['Sem']==1?"FIRST SEMESTER":"SECOND SEMESTER";
            $Tbb = '<table class="w3-white w3-small" style="width:100%;"><tr><th>S/N</th><th>ITEM BREAKDOWN</th><th>AMOUNT</th></tr>';
            $cnt4 = 1;
            $totalAmt = 0;
            foreach($breakDwn as $key => $val){
                $totalAmt+=$val;
                $Tbb.=' <tr><td>'.$cnt4.'</td><td>'.strtoupper($key).'</td><td>'.$val.'</td></tr>';
                $cnt4++;
            }
            $Tbb.='<tr><td colspan="2" style="text-align:center;">TOTAL AMOUNT</td><th>'.number_format($totalAmt,2).'</th></tr></table>';
            // die(''.$breakDwn->FeesCharges);
            $outputTB.='
                <div class="w3-light-grey" style="position:relative;width:100%;height:120px;padding:15px;">
                    <div class="w3-center w3-white" style="width:100%;padding:1px;font-size:14px;font-weight:bold;">PAYMENT DETAILS</div>
                    <div class=" w3-white" style="width:100%;font-size:13px;margin-top:3px;">
                            <div style="float:left;width:30%;">&nbsp;FULL NAME:</div>
                            <div style="float:left;width:70%;">'.$namesDetails->Name.'</div>
                    </div>
                    <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                            <div style="float:left;width:30%;">&nbsp;REGISTRATION NUMBER:</div>
                            <div style="float:left;width:70%;">'.$namesDetails->RegNo.'</div>
                    </div>
                    <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                            <div style="float:left;width:30%;">&nbsp;PAYMENT REFERENCE:</div>
                            <div style="float:left;width:70%;">'.trim($_GET['s_t']).'</div>
                    </div>
                    <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                            <div style="float:left;width:30%;">&nbsp;PAYMENT TYPE</div>
                            <div style="float:left;width:70%;">'.$namesDetails->PayName.'</div>
                    </div>
                    <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                            <div style="float:left;width:30%;">&nbsp;DATE:</div>
                            <div style="float:left;width:70%;">'.$dateReg.'</div>
                    </div>
                    <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                            <div style="float:left;width:30%;">&nbsp;SEMESTER:</div>
                            <div style="float:left;width:70%;">'.$sems.'</div>
                    </div>
                    <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                            <div style="float:left;width:30%;">&nbsp;SESSION:</div>
                            <div style="float:left;width:70%;">'.$rowOrder['SesName'].'</div>
                    </div>
                </div>
                <div style="margin-top:10px;">
                    <div class="w3-light-grey" style="width:90%;margin:auto;">
                        '.$Tbb.'
                    </div>
                </div>
            ';
        }else{
            // not paid
            $payM = "UNPAID";
            $rstRefOrder = $_->Select("order_tb","*","TransNum = ".trim($_->SqlSafe($_GET['s_t']))."");
            if($rstRefOrder[1] > 0){
                $rowOrder = $rstRefOrder[0]->fetch_assoc();
                $namesDetails = json_decode($rowOrder['Info']);
                $breakDwn = json_decode($rowOrder['BrkDwn']);
                $dateReg = explode('-', $rowOrder['RegDate']);
                $dateReg = $dateReg[2].'/'.$dateReg[1].'/'.$dateReg[0];
                // die(''.$breakDwn->FeesCharges);
                $outputTB.='
                    <div class="w3-grey" style="position:relative;width:100%;height:120px;padding:15px;">
                        <div class="w3-center w3-white" style="width:100%;padding:1px;font-size:14px;font-weight:bold;box-shadow:0 1px 4px rgb(0 0 0 / 60%);">PAYMENT DETAILS</div>
                        <div class=" w3-white" style="width:100%;font-size:13px;margin-top:3px;">
                                <div style="float:left;width:30%;">&nbsp;FULL NAME:</div>
                                <div style="float:left;width:70%;">'.$namesDetails->Name.'</div>
                        </div>
                        <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                                <div style="float:left;width:30%;">&nbsp;REGISTRATION NUMBER:</div>
                                <div style="float:left;width:70%;">'.$namesDetails->RegNo.'</div>
                        </div>
                        <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                                <div style="float:left;width:30%;">&nbsp;PAYMENT REFERENCE:</div>
                                <div style="float:left;width:70%;">'.trim($_GET['s_t']).'</div>
                        </div>
                        <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                                <div style="float:left;width:30%;">&nbsp;PAYMENT TYPE:</div>
                                <div style="float:left;width:70%;">'.$namesDetails->PayName.'</div>
                        </div>
                        <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                                <div style="float:left;width:30%;">&nbsp;DATE:</div>
                                <div style="float:left;width:70%;">'.$dateReg.'</div>
                        </div>
                        <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                            <div style="float:left;width:30%;">&nbsp;SEMESTER:</div>
                            <div style="float:left;width:70%;">'.$sems.'</div>
                        </div>
                        <div class=" w3-white" style="width:100%;font-size:13px;margin-top:2px;clear:both;">
                                <div style="float:left;width:30%;">&nbsp;SESSION:</div>
                                <div style="float:left;width:70%;">'.$rowOrder['SesName'].'</div>
                        </div>
                    </div>
                    <div style="margin-top:10px;">
                        <div class="w3-light-grey" style="width:90%;margin:auto;">
                            '.$Tbb.'
                        </div>
                    </div>
                ';
            }else{
                echo 'WRONG REF';
            }
        }
        // die($outputTB);
        $html = $outputTB;
        $_->generategeneratePDFv6($html,5,5,$payM,'L');
    break;
    // gen ref number
    case 3:
        $outputTB.='<div class="w3-row w3-center w3-small w3-margin-top" style="text-align:center;font-size: 0.70em;"><strong>REGISTRATION CONFIRMATION SLIP</strong></div>';
        $rstRefNo = $_->Select("pstudentinfo_tb p,programme_tb pr,state_tb s,lga_tb l","p.*,pr.ProgName,s.StateName,l.LGAName","p.JambNo = ".trim($_->SqlSafe($_GET['s_t']))." AND p.ID = pr.ProgID AND p.StateId = s.StateID AND p.LGA = l.LGAID");
        if($rstRefNo[1] > 0){
            $row = $rstRefNo[0]->fetch_assoc();
            $gender = $row['Gender']=="F"?"FEMALE":"MALE";
            $moe = $row['ModeOfEntry']=="1"?"TOP-UP":"PART-TIME";
            // COMPUTE OLEVL
            $OlevelRst = explode('###',$row['OlevelRst']);
            if(count($OlevelRst) > 1){
                // 2 sittins
                $OlevelRstDetails = explode('###',$row['OlevelRstDetails']);
                // first sit
                $firstSi = $OlevelRstDetails[0];
                $firstSi = explode('`~',$firstSi);
                // school name
                $sclName = $firstSi[0];
                // ex yer
                $sclyear = $firstSi[1];
                // exm numb
                $sclNumber = $firstSi[2];
                // exams typ
                $rstExamTy = $_->Select("olevelexamtype_tb","*","ID = ".trim($_->SqlSafe($firstSi[3]))."");
                $rowEx = $rstExamTy[0]->fetch_assoc();
                $scltype = $rowEx['Name'];
                // comp olv first
                $OlevelRst = $OlevelRst[0];
                $OlevelRst = explode(";",$OlevelRst);
                $TB1 = '<table class="w3-small" style="width:100%;"><tr><th>S/N</th><th>SUBJECT</th><th>GRADE</th></tr>';
                $cnt1 = 1;
                foreach($OlevelRst as $val1){
                    $subJNam = explode("=",$val1);
                    if($subJNam[0]=="")continue;
                    $TB1.='<tr><td>'.$cnt1.'</td><td>'.$subJNam[0].'</td><td>'.$subJNam[1].'</td></tr>';
                    $cnt1++;
                }
                $TB1.='</table>';
                // die($TB1);
                // comput 2 sittings
                // first sit
                $firstSi2 = $OlevelRstDetails[1];
                $firstSi2 = explode('`~',$firstSi2);
                // school name
                $sclName2 = $firstSi2[0];
                // ex yer
                $sclyear2 = $firstSi2[1];
                // exm numb
                $sclNumber2 = $firstSi2[2];
                // exams typ
                $rstExamTy2 = $_->Select("olevelexamtype_tb","*","ID = ".trim($_->SqlSafe($firstSi2[3]))."");
                $rowEx2 = $rstExamTy2[0]->fetch_assoc();
                $scltype2 = $rowEx2['Name'];
                // comp olv first
                $OlevelRst2 = explode('###',$row['OlevelRst']);
                // die;
                $OlevelRst2 = $OlevelRst2[1];
                $OlevelRst2 = explode(";",$OlevelRst2);
                $TB2 = '<table class="w3-small" style="width:100%;"><tr><th>S/N</th><th>SUBJECT</th><th>GRADE</th></tr>';
                $cnt2 = 1;
                foreach($OlevelRst2 as $val2){
                    $subJNam2 = explode("=",$val2);
                    if($subJNam2[0]=="")continue;
                    $TB2.='<tr><td>'.$cnt2.'</td><td>'.$subJNam2[0].'</td><td>'.$subJNam2[1].'</td></tr>';
                    $cnt2++;
                }
                $TB2.='</table>';
                // die($TB2);
                $Sitings12 = '
                <div class="cor-row">
                    <div class="cor-column" style="width:50%;">
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">SCHOOL NAME:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclName.'</div>
                        </div> 
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">EXAM YEAR:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclyear.'</div>
                        </div>
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">EXAM NUMBER:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclNumber.'</div>
                        </div>
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:3px;">
                            '.$TB1.'
                        </div>
                    </div>        
                    <div class="cor-column" style="width:50%;">
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">SCHOOL NAME:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclName2.'</div>
                        </div> 
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">EXAM YEAR:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclyear2.'</div>
                        </div>
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">EXAM NUMBER:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclNumber2.'</div>
                        </div>
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:3px;">
                            '.$TB2.'
                        </div>
                    </div>        
                </div>
                ';
            }else{
                // 1 siting
                // 2 sittins
                // $OlevelRstDetails = explode('###',$row['OlevelRstDetails']);
                // first sit
                $firstSi = $row['OlevelRstDetails'];
                $firstSi = explode('`~',$firstSi);
                // school name
                $sclName = $firstSi[0];
                // ex yer
                $sclyear = $firstSi[1];
                // exm numb
                $sclNumber = $firstSi[2];
                // exams typ
                $rstExamTy = $_->Select("olevelexamtype_tb","*","ID = ".trim($_->SqlSafe($firstSi[3]))."");
                $rowEx = $rstExamTy[0]->fetch_assoc();
                $scltype = $rowEx['Name'];
                // comp olv first
                $OlevelRst = $OlevelRst[0];
                $OlevelRst = explode(";",$OlevelRst);
                $TB1 = '<table class="w3-small" style="width:100%;"><tr><th>S/N</th><th>SUBJECT</th><th>GRADE</th></tr>';
                $cnt1 = 1;
                foreach($OlevelRst as $val1){
                    $subJNam = explode("=",$val1);
                    if($subJNam[0]=="")continue;
                    $TB1.='<tr><td>'.$cnt1.'</td><td>'.$subJNam[0].'</td><td>'.$subJNam[1].'</td></tr>';
                    $cnt1++;
                }
                $TB1.='</table>';
                $Sitings12 = '
                <div class="cor-row">
                    <div class="cor-column" style="width:100%;">
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">SCHOOL NAME:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclName.'</div>
                        </div> 
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">EXAM YEAR:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclyear.'</div>
                        </div>
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                            <div class="cor-column" style="width:30%">EXAM NUMBER:</div>
                            <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclNumber.'</div>
                        </div>
                        <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:3px;">
                            '.$TB1.'
                        </div>
                    </div>     
                </div>
                ';
            }
            $outputTB.='<div>
                <div class=" aks-Records-all-width- cor-row w3-light-grey w3-border cep_padding">
                    <div class="cor-column" style="width:60%;">
                        <div class="cep_padding_innner ">
                            <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">BASIC DETAILS</div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">NAME:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SurName'].' '.$row['FirstName'].' '.$row['OtherNames'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">REG. NUMBER:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['JambNo'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">STATE:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['StateName'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">LGA:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['LGAName'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">NATIONLAITY:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Nationality'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">GENDER:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$gender.'</div>
                            </div>
                        </div>
                    </div>
                    <div class="cor-column" style="width:40%;">
                        <div class="cep_padding_innner ">
                            <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">PASSPORT PHOTOGRAPH</div>
                            <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border" style="width:100%;height:150px;padding:5px;">
                                <div style="width:200px;height:200px;margin:auto;">
                                    <img src="../../api/uploads/passports/'.$row['Passport'].'" width="100%" height="100%">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=" w3-margin-top cor-row w3-light-grey w3-border cep_padding">
                    <div class="cor-column" style="width:50%;">
                        <div class="cep_padding_innner ">
                            <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">CONTACT DETAILS</div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">PHONE NUMBER:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Phone'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">EMAIL:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Email'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">ADDRESS:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Addrs'].'</div>
                            </div>
                        </div>
                    </div>
                    <div class="cor-column" style="width:50%;">
                        <div class="cep_padding_innner ">
                            <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">ACADEMIC DETAILS</div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">DEPT:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['ProgName'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">MODE OF ENTRY:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$moe.'</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=" w3-margin-top cor-row w3-light-grey w3-border cep_padding">
                    <div class="cor-column" style="width:100%;">
                        <div class="cep_padding_innner ">
                            <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">SPONSOR\'s DETAILS</div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">NAME:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SponsorName'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">ADDRESS:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SponsorName'].'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">PHONE NUMBER:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SponsorPhone'].'</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=" w3-margin-top cor-row w3-light-grey w3-border cep_padding">
                    <div class="cor-column" style="width:100%;">
                        <div class="cep_padding_innner ">
                            <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">O\'LEVEL DETAILS</div>
                            '.$Sitings12.'
                        </div>
                    </div>
                </div>
            </div>';
        }else{
            $outputTB.='error';
        }
    //    die($outputTB);
       $html = $outputTB;
       $_->generategeneratePDFv6($html,5,5,'AKSU','L');
    break;
        // gen diodata reg slip
    case 4:
            $outputTB.='<div class="w3-row w3-center w3-small w3-margin-top" style="text-align:center;font-size: 0.70em;"><strong>BIODATA REGISTRATION SLIP</strong></div>';
            $rstRefNo = $_->Select("studentinfo_tb p,programme_tb pr,state_tb s,lga_tb l,accesscode_tb a,session_tb ses","p.*,pr.ProgName,s.StateName,l.LGAName,a.AccessCode,ses.SesName","p.JambNo = ".trim($_->SqlSafe($_GET['s_t']))." AND p.ID = pr.ProgID AND p.StateId = s.StateID AND p.LGA = l.LGAID AND p.JambNo = a.JambNo AND p.StartSes = ses.SesID");
            if($rstRefNo[1] > 0){
                $row = $rstRefNo[0]->fetch_assoc();
                $gender = $row['Gender']=="F"?"FEMALE":"MALE";
                $moe = $row['ModeOfEntry']=="1"?"TOP-UP":"PART-TIME";
                // COMPUTE OLEVL
                $OlevelRst = explode('###',$row['OlevelRst']);
                if(count($OlevelRst) > 1){
                    // 2 sittins
                    $OlevelRstDetails = explode('###',$row['OlevelRstDetails']);
                    // first sit
                    $firstSi = $OlevelRstDetails[0];
                    $firstSi = explode('`~',$firstSi);
                    // school name
                    $sclName = $firstSi[0];
                    // ex yer
                    $sclyear = $firstSi[1];
                    // exm numb
                    $sclNumber = $firstSi[2];
                    // exams typ
                    $rstExamTy = $_->Select("olevelexamtype_tb","*","ID = ".trim($_->SqlSafe($firstSi[3]))."");
                    $rowEx = $rstExamTy[0]->fetch_assoc();
                    $scltype = $rowEx['Name'];
                    // comp olv first
                    $OlevelRst = $OlevelRst[0];
                    $OlevelRst = explode(";",$OlevelRst);
                    $TB1 = '<table class="w3-small" style="width:100%;"><tr><th>S/N</th><th>SUBJECT</th><th>GRADE</th></tr>';
                    $cnt1 = 1;
                    foreach($OlevelRst as $val1){
                        $subJNam = explode("=",$val1);
                        if($subJNam[0]=="")continue;
                        $TB1.='<tr><td>'.$cnt1.'</td><td>'.$subJNam[0].'</td><td>'.$subJNam[1].'</td></tr>';
                        $cnt1++;
                    }
                    $TB1.='</table>';
                    // die($TB1);
                    // comput 2 sittings
                    // first sit
                    $firstSi2 = $OlevelRstDetails[1];
                    $firstSi2 = explode('`~',$firstSi2);
                    // school name
                    $sclName2 = $firstSi2[0];
                    // ex yer
                    $sclyear2 = $firstSi2[1];
                    // exm numb
                    $sclNumber2 = $firstSi2[2];
                    // exams typ
                    $rstExamTy2 = $_->Select("olevelexamtype_tb","*","ID = ".trim($_->SqlSafe($firstSi2[3]))."");
                    $rowEx2 = $rstExamTy2[0]->fetch_assoc();
                    $scltype2 = $rowEx2['Name'];
                    // comp olv first
                    $OlevelRst2 = explode('###',$row['OlevelRst']);
                    // die;
                    $OlevelRst2 = $OlevelRst2[1];
                    $OlevelRst2 = explode(";",$OlevelRst2);
                    $TB2 = '<table class="w3-small" style="width:100%;"><tr><th>S/N</th><th>SUBJECT</th><th>GRADE</th></tr>';
                    $cnt2 = 1;
                    foreach($OlevelRst2 as $val2){
                        $subJNam2 = explode("=",$val2);
                        if($subJNam2[0]=="")continue;
                        $TB2.='<tr><td>'.$cnt2.'</td><td>'.$subJNam2[0].'</td><td>'.$subJNam2[1].'</td></tr>';
                        $cnt2++;
                    }
                    $TB2.='</table>';
                    // die($TB2);
                    $Sitings12 = '
                    <div class="cor-row">
                        <div class="cor-column" style="width:50%;">
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">SCHOOL NAME:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclName.'</div>
                            </div> 
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">EXAM YEAR:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclyear.'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">EXAM NUMBER:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclNumber.'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:3px;">
                                '.$TB1.'
                            </div>
                        </div>        
                        <div class="cor-column" style="width:50%;">
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">SCHOOL NAME:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclName2.'</div>
                            </div> 
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">EXAM YEAR:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclyear2.'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">EXAM NUMBER:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclNumber2.'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:3px;">
                                '.$TB2.'
                            </div>
                        </div>        
                    </div>
                    ';
                }else{
                    // 1 siting
                    // 2 sittins
                    // $OlevelRstDetails = explode('###',$row['OlevelRstDetails']);
                    // first sit
                    $firstSi = $row['OlevelRstDetails'];
                    $firstSi = explode('`~',$firstSi);
                    // school name
                    $sclName = $firstSi[0];
                    // ex yer
                    $sclyear = $firstSi[1];
                    // exm numb
                    $sclNumber = $firstSi[2];
                    // exams typ
                    $rstExamTy = $_->Select("olevelexamtype_tb","*","ID = ".trim($_->SqlSafe($firstSi[3]))."");
                    $rowEx = $rstExamTy[0]->fetch_assoc();
                    $scltype = $rowEx['Name'];
                    // comp olv first
                    $OlevelRst = $OlevelRst[0];
                    $OlevelRst = explode(";",$OlevelRst);
                    $TB1 = '<table class="w3-small" style="width:100%;"><tr><th>S/N</th><th>SUBJECT</th><th>GRADE</th></tr>';
                    $cnt1 = 1;
                    foreach($OlevelRst as $val1){
                        $subJNam = explode("=",$val1);
                        if($subJNam[0]=="")continue;
                        $TB1.='<tr><td>'.$cnt1.'</td><td>'.$subJNam[0].'</td><td>'.$subJNam[1].'</td></tr>';
                        $cnt1++;
                    }
                    $TB1.='</table>';
                    $Sitings12 = '
                    <div class="cor-row">
                        <div class="cor-column" style="width:100%;">
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">SCHOOL NAME:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclName.'</div>
                            </div> 
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">EXAM YEAR:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclyear.'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                <div class="cor-column" style="width:30%">EXAM NUMBER:</div>
                                <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$sclNumber.'</div>
                            </div>
                            <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:3px;">
                                '.$TB1.'
                            </div>
                        </div>     
                    </div>
                    ';
                }
                $outputTB.='<div>
                    <div class=" aks-Records-all-width- cor-row w3-light-grey w3-border cep_padding">
                        <div class="cor-column" style="width:60%;">
                            <div class="cep_padding_innner ">
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">BASIC DETAILS</div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">NAME:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SurName'].' '.$row['FirstName'].' '.$row['OtherNames'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">REG. NUMBER:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['JambNo'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">STATE:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['StateName'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">LGA:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['LGAName'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">NATIONLAITY:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Nationality'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">GENDER:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$gender.'</div>
                                </div>
                            </div>
                        </div>
                        <div class="cor-column" style="width:40%;">
                            <div class="cep_padding_innner ">
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">PASSPORT PHOTOGRAPH</div>
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border" style="width:100%;height:150px;padding:5px;">
                                    <div style="width:200px;height:200px;margin:auto;">
                                        <img src="../../api/uploads/passports/'.$row['Passport'].'" width="100%" height="100%">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" w3-margin-top cor-row w3-light-grey w3-border cep_padding">
                        <div class="cor-column" style="width:50%;">
                            <div class="cep_padding_innner ">
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">CONTACT DETAILS</div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">PHONE NUMBER:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Phone'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">EMAIL:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Email'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">ADDRESS:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['Addrs'].'</div>
                                </div>
                            </div>
                        </div>
                        <div class="cor-column" style="width:50%;">
                            <div class="cep_padding_innner ">
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">ACADEMIC DETAILS</div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">DEPT:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['ProgName'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">MODE OF ENTRY:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$moe.'</div>
                                </div> 
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">ADMITTED SESSION:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SesName'].'</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" w3-margin-top cor-row w3-light-grey w3-border cep_padding">
                        <div class="cor-column" style="width:50%;">
                            <div class="cep_padding_innner ">
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">SPONSOR\'s DETAILS</div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">NAME:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SponsorName'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">ADDRESS:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SponsorName'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">PHONE NUMBER:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['SponsorPhone'].'</div>
                                </div>
                            </div>
                        </div>
                        <div class="cor-column" style="width:50%;">
                            <div class="cep_padding_innner ">
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">LOGIN DETAILS</div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">REG. NUMBER:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['RegNo'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">ACCESS CODE:</div>
                                    <div class="cor-column" style="width:70%;">'.$row['AccessCode'].'</div>
                                </div>
                                <div class="cor-row w3-white w3-border aks-Records-font-11_60" style="padding:0 3px;">
                                    <div class="cor-column" style="width:30%">JAMB NUMBER:</div>
                                    <div class="cor-column" style="width:70%;text-transform:uppercase;">'.$row['JambNo'].'</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" w3-margin-top cor-row w3-light-grey w3-border cep_padding">
                        <div class="cor-column" style="width:100%;">
                            <div class="cep_padding_innner ">
                                <div class="cep_title aks-Records-font-11_60 aks-Records-btn-inner-txt w3-white w3-border">O\'LEVEL DETAILS</div>
                                '.$Sitings12.'
                            </div>
                        </div>
                    </div>
                </div>';
            }else{
                $outputTB.='error';
            }
        //    die($outputTB);
           $html = $outputTB;
           $_->generategeneratePDFv6($html,5,5,'AKSU','L');
    break;
    // print course
    case 10:
        
    break;

    default:

    break;
}
function gender($gen){
    if($gen == "F"){
        return "FEMALE";
    }else{
        return "MALE";
    }
}
function modeOfEntry($gen){
    
    switch($gen){

        case 1:
            return "UTME";
        break;

        case 2:
            return "ND";
        break;

        case 3:
            return "HND";
        break;
    }
}
function examType($gen){
    switch($gen){
        case "~2":
            return "WAEC";
        break;

        case "~3":
            return "NECO";
        break;

        case "~4":
            return "NAPTECH";
        break;

        default:
            $gen = ltrim($gen,"~");
            return $gen;
        break;
    }
}
function interExter($gen){
    if($gen == "~1"){
        return "June";
    }else{
        return "Nov/Dec";
    }
}
function lev($gen){
    switch($gen){
        case 100:
            return "ONE";
        break;

        case 200:
            return "TWO";
        break;

        case 300:
            return "THREE";
        break;

        case 400:
            return "FOUR";
        break;

        case 500:
            return "FIVE";
        break;

        case 600:
            return "SIX";
        break;

        case 700:
            return "SEVEN";
        break;

        case 800:
            return "EIGHT";
        break;

        case 900:
            return "NINE";
        break;

        default:
            return "TEN";
        break;
    }
}
function formHeader(){
    // global $outputTB;
    $outputTB ='
            <div class="w3-center" style="text-align:center;">
                <img class="w3-circle" src="../../assets/images/FB_1.jpeg" width="70" height="70" alt="">
            </div>
            <div class="w3-center" style="margin-top:5px;text-align:center;">
                    <strong style="font-size:30px;font-weight:bold;">AKWA IBOM STATE UNIVERSITY</strong>
            </div>
            <div class="w3-row w3-center w3-small" style="text-align:center;font-size: 0.75em;">P.M.B. 1167 UYO, AKWA IBOM STATE, NIGERIA</div>
            <div class="w3-center" style="margin-top:5px;text-align:center;">
                    <strong style="font-size:18px;font-weight:bold;">STUDENT\'S ACADEMIC TRANSCRIPT</strong>
            </div>
            ';
    return $outputTB;   
}
?>
<!-- {"Level_100_2015\/2016":{"FirstSemester":[[["517","CHM 101","GENERAL CHEMISTRY I","4","C","12","57"],["374","BIO 101","GENERAL BIOLOGY","4","B","16","61"],["2219","PHY 101","GENERAL PHYSICS","4","C","12","56"],["1963","MTH 111","ALGEBRA AND TRIGONOMETRY","3","B","12","62"],["1267","GSS 101","USE OF ENGLISH I","2","B","8","61"],["1409","GSS 131","INTRODUCTION TO PHILOSOPHY AND LOGIC","2","A","10","70"]],"19","70","3"],"SecondSemester":[[["3372","CHM 102","GENERAL CHEMISTRY II","4","A","20","70"],["3373","BIO 102","GENERAL BIOLOGY II","4","C","12","59"],["3374","PHY 102","GENERAL PHYSICS II","4","A","20","70"],["3375","MTH 112","COORDINATE GEOMETRY AND CALCULUS","3","D","6","46"],["3376","GSS 102","USE OF ENGLISH II","2","A","10","72"],["3377","GSS 112","NIGERIAN PEOPLE AND CULTURE","2","A","10","80"],["4068","GSS 122","HISTORY AND PHILOSOPHY OF SCIENCE","2","A","10","71"]],"21","88","4"]},"Level_200_2016\/2017":{"FirstSemester":[[["571","CHM 221","PHYSICAL CHEMISTRY I","3","A","15","71"],["564","CHM 211","INORGANIC CHEMISTRY I","3","C","9","58"],["2284","PHY 221","VIBRATION AND WAVES","3","B","12","65"],["2303","PHY 291","INTRODUCTORY PHYSICS","3","B","12","64"],["587","CHM 261","PRACTICAL CHEMISTRY III","1","C","3","51"],["1974","MTH 201","ADVANCED MATHEMATICS I","3","A","15","74"],["1478","GSS 211","INTRODUCTION TO COMPUTER","2","B","8","67"],["1451","GSS 201","INTRODUCTION TO ENTERPRENEURIAL STUDIES","2","B","8","66"]],"20","82","4"],"SecondSemester":[[["3378","CHM 232","ORGANIC CHEMISTRY I","3","A","15","79"],["3380","CHM 242","ANALYTICAL CHEMISTRY I","3","C","9","59"],["3381","CHM 212","STRUCTURE AND BONDING","2","B","8","64"],["3382","PHY 252","ELECTRICAL CIRCUIT AND ELECTRONICS","3","C","9","57"],["3379","CHM 262","PRACTICAL CHEMISTRY IV","1","A","5","79"],["3383","STA 202","STATISTICS FOR THE SCIENCES","3","C","9","53"],["3384","MTH 202","ADVANCED MATHEMATICS II","3","C","9","50"],["3385","GSS 212","COMPUTER APPLICATION","2","C","6","59"]],"20","70","3"]}} -->