<?php
require_once "../engine/Robot.php";
require_once "errormsg.php";
$getJall = json_decode($_POST['data']);
$expl = explode('_',$getJall->param);
$getDetials = $_->Select("lga_tb","*","StateID = ".trim($_->SqlSafe($expl[1]))."");
if($getDetials[1] > 0) {
	$TB = '<option value="" selected disabled>LGA</option>';
	while($row = $getDetials[0]->fetch_assoc()){
		$TB.='<option value="'.$row['LGAName'].'" >'.strtoupper($row['LGAName']).'</option>';
	}
	die($TB);
}
?>