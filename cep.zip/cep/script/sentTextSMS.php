<?php
require_once "../engine/Robot.php";
$getJall = json_decode($_POST['data']);
$Jam_bN = trim($_->SqlSafe($getJall->Jam_bN));
$Program_Name = trim($_->SqlSafe($getJall->Program_Name));
$Pho_neN = trim($_->SqlSafe($getJall->Pho_neN));
$email = trim($_->SqlSafe($getJall->email));
$getPstuinf = $_->Select("pstudentinfo_tb","SurName,FirstName,OtherNames","JambNo = '$Jam_bN'");
if($getPstuinf[1] > 0){
    $rowNma = $getPstuinf[0]->fetch_assoc();
    $name = $rowNma['FirstName']." ".$rowNma['OtherNames']." ".$rowNma['SurName'];
    $SName = "AKSU";
    $messagetext = "CONGRATULATIONS ".$name.". YOU HAVE BEEN OFFERED ADMISSION INTO ".$Program_Name." DEPARTMENT. VISIT aksu.edu.ng/AL ...AKSU-ICT";
    $recipients = "$Pho_neN";
      //email
    $getTextRes = $_->useHTTPGet($messagetext,$recipients);
    // send Email with aksu logo
    $to = $email; // reciver

    // Subject
    $subject = 'ADMISSION';
// Message
$message = '
<html>
<head>
  <title>'.$subject.'</title>
</head>
<body>
  <div style="width:100%;">
    <div style="text-align:center;">
		<img src="http://aksu.edu.ng/admission/assets/images/chlogo.png" width="100" height="100" alt="photo" />
	</div>
	<div style="margin-top:3px;text-align:center;">
			<strong>AKWA IBOM STATE UNIVERSITY</strong>
	</div>
	<div style="text-align:center;"><strong>P.M.B. 1167 UYO, AKWA IBOM STATE, NIGERIA</strong></div>
	<div style="text-align:center;"><strong>IKOT AKPADEN, MKPAT ENIN L.G.A,AKWA IBOM STATE</strong></div>
  </div>
  <p>Dear '.$name.',</p>
  <div>
    <div>CONGRATULATIONS.</div>
    <div>YOU HAVE BEEN OFFERED ADMISSION INTO '.$Program_Name.' DEPARTMENT.</div>
  </div>
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers 
//$headers[] = 'To: Mfoniso Asuquo <mfonisoasuquo@aksu.edu.ng>, Enefiok Duke <enefiokduke@aksu.edu.ng>';//here you can copy other mails
$headers[] = 'From: '.$subject.' <webmaster@aksu.edu.ng>';
$sendEmailToo = $_->sendMail($to,$subject,$message,$headers);
die($getTextRes);
}
?>
