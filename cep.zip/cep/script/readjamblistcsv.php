<?php
// sleep(1);
require_once "../engine/Robot.php";
require_once "errormsg.php";
$mimeType = array("text/csv","application/vnd.ms-excel","text/plain","text/tsv");
if(in_array($_FILES['file1']['type'],$mimeType)){
	$handle = fopen($_FILES['file1']['tmp_name'], "r");
	// $headers = fgetcsv($handle, 1000, ",");
	$data = fgetcsv($handle, 1000, ",");
	$getArr = array();
	while (($data = fgetcsv($handle, 1000, ",")) !== FALSE){
		if(strlen($data[0]) < 10){die('*78');}//check serial no
		$getArr[] = ["JAMBNO" => $data[0],"CNAME" => $data[1],"GENDER" => $data[2],"STATE" => $data[3],"LGA" => $data[6],"JAMBSCOR" => $data[4],"COURSE" => $data[5],"SUBJ1" => $data[7],"SCORE1" => $data[8],"SUBJ2" => $data[9],"SCOR2" => $data[10],"SUBJ3" => $data[11],"SCOR3" => $data[12],"SCOR4" => $data[13]];
	}
	fclose($handle);
	if(count($getArr) > 0){
		die(json_encode($getArr));
	}else{
		die('*78');//contact ict *78
	}
}else{
	die('@!*');//csv format needed
}

?>