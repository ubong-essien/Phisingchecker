<?php
require_once "../engine/Robot.php";
	$decObj = json_decode($_POST['data']);
	$getcanName = $_->Select("pstudentinfo_tb p,programme_tb pro","CONCAT(p.SurName,' ',p.FirstName,' ',p.OtherNames) AS Name,p.LGA,p.JambNo,pro.ProgName","p.JambNo = '".trim($_->SqlSafe($decObj->getJmNo))."' AND p.ProgID  = pro.ProgID");
	if($getcanName[1] > 0){
		$rows = $getcanName[0]->fetch_assoc();
		die(json_encode(["CanName" => $rows['Name'], "CandJamb" => $rows['JambNo'],"progNr" => $rows['ProgName']]));
	}else{
		die('*3');
	}
?>