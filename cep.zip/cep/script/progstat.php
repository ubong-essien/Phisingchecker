<?php
require_once "../engine/Robot.php";
require_once "../engine/Roboti.php";
$err = "";
$gtT = date('Y-m-d');
//get all candidate from recommendation tb
    $tbflNames = "*";
	$tbName = "";
	$gtrecom = $_P->Select("recommendation_tb","*","1=1");
    $TP = $gtrecom[1] > 0?((int)$gtrecom[1]/(int)$gtrecom[1])*100:"0";
	
	//total de can
	$gtrecomde = $_P->Select("recommendation_tb","*","ModeOfEntry IN(2,3)");
	$TP1 = $gtrecomde[1] > 0?((int)$gtrecomde[1]/(int)$gtrecomde[1])*100:"0";
	//total admissible
    $gtrecomadms = $_P->Select("recommendation_tb","*","final_status = 1 AND ModeOfEntry = 1");
	$TP2 = $gtrecomadms[1] > 0?((int)$gtrecomadms[1]/(int)$gtrecom[1])*100:"0";
	//total can not admissible
    $gtrecomnotadms = $_P->Select("recommendation_tb","*","final_status != 1 AND ModeOfEntry = 1");
	$TP3 = $gtrecomnotadms[1] > 0?((int)$gtrecomnotadms[1]/(int)$gtrecom[1])*100:"0";
	/*total admissible*/
	$gtrecomnotadmsible = $_P->Select("recommendation_tb","*","ModeOfEntry = 1 AND final_status = 1");
	$TP4 = $gtrecomnotadmsible[1] > 0?((int)$gtrecomnotadmsible[1]/(int)$gtrecom[1])*100:"0";
	/*total admitted*/
	$admitd = $_->Select("admissionlog_tb",'*',"ModeOfEntry = 1");
	$TP5 = $admitd[1] > 0?((int)$admitd[1]/(int)$gtrecom[1])*100:"0";
	//admitted today
	$admitdToday = $_->Select("admissionlog_tb",'Time',"1=1");
	if($admitdToday[1] > 0){
		$arry = [];
		while($row = $admitdToday[0]->fetch_assoc()){
			$arrGetS = explode(" ",$row['Time']);
			//$arry[] = $arrGetS[0];
			if($gtT == $arrGetS[0]){
				$arry[] = $arrGetS[0];
			}
		}
		if(count($arry) != 0){
			$cntAr = count($arry);
		}else{
			$cntAr = 0;
		}
	}else{
		$cntAr = 0;
	}
	//notification
	$admitdTodayNotify = $_->Select("admissionlog_tb",'Time',"Sent = 1");
	if($admitdTodayNotify[1] > 0){
		$toN = $admitdTodayNotify[1];
	}else{
		$toN = 0;	
	}
	//total admited de
	$totaladde = $_P->Select("recommendation_tb","*","ModeOfEntry IN(2,3) AND AdmitStatus = 1");
	$TP6 = $totaladde[1] > 0?((int)$totaladde[1]/(int)$gtrecomde[1])*100:"0";
	//total cand not admited de 
	$totalNOTadde = $_P->Select("recommendation_tb","*","AdmitStatus = 0 AND ModeOfEntry IN(2,3,0)");
	$TP7 = $totalNOTadde[1] > 0?((int)$totalNOTadde[1]/(int)$gtrecomde[1])*100:"0";
	$perTodyNotify = $admitdTodayNotify[1] != 0?round(($admitdTodayNotify[1]/$admitd[1])*100,1):0;
	$perTody = $cntAr != 0?round(($cntAr/$admitd[1])*100,1):0;
    // if($err == "@!"){die("@!");}
	die(json_encode(["TC"=>[$gtrecom[1],$TP],"TDEC"=>[$gtrecomde[1],$TP1],"TADMC"=>[$gtrecomadms[1],$TP2],"TCNAMS"=>[$gtrecomnotadms[1],$TP3],"TNADC"=>[$admitd[1],$TP5 ],"ADMIC"=>[$gtrecomadms[1]-$admitd[1],$TP4],"AdmitedToday" => [$perTody,$cntAr],"Notification" => [$perTodyNotify,$toN],"TotalAdmitedDe" => [round($TP6,1),$totaladde[1]],"TotalDeNotAdmit" => [round($TP7,1),$totalNOTadde[1]]]));
?>