<?php
require_once "../engine/Robot.php";
$getJall = json_decode($_POST['sendJsn']);
$getDetials = $_->Select("doctor_tb","*","Email = '".trim($_->SqlSafe($getJall->tel_doc_email))."' OR PhoneNo = '".$_->SqlSafe($getJall->tel_phone)."' OR Username = '".$_->SqlSafe($getJall->tel_username)."' OR Password = '".$_->SqlSafe($getJall->tel_passw)."'");
if($getDetials[1] > 0){die("~~!");}
$pasport = $_->fileUpoadAndCheckingStaf("../assets/images/","file12","".$getJall->tel_doc_email."");
	if($pasport != "@" && $pasport != "@&@" && $pasport != "&@" && $pasport != "9@" && $pasport != "2@"){
		$gtJorCat = $_->Insert("doctor_tb",["Name" => trim($_->SqlSafe($getJall->tel_doc_name)),"DOB" => "".$_->SqlSafe($getJall->tel_doc_dob)."","Passport" => "".$_->SqlSafe($pasport)."","Gender" => "".$_->SqlSafe($getJall->tel_doc_gender)."","Address" => trim($_->SqlSafe($getJall->tel_doc_contInfo)),"PhoneNo" => "".$_->SqlSafe($getJall->tel_doc_phone)."","Email" => "".$_->SqlSafe($getJall->tel_doc_email)."","Username" => "".$_->SqlSafe($getJall->tel_doc_username)."","Password" => "".$_->SqlSafe($getJall->tel_doc_password)."","Profession" => "".$_->SqlSafe($getJall->tel_doc_profsion)."","Specialty" => "".$_->SqlSafe($getJall->tel_doc_specialty)."","Privilege" => 1]);
		if($gtJorCat[1] > 0){
			$gtJoUser = $_->Insert("users_tb",["UserID" => trim($_->SqlSafe($gtJorCat[2])),"Privilege" => 1,"Passport" => "".$_->SqlSafe($pasport)."","Username" => "".$_->SqlSafe($getJall->tel_doc_username)."","Password" => "".$_->SqlSafe($getJall->tel_doc_password)."","Name" => trim($_->SqlSafe($getJall->tel_doc_name))]);
			if($gtJoUser[1] > 0){
				die('1');
			}
		}
	}else{
		die($pasport);
	}
?>