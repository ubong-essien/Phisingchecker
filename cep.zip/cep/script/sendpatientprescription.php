<?php
error_reporting(0);
require_once "../engine/Robot.php";
require_once "../engine/sha3encryptdecriptold.php";
$getJall = json_decode($_POST['data']);
$illnessDestring = trim($_->SqlSafe($getJall->prescription));
$illnessDescriptionStringHash = encryptSH3($illnessDestring);//hash the description
$gtJoUser = $_->Update("patientappointment_db",["DoctorsPrescription" => "".$illnessDescriptionStringHash."","ApprovedChat" => trim($_->SqlSafe($getJall->getApproval))],"ID = ".trim($_->SqlSafe($getJall->getPatientUserXXX))."");
if($gtJoUser[1] > 0){
	die('1');
}
?>