<?php
session_start();
	require_once "../engine/Robot.php";
	$d_username = trim($_->SqlSafe($_POST['d_userD']));
	$d_pwrd = trim($_->SqlSafe($_POST['pard']));
	$getCours = $_->Select("accesscode_tb a,studentinfo_tb s",'s.*,a.AccessCode',"a.JambNo = '$d_username' AND a.accesscode = '$d_pwrd' AND a.JambNo = s.RegNo");
	if($getCours[1] > 0){
		// $getSesStart = $_->Select("appsetting_tb",'AdmSes,SessPatern',"ID = 1");
		// $rowStr = $getSesStart[0]->fetch_assoc();
		// $admSesStr = $rowStr['AdmSes']==""?"s.JambNo = '".$rowStr['SessPatern']."%'":'s.StartSes = '.$rowStr['AdmSes'];
		$rows = $getCours[0]->fetch_assoc();
		// $_SESSION['idd'] = $rows['ID'];
			// $_SESSION['prev'] = $rows['Privilege'];
			$name = $rows['SurName'].' '.$rows['FirstName'].' '.$rows['OtherNames'];
			die($name.'~'.$rows['Passport'].'~'.$rows['AccessCode'].'~'.$rows['RegNo']);
	}else{
		die('*3');
	}
?>