<?php
require_once "../engine/Robot.php";
	$decObj = json_decode($_POST['data']);
	$dept = explode("_", $decObj->getDpet_rr);
	$getcanName = $_->Update("pstudentinfo_tb",["ProgID" => $dept[1]],"JambNo = '".trim($_->SqlSafe($decObj->getJmNo))."'");
	die(json_encode(["SUCCESS" => "R12"]));
?>