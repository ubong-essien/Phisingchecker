<?php
require_once "../engine/Robot.php";
$jambPassportSent = [];//number of passport jamb sent to us
$JambPasportInserted = [];//total number updated
$NoUpdateMade = [];//if there is no update made in the db
$wrongExtension = [];//keep track of jamb no with wrong extension
$invalidRegNo = [];
for($i = 0; $i < count($_FILES['fileToUpload']['name']); $i++){
	$filename = str_replace(" _Face","",$_FILES['fileToUpload']['name'][$i]);
	$explodeJambNo = explode(".",$filename); 
	$jambNo = trim($explodeJambNo[0]);
	// move the file to temporay location
	if(strpos($filename, "_Face") !== false){
		$filename = str_replace("_Face","",$_FILES['fileToUpload']['name'][$i]);
	}
	if(strpos($jambNo, "_Face") !== false){
		$jambNo = explode("_",$jambNo);
		$jambNo = $jambNo[0];
	}
	 $location = '../../app/Files/UserImages/PUTME/'.$filename;
	 // file extension
	 $file_extension = pathinfo($location, PATHINFO_EXTENSION);
	 $file_extension = strtolower($file_extension);
	 // Valid extensions
	//  $valid_ext = array("pdf","doc","docx","jpg","png","jpeg");
	 $valid_ext = array("jpg");
	//  $valid_ext = array("jpg","png","jpeg");
	if(in_array($file_extension,$valid_ext)){
			$jambPassportSent[] = $jambNo;
			$pasport = 'UserImages/PUTME/'.$filename;
			// check if regNo is found
			$rstGetRegNo = $_->Select("pstudentinfo_tb","id","JambNo = '".$_->SqlSafe($jambNo)."'");
			if($rstGetRegNo[1] > 0){
				//update the candidate passport
				$rstup = $_->Update("pstudentinfo_tb",["Passport" => "".trim($pasport).""],"JambNo = '".trim($jambNo)."'");
				if($rstup[1] > 0){
					// Upload file
					if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'][$i],$location)){
						$JambPasportInserted[] = $jambNo;
					} 
				}else{
					$NoUpdateMade[] = $jambNo;
				}
			}else{
				$invalidRegNo[] = $jambNo;
			}
	}else{
		$wrongExtension[] = $jambNo;
	}
}

if(count($jambPassportSent) > 0){
	die(json_encode(["TotalPasportSent" => $jambPassportSent,"NoOFPassportInserted" => $JambPasportInserted,"JambNoNotUpdated" => $NoUpdateMade,"WrongExtensionjambNo" => $wrongExtension,"InvalidRegNo" => $invalidRegNo]));
}else{
	die("*77");
}
?>