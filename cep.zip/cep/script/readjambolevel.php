<?php
require_once "../engine/Robot.php";
$mimeType = array("text/csv","application/vnd.ms-excel","text/plain","text/tsv");
if(in_array($_FILES['file1']['type'],$mimeType)){
	$handle = fopen($_FILES['file1']['tmp_name'], "r");
	// $headers = fgetcsv($handle, 1000, ",");
	$data = fgetcsv($handle, 1000, ",");
	$getArr = array();
	while (($data = fgetcsv($handle, 1000, ",")) !== FALSE){
		// "RegNo" => $data[0]
		// "SubjectName" => $data[1]
		// "Grade" => $data[2]
		// "ExamSeries" => $data[3]
		// "ExamYear" => $data[4]
		// "ExamType" => $data[5]
		// "ExamNumber" => $data[6]
		$getArr[] = [$data[0],$data[1],$data[2],$data[3],$data[4],$data[5],$data[6]];
	}
	fclose($handle);
	// print_r($getArr);die;
	if(count($getArr) > 0){
		// OlevelRstDetails = Progressive Secondary Commercial School`~2018`~4041201015`~2`~1
		// OlevelRst = ENGLISH LANGUAGE=C4;ECONOMICS=B3;MATHEMATICS=B3;BIOLOGY=D7;FINANCIAL ACCOUNTING=C5;COMMERCE=C6;C. R. K=C6;CIVIC EDUCATION=C5;ANIMAL HUSBANDARY=C5
		// OlevelRst2 = 1=5||5=4||6=4||7=8||15=6||16=7||17=7||37=6||39=6
		// die("SELECT ID FROM olevelexamtype_tb WHERE Name = '".trim($_->escape_String($xamTy))."'");
		$numOfAffectedRows = 0;
		$holdRegNo = '';
		$holdExaminationNUmber = "";
		$OlevelRstDetails = '';
		$OlevelRst = '';
		$OlevelRst2 = '';
		//second sittings
		$Olevel2Rst = '';
		$Olevel2Rst2 = '';
		$checkCombineResult = false;
		$cnt = 0;
		$jambOlevelDetails = [];
		foreach($getArr as $key => $val){
			$examSeries = $val[3]=="School Exam"?1:2;
			if($holdRegNo == ''){
				$holdRegNo = $val[0];
				if($checkCombineResult == false){
					$holdExaminationNUmber = $val[6];
				}
				if($val[2] == "A/R"){
					$OlevelRstDetails = "AR";
					$OlevelRst = "";
					$OlevelRst2 = "";
					$Olevel2Rst = '';
					$Olevel2Rst2 = '';
				}else{
					$getGradeDetails = $_->Select("olvlgrade_tb","ID","Grade = '".trim($_->SqlSafe($val[2]))."'");
					$getGDet = $getGradeDetails[0]->fetch_assoc();
					$getSubjDetails = $_->Select("olvlsubj_tb","*","(JambOlevelSubject = '".trim($_->SqlSafe($val[1]))."' OR SubName = '".trim($_->SqlSafe($val[1]))."')");
					$getSubjDet = $getSubjDetails[0]->fetch_assoc();
					// $xamTy = $val[5]=="WAEC Only"||$val[5]=="NECO Only"?str_replace("Only","",$val[5]):"NABTEB";
					$xamTy = '';
					switch(trim($val[5])){

						case "WAEC Only":
							$xamTy = "WAEC";
						break;

						case "NECO Only":
							$xamTy = "NECO";
						break;

						case "NABTEB":
							$xamTy = "NABTEB";
						break;

						default:
							$xamTy = "OTHERS";
						break;
					}
					// $xamTy = str_replace("Only","",$val[5]);//WAEC ONLY
					$examTypeOnly = $_->Select("olevelexamtype_tb","ID","Name = '".trim($_->SqlSafe($xamTy))."'");
					$getexTypOnly= $examTypeOnly[0]->fetch_assoc();
					$OlevelRstDetails = $val[3].'`~'.$val[4].'`~'.$val[6].'`~'.$getexTypOnly['ID'].'`~'.$examSeries;
					// if($val[2] == "ACCOUNTS"){}
					$OlevelRst.= $getSubjDet['SubName'].'='.$val[2].';';
					// $OlevelRst.= $val[1].'='.$val[2].';';
					$OlevelRst2.= $getSubjDet['SubId'].'='.$getGDet['ID'].'||';
				}
			}else{
				//if $holdRegNo is not empty 
				if($holdRegNo == $val[0]){
					// $holdRegNo = $val[0];
					// echo $holdRegNo.'<br>';
					if($val[2] == "A/R"){
						//check if $OlevelRst has value
						if(strlen($OlevelRst) > 0){
							// combine results 
							$checkCombineResult = true;
							$Olevel2Rst = 'AR';
							$Olevel2Rst2 = 'AR';
						}else{
							$OlevelRstDetails = "AR";
							$OlevelRst = "";
							$OlevelRst2 = "";
							$Olevel2Rst = '';
							$Olevel2Rst2 = '';
						}
					}else{
						//still first sitting
						if($holdExaminationNUmber == $val[6]){
						// $holdExaminationNUmber = $val[6];
						$getGradeDetails = $_->Select("olvlgrade_tb","ID","Grade = '".trim($_->SqlSafe($val[2]))."'");
						$getGDet = $getGradeDetails[0]->fetch_assoc();
						$getSubjDetails = $_->Select("olvlsubj_tb","*","(JambOlevelSubject = '".trim($_->SqlSafe($val[1]))."' OR SubName = '".trim($_->SqlSafe($val[1]))."')");
						$getSubjDet = $getSubjDetails[0]->fetch_assoc();
						// $xamTy = str_replace("Only","",$val[5]);//WAEC ONLY
						// $xamTy = $val[5]=="WAEC Only"||$val[5]=="NECO Only"?str_replace("Only","",$val[5]):"NABTEB";
						$xamTy = '';
						switch(trim($val[5])){

							case "WAEC Only":
								$xamTy = "WAEC";
							break;

							case "NECO Only":
								$xamTy = "NECO";
							break;

							case "NABTEB":
								$xamTy = "NABTEB";
							break;

							default:
								$xamTy = "OTHERS";
							break;
						}
						$examTypeOnly = $_->Select("olevelexamtype_tb","ID","Name = '".trim($_->SqlSafe($xamTy))."'");
						$getexTypOnly= $examTypeOnly[0]->fetch_assoc();
						if(strpos($OlevelRstDetails, "###") !== false){
						} else{
							$OlevelRstDetails = $val[3].'`~'.$val[4].'`~'.$val[6].'`~'.$getexTypOnly['ID'].'`~'.$examSeries;
						}
						$OlevelRst.= $getSubjDet['SubName'].'='.$val[2].';';
						$OlevelRst2.= $getSubjDet['SubId'].'='.$getGDet['ID'].'||';
						}else{
							
							//second sitting
							$checkCombineResult = true;
							$getGradeDetails = $_->Select("olvlgrade_tb","ID","Grade = '".$_->SqlSafe($val[2])."'");
							$getGDet = $getGradeDetails[0]->fetch_assoc();
							$getSubjDetails = $_->Select("olvlsubj_tb","*","(JambOlevelSubject = '".trim($_->SqlSafe($val[1]))."' OR SubName = '".trim($_->SqlSafe($val[1]))."')");
							$getSubjDet = $getSubjDetails[0]->fetch_assoc();
							// $xamTy = str_replace("Only","",$val[5]);//WAEC ONLY
							// $xamTy = $val[5]=="WAEC Only"||$val[5]=="NECO Only"?str_replace("Only","",$val[5]):"NABTEB";
							$xamTy = '';
						switch(trim($val[5])){

							case "WAEC Only":
								$xamTy = "WAEC";
							break;

							case "NECO Only":
								$xamTy = "NECO";
							break;

							case "NABTEB":
								$xamTy = "NABTEB";
							break;

							default:
								$xamTy = "OTHERS";
							break;
						}
							$examTypeOnly = $_->Select("olevelexamtype_tb","ID","Name = '".trim($_->SqlSafe($xamTy))."'");
							$getexTypOnly = $examTypeOnly[0]->fetch_assoc();
							if(strpos($OlevelRstDetails, "###") !== false){
							} else{
								$OlevelRstDetails.= '###'.$val[3].'`~'.$val[4].'`~'.$val[6].'`~'.$getexTypOnly['ID'].'`~'.$examSeries;
							}
							$Olevel2Rst.= $getSubjDet['SubName'].'='.$val[2].';';
							$Olevel2Rst2.= $getSubjDet['SubId'].'='.$getGDet['ID'].'||';
						}
					}
				}else{
					//update DB
					if($Olevel2Rst != ''){
						// insert with second sitting
						$OlevelRst = rtrim($OlevelRst,';');
						$OlevelRst2 = rtrim($OlevelRst2,'||');
						//second det
						$Olevel2Rst = rtrim($Olevel2Rst,';');//this was hard to come by after lots of work 24/10/2021
						$Olevel2Rst2 = rtrim($Olevel2Rst2,'||');
						// combine the two results together
						$OlevelRst = $OlevelRst.'###'.$Olevel2Rst;
						$OlevelRst2 = $OlevelRst2.'###'.$Olevel2Rst2;
						// insert to DB
						
						$rstup = $_->Update("pstudentinfo_tb",["OlevelRstDetails" => "".trim(strtoupper($OlevelRstDetails))."","OlevelRst" => "".trim(strtoupper($OlevelRst))."","OlevelRst2" => "".trim(strtoupper($OlevelRst2)).""],"JambNo = '".trim($holdRegNo)."'");
					}else{
						// insert only first sittings
						$OlevelRst = rtrim($OlevelRst,';');
						$OlevelRst2 = rtrim($OlevelRst2,'||');
						// $jambOlevelDetails[] = [$holdRegNo => $OlevelRst];
						$rstup = $_->Update("pstudentinfo_tb",["OlevelRstDetails" => "".trim(strtoupper($OlevelRstDetails))."","OlevelRst" => "".trim(strtoupper($OlevelRst))."","OlevelRst2" => "".trim(strtoupper($OlevelRst2)).""],"JambNo = '".trim($holdRegNo)."'");
					}
					if($rstup[1] > 0){
						if($OlevelRst == ""){$OlevelRst = $OlevelRstDetails;}
						$jambOlevelDetails[] = [$holdRegNo,$OlevelRst];
						$numOfAffectedRows++;
						$OlevelRstDetails = '';
						$OlevelRst = '';
						$OlevelRst2 = '';
						$Olevel2Rst = '';
						$Olevel2Rst2 = '';
						//pic the fist row of the new reg num and form
						$holdRegNo = $val[0];
						$holdExaminationNUmber = $val[6];
						$checkCombineResult = false;
						if($val[2] == "A/R"){
							$OlevelRstDetails = "AR";
							$OlevelRst = "";
							$OlevelRst2 = "";
							$Olevel2Rst = '';
							$Olevel2Rst2 = '';
						}else{
							$getGradeDetails = $_->Select("olvlgrade_tb","ID","Grade = '".trim($_->SqlSafe($val[2]))."'");
							$getGDet = $getGradeDetails[0]->fetch_assoc();
							$getSubjDetails = $_->Select("olvlsubj_tb","*","(JambOlevelSubject = '".trim($_->SqlSafe($val[1]))."' OR SubName = '".trim($_->SqlSafe($val[1]))."')");
							$getSubjDet = $getSubjDetails[0]->fetch_assoc();
							// $xamTy = $val[5]=="WAEC Only"||$val[5]=="NECO Only"?str_replace("Only","",$val[5]):"NABTEB";
							$xamTy = '';
							switch(trim($val[5])){

								case "WAEC Only":
									$xamTy = "WAEC";
								break;

								case "NECO Only":
									$xamTy = "NECO";
								break;

								case "NABTEB":
									$xamTy = "NABTEB";
								break;

								default:
									$xamTy = "OTHERS";
								break;
							}
							// $xamTy = str_replace("Only","",$val[5]);//WAEC ONLY
							$examTypeOnly = $_->Select("olevelexamtype_tb","ID","Name = '".trim($_->SqlSafe($xamTy))."'");
							$getexTypOnly= $examTypeOnly[0]->fetch_assoc();
							$OlevelRstDetails = $val[3].'`~'.$val[4].'`~'.$val[6].'`~'.$getexTypOnly['ID'].'`~'.$examSeries;
							$OlevelRst.= $getSubjDet['SubName'].'='.$val[2].';';
							$OlevelRst2.= $getSubjDet['SubId'].'='.$getGDet['ID'].'||';
						}
					}else{
						$OlevelRstDetails = '';
						$OlevelRst = '';
						$OlevelRst2 = '';
						$Olevel2Rst = '';
						$Olevel2Rst2 = '';
						$holdRegNo = $val[0];
						$holdExaminationNUmber = $val[6];
						$checkCombineResult = false;
						if($val[2] == "A/R"){
							$OlevelRstDetails = "AR";
							$OlevelRst = "";
							$OlevelRst2 = "";
							$Olevel2Rst = '';
							$Olevel2Rst2 = '';
						}else{
							$getGradeDetails = $_->Select("olvlgrade_tb","ID","Grade = '".trim($_->SqlSafe($val[2]))."'");
							$getGDet = $getGradeDetails[0]->fetch_assoc();
							$getSubjDetails = $_->Select("olvlsubj_tb","*","(JambOlevelSubject = '".trim($_->SqlSafe($val[1]))."' OR SubName = '".$_->SqlSafe($val[1])."')");
							$getSubjDet = $getSubjDetails[0]->fetch_assoc();
							// $xamTy = $val[5]=="WAEC Only"||$val[5]=="NECO Only"?str_replace("Only","",$val[5]):"NABTEB";
							$xamTy = '';
							switch(trim($val[5])){

								case "WAEC Only":
									$xamTy = "WAEC";
								break;

								case "NECO Only":
									$xamTy = "NECO";
								break;

								case "NABTEB":
									$xamTy = "NABTEB";
								break;

								default:
									$xamTy = "OTHERS";
								break;
							}
							// $xamTy = str_replace("Only","",$val[5]);//WAEC ONLY
							$examTypeOnly = $_->Select("olevelexamtype_tb","ID","Name = '".trim($_->SqlSafe($xamTy))."'");
							$getexTypOnly= $examTypeOnly[0]->fetch_assoc();
							$OlevelRstDetails = $val[3].'`~'.$val[4].'`~'.$val[6].'`~'.$getexTypOnly['ID'].'`~'.$examSeries;
							$OlevelRst.= $getSubjDet['SubName'].'='.$val[2].';';
							$OlevelRst2.= $getSubjDet['SubId'].'='.$getGDet['ID'].'||';
						}
						
					}
					
				}
			}
		}
		if($numOfAffectedRows > 0){
			$jambOlevelDetails["numOfAffectedRows"] = $numOfAffectedRows;
			// print_r($jambOlevelDetails);die;
			die(json_encode($jambOlevelDetails));
		}else{
			die("*77");
		}
	}else{
		die('*78');//contact ict
	}
}else{
	die('@!*');//csv format needed
}

?>