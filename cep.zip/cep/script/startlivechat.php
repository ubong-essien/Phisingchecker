<?php
error_reporting(0);
require_once "../engine/Robot.php";
require_once "../engine/sha3encryptdecriptold.php";
$getJall = json_decode($_POST['data']);
$opponentDocPateint = explode('_',$getJall->docID);//here will hold both doc or pat id depending i.e $opponent
$homeDocPatient = explode('_',$getJall->patientID);//here will hold both doc or pat id depending i.e $home
$homeDocPatientPrivilage = explode('_',$getJall->doctPatientPrivilege);//here will hold both doc or pat id depending i.e $home
$rst = $_->Select("chat_tb","*","PatientID = ".trim($_->SqlSafe($homeDocPatient[1]))." AND DoctID = ".$_->SqlSafe($opponentDocPateint[1])." AND Active = 1");
			if($rst[1] > 0){
				$TB = '';
				while($row = $rst[0]->fetch_assoc()){
					if(trim($row['Privilege']) == trim($_->SqlSafe($homeDocPatientPrivilage[1]))){
						// allign text left
						$TB.='<div style="width:70%;position:relative;margin-top:30px;text-align: left;">
						<span style="width:auto;box-shadow:var(--app-box-shadow);background-color:#0a1014;padding:10px;border-top-left-radius: 10px;border-bottom-right-radius: 10px;">'.decryptSH3($row['Message']).'</span></div>
						';
					}else{
						// allign text right
						$TB.='
						<div style="width:auto;position:relative;margin-top:30px;text-align: right;">
							<span style="width:auto;box-shadow:var(--app-box-shadow);background-color:#0a1014;padding:10px;border-top-left-radius: 10px;border-bottom-right-radius: 10px;">
							'.decryptSH3($row['Message']).'
							</span>
						</div>
						';
					}
				}
				echo $TB;
			}
?>