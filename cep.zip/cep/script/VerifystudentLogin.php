<?php
require_once('functions/function.php');
$con = connect();
$settings = Loadsettings($con);
$ty = json_decode($_POST['verifyCredentials'],true);
$ses = $settings['Ses'];
$sem =  $settings['Sem'];
//check if status is > 2, log out the user
$errorCode = [
    "D##" => "YOUR DEPARTMENT IS NOT ALLOWED FOR THIS EXAMS",
    "R###" => "YOU HAVE NOT REGISTERED FOR THIS EXAMS",
    "OK##" => "SUCCESS"
];

/*************************************************CHECK STUDENT LOGIN************************* */
        $user = $ty['username'];
        $pass = $ty['pass'];
        $login_user=chkstudentlogin($user,$pass,$con);
        if(!isset($_SESSION['res_user']) || empty($_SESSION['res_user'])){die(json_encode(["ERROR" => ["Message" => "INVALID REGISTRATION OR ACCESS CODE"]]));}

/****************************************fetch the student recoed**************************/
$Stud = getdatabyreg($login_user,$con);
$dpt = $Stud['ProgID'];
$SurName = $Stud['SurName'];
$Firstame = $Stud['FirstName'];
$OtherName = $Stud['OtherNames'];
$Passport = $Stud['Passport'];

$Stud_name = $SurName.", ".$Firstame." ".$OtherName;
/*******************************fetch course registration for the current semester and session******************************/
$listofcourses = getstudcoursereg($con,$login_user,$ses,$sem); 
//get active exams
/******************************GET ACTIVE EXAMS********************** */
$ex_array = getActiveExams($con);
$exmascoursesid = $ex_array['Exams_courses_id'];
$allowd_dpt = $ex_array['depts'];
$course_grp_id = $ex_array['course_grp_id'];
$No_of_Q = $ex_array['No_of_Q'];
$exams_details = $ex_array['ExamsDetails'];
$exams_duration = $ex_array['duration'];
//
$ex_det = explode('|',$exams_details);


$Ex_id = $ex_array['id'];
/******************************CHECK IF STUDENT DEPT IS ALLOWED TO WRITE EXAMS */
//check if department of student is allowed to take the exams
$can_write = dept_can_write($dpt,$allowd_dpt);//returns true of false

/******************************CHECK IF STUDENT HAS REGISTERED FOR THE EXAMS */

// check if the student has registered for the exams
$reg_status = has_registered($exmascoursesid,$listofcourses['CoursesID']);//returns true or false

/***************************CHECK ELIGIBILITY ********************/
$error_status = '@';//initialize

if($can_write != true){
    $error_status = 'D##';
}else if($reg_status != '#OK#'){
    $error_status = 'R###';
}else{
    $error_status = 'OK##';
}
// if($error_status == 'D##'){die(json_encode(["ERROR" => ["Message" => $errorCode['D##']]]));}
// if($error_status == 'R###'){die(json_encode(["ERROR" => ["Message" => $errorCode['R###']]]));}
$details = array(
    'Name' => $Stud_name,
    'ProgID' => $dpt,
    'ProgName' => GetProgDetails($dpt,$con),
    'Lvl'=> $listofcourses['Lvl'],
    'RegNo' => $login_user,
    'exams_id' => $Ex_id,
    'CourseCode' => $ex_det[0],
    'CourseTitle' => $ex_det[1],
    'Duration' => $exams_duration,
    'course_grp'=> $course_grp_id,
    'eligible' => $error_status,
    'Passport' => $Passport,
    'ExamName' => $ex_det[1]
);
$_SESSION['exams_details_ses']  = $details;
die(json_encode(["SUCCESS" => ["Message" => $details]]));
?>
