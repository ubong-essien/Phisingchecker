<?php
require_once "../engine/Robot.php";
$getJall = json_decode($_POST['data']);
$JAMBNO = trim($_->SqlSafe($getJall->JAMBNO));
$CNAME = trim($_->SqlSafe($getJall->CNAME));
$GENDER = trim($_->SqlSafe($getJall->GENDER));
$STATE = trim($_->SqlSafe($getJall->STATE));
$LGA = trim($_->SqlSafe($getJall->LGA));
$JAMBSCOR = trim((int)$_->SqlSafe($getJall->JAMBSCOR));
$COURSE = trim($_->SqlSafe($getJall->COURSE));
$SUBJ1 = trim($_->SqlSafe($getJall->SUBJ1));
$SCORE1 = trim($_->SqlSafe($getJall->SCORE1));
$SUBJ2 = trim($_->SqlSafe($getJall->SUBJ2));
$SCOR2 = trim($_->SqlSafe($getJall->SCOR2));
$SUBJ3 = trim($_->SqlSafe($getJall->SUBJ3));
$SCOR3 = trim($_->SqlSafe($getJall->SCOR3));
$SCOR4 = trim($_->SqlSafe($getJall->SCOR4));
//explode name
$CNAME = explode(' ',$CNAME);
if(empty($CNAME[2])){$CNAME[2] = "";}
//getStateID
$rst = $_->Select("state_tb","StateID","StateName = '".$STATE."'");
$getStID = $rst[0]->fetch_assoc();
$StateID = $getStID['StateID'];
//get subj1
$getsessDetails1 = $_->Select("olvlsubj_tb","SubId","JambSubName = '$SUBJ1'");
$getSest1 = $getsessDetails1[0]->fetch_assoc();
$subject11 = $getSest1['SubId'];
//get subj2
$getsessDetails2 = $_->Select("olvlsubj_tb","SubId","JambSubName = '$SUBJ2'");
$getSest2 = $getsessDetails2[0]->fetch_assoc();
$subject12 = $getSest2['SubId'];
//get subj3
$getsessDetails3 = $_->Select("olvlsubj_tb","SubId","JambSubName = '$SUBJ3'");
$getSest3 = $getsessDetails3[0]->fetch_assoc();
$subject13 = $getSest3['SubId'];
$subjctCombi = "1~$subject11~$subject12~$subject13";
//get programID
$getsessProID = $_->Select("programme_tb","ProgID","JambDeptName = '$COURSE'");
$ProgID1 = $getsessProID[0]->fetch_assoc();
$ProgID = $ProgID1['ProgID'];
//get startsssion
$getMax = $_->Select("session_tb","SesID","Current = 1");
$sesID = $getMax[0]->fetch_assoc();
// check if candidate exist
//dept 
if($COURSE == "Information & Communication Technology"){$ProgID = 28;}
if($COURSE == "Oceanography"){$ProgID = 33;}
if($COURSE == "Geoscience" || $COURSE == "Applied Geophysics" || $COURSE == "Geosciences"){$ProgID = 29;}
//By director's directive
if($COURSE == "Biological Science(S)"){$ProgID = 25;}
if($COURSE == "Petroleum Engineering"){$ProgID = 17;}
// cjeck if canddita has been inserted in student info tb
$getExistStudntInfo = $_->Select("studentinfo_tb","id","JambNo = '".$JAMBNO."'");
if($getExistStudntInfo[1] > 0){
	$rstupStuInfo = $_->Update("studentinfo_tb",["ProgID" => $ProgID],"JambNo = '".$JAMBNO."'");
	$delAll = $_->Delete("pstudentinfo_tb","JambNo = '".$JAMBNO."'");
	die("*2");//already exist
}
// can already exist
$getExistJamno = $_->Select("pstudentinfo_tb","id","JambNo = '".$JAMBNO."'");
if($getExistJamno[1] > 0){
    // $rstup = $_->Update("pstudentinfo_tb",["ProgID" => $ProgID,"JmbComb" => "".$subjctCombi.""],"JambNo = '".$JAMBNO."'");
	$rstup = $_->Update("pstudentinfo_tb",["ProgID" => $ProgID,"JmbComb" => "".$subjctCombi."","FirstName" => $CNAME[1],"OtherNames" => $CNAME[2]],"JambNo = '".$JAMBNO."'");
	die("*2");//already exist	
}else{
	$egtR = $_->Insert("pstudentinfo_tb",["SurName" =>  $CNAME[0],"FirstName" => $CNAME[1],"OtherNames" => $CNAME[2],"DOB" => "2020-08-09","JambNo" => $JAMBNO,"StateId" => $StateID,"LGA" => $LGA,"Passport" => '',"Gender" => $GENDER,"Phone" => '',"Email" => '',"Addrs" => '',"StartSes" => trim($_->SqlSafe($sesID['SesID'])),"ModeOfEntry" => 1,"RegDate" => '2020-08-09',"JambAgg" => $JAMBSCOR,"OlevelRstDetails" => '',"OlevelRst" => '',"RegLevel" => 0,"ProgID" => trim($_->SqlSafe($ProgID)),"StudyID" => 5,"RegID" => 1,"JmbComb" => trim($subjctCombi),"MaritalStatus" => '',"Nationality" => "","Tribe" => '',"Religion" => '',"Language" => '',"Hobbies" => '',"SponsorName" => "","SponsorAddrs" => '',"SponsorPhone" => '',"NName" => '',"NAddrs" => '',"Nphone" => '',"NEmail" => '',"Relationship" => '',"AdminDate" => '2020-08-09',"OlevelRstDetails" => '',"OlevelRst" => '',"OlevelRst2" => '',"OtherCert" => '',"SeatNo" => '',"Title" => '',"RegNo" => '',"PUTMECombID" => '',"VenueID" => '',"admitted" => 0]);
	if($egtR[1] > 0){
		die('*|3');//inserted
	}else{
		die('|@');//error
	}
}
?>