<?php
require_once "../engine/Robot.php";
	$getcanName = $_->Select("pstudentinfo_tb","CONCAT(SurName,' ',FirstName,' ',OtherNames) AS Name","JambNo = '".trim($_->SqlSafe($_POST['jambbite']))."'");
	if($getcanName[0]->num_rows > 0){
		$rows = $getcanName[0]->fetch_assoc();
		die($rows['Name']);
	}else{
		die('*3');
	}
?>