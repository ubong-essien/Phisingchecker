<?php
// sleep(1);
$mimeType = array("text/csv","application/vnd.ms-excel","text/plain","text/tsv");
if(in_array($_FILES['file1']['type'],$mimeType)){
$handle = fopen($_FILES['file1']['tmp_name'], "r");
// $headers = fgetcsv($handle, 1000, ",");
$data = fgetcsv($handle, 1000, ",");
$getArr = array();
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE){
	if(strlen($data[0]) < 10){die('*78');}
    $getArr[] = ["JAMBNO" => $data[0],"CNAME" => $data[1],"GENDER" => $data[2],"STATE" => $data[3],"LGA" => $data[5],"COURSE" => $data[4]];//2021
    // $getArr[] = ["JAMBNO" => $data[1],"CNAME" => $data[2],"GENDER" => $data[3],"STATE" => $data[4],"LGA" => $data[6],"COURSE" => $data[5]];2020
}
fclose($handle);
if(count($getArr) > 0){
	die(json_encode($getArr));
}else{
	die('*78');//contact ict
}
}else{
	die('@!*');//csv format needed
}
?>