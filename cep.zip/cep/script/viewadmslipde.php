<?php
require_once "../engine/Robot.php";
require_once "../engine/Roboti.php";
$getJall = json_decode($_POST['data']);
$pr_ID = $_->SqlSafe($getJall->v_list);
$pr_ID = explode('_',$pr_ID);
$pr_ID = $pr_ID[1];
			$gtrecom2 = $_->Select("admissionlog_tb","JambNo,ProgID","ProgID = '$pr_ID' AND ModeOfEntry IN(2,3,0)");
			if($gtrecom2[1] > 0){
				$Assdarry = array();
				while($rows = $gtrecom2[0]->fetch_assoc()){
					$Assdarry[] = ["jambNo" => $rows['JambNo'],"ProgID" => $rows['ProgID']];
				}
				$cnt = 1;
				$cnt_1 = 0;
				$outputTB = "<table  class=' w3-white' style=\"width:99.9%!important\"><thead><tr class='spt-newap-light-grey'><th class='w3-lightgrey'>S/N</th><th>JAMBNO</th><th>SURNAME</th><th>FIRSTNAME</th><th>OTHERNAMES</th><th>L.G.A</th></tr></thead>
				";
				foreach($Assdarry as $val){
					$getPstuinf = $_P->Select("pstudentinfo_tb","SurName,FirstName,OtherNames,Gender,JambAgg,LGA","JambNo = '".$val['jambNo']."' ORDER BY JambAgg DESC");
					if($getPstuinf){
						$getPrgName = $_P->Select("programme_tb","ProgName","ProgID = '".$val['ProgID']."'");
						if($getPrgName[1] > 0){
							$getPIND = $getPstuinf[0]->fetch_assoc();
							$getPName = $getPrgName[0]->fetch_assoc();
							$getPIND['SurName'] = rtrim($getPIND['SurName'],',');
							$outputTB.="<tr style='animation:tablerow 0.5s ease-in-out '.$cnt_1.'s; opacity:0; animation-fill-mode:forwards'><td class='w3-light-grey'>".$cnt."</td><td>".$val['jambNo']."</td><td>".$getPIND['SurName']."</td><td>".$getPIND['FirstName']."</td><td>".$getPIND['OtherNames']."</td><td>".$getPIND['LGA']."</td></tr>";
							// $arrInd2[] = $cnt;
							
						}
					}
					$cnt++;
					$cnt_1 += 0.4;
				}
				$outputTB.="</table>";
				echo $outputTB;
			}else{
				die('<h1 class="w3-center">NO CANDIDATES FOUND</h1>');
			}
?>