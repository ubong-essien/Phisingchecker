
<?php
require_once "../engine/Robot.php";
if(isset($_POST['jam_bN'])){
	$egtR = $_->Update("admissionlog_tb",["Sent"=>1],"JambNo = '".$_POST['jam_bN']."'");
	if($egtR){
		die('updated');
	}
}
?>
