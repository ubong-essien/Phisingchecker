<?php
require_once "../engine/Robot.php";
require_once "errormsg.php";
$getJall = json_decode($_POST['data']);
$getstate = explode("_", $getJall->getstate);
$dept = explode("_", $getJall->getDpet);
$CNAMEsur = $_->SqlSafe($getJall->tel_sur_name);
$CNAMEFir = $_->SqlSafe($getJall->tel_fn_name);
$CNAMEOther = $_->SqlSafe($getJall->tel_othr_names);
$SUBJ1 = $_->SqlSafe($getJall->Subject1__);
$SUBJ2 = $_->SqlSafe($getJall->Subject2__);
$SUBJ3 = $_->SqlSafe($getJall->Subject3__);
$SUBJ4 = $_->SqlSafe($getJall->Subject4__);
$SUBJ1 = explode('_',$SUBJ1);
$SUBJ2 = explode('_',$SUBJ2);
$SUBJ3 = explode('_',$SUBJ3);
$SUBJ4 = explode('_',$SUBJ4);
// session
$sesID = $_->Select("session_tb","SesID","Current = 1");
$sesIDRow = $sesID[0]->fetch_assoc();
if(!$sesID[1] > 0){die($errorCode['R03']);}
// cjeck if canddita has been inserted in student info tb
$getExistStudntInfo = $_->Select("studentinfo_tb","id","JambNo = '".trim($_->SqlSafe($getJall->tel_jam_number))."'");
if($getExistStudntInfo[1] > 0){
	$rstupStuInfo = $_->Update("studentinfo_tb",["ProgID" => "".trim($_->SqlSafe($dept[1])).""],"JambNo = '".trim($_->SqlSafe($getJall->tel_jam_number))."'");
	$delAll = $_->Delete("pstudentinfo_tb","JambNo = '".trim($_->SqlSafe($getJall->tel_jam_number))."'");
	die($errorCode['R21']);
}
$subjctCombi = '';
if( $SUBJ1[1] != "" || $SUBJ2[1] != "" || $SUBJ3[1] != $SUBJ4[1]){
	$subjctCombi = $SUBJ1[1].'~'.$SUBJ2[1].'~'.$SUBJ3[1].'~'.$SUBJ4[1];
}
// can already exist
$getExistJamno = $_->Select("pstudentinfo_tb","id","JambNo = '".trim($_->SqlSafe($getJall->tel_jam_number))."'");
if($getExistJamno[1] > 0){
	$rstup = $_->Update("pstudentinfo_tb",["ProgID" => trim($_->SqlSafe($dept[1])),"JmbComb" => $subjctCombi],"JambNo = '".trim($_->SqlSafe($getJall->tel_jam_number))."'");
	if($rstup[1] > 0){
		die($errorCode['R21']);//already exist
	}
	
}else{
	$regID = null;
	if($getJall->tel_modentry == 1){
		$regID = 1;
	}elseif($getJall->tel_modentry == 2){
		$regID = 2;
	}else{
		$regID = 3;
	}
	// echo trim($_->SqlSafe($sesIDRow['SesID']));
	// die;
	$getstifR = $_->Insert("pstudentinfo_tb",["SurName" =>  $CNAMEsur,"FirstName" => $CNAMEFir,"OtherNames" => $CNAMEOther,"DOB" => trim($_->SqlSafe($getJall->adm__DoB)),"JambNo" => "".trim($_->SqlSafe($getJall->tel_jam_number))."","StateId" => $getstate[1],"LGA" => trim($_->SqlSafe($getJall->getLGA)),"Passport" => '',"Gender" => "".trim($_->SqlSafe($getJall->tel_Gender))."","Phone" => '',"Email" => '',"Addrs" => '',"StartSes" => trim($_->SqlSafe($sesIDRow['SesID'])),"ModeOfEntry" => "".trim($_->SqlSafe($getJall->tel_modentry))."","RegDate" => '2020-08-09',"JambAgg" => "".trim($_->SqlSafe($getJall->tel_jambScor))."","OlevelRstDetails" => '',"OlevelRst" => '',"RegLevel" => 0,"ProgID" => trim($_->SqlSafe($dept[1])),"StudyID" => 5,"RegID" => $regID,"JmbComb" => trim($subjctCombi),"MaritalStatus" => '',"Nationality" => "".trim($_->SqlSafe($getJall->getNationality))."","Tribe" => '',"Religion" => '',"Language" => '',"Hobbies" => '',"SponsorName" => "","SponsorAddrs" => '',"SponsorPhone" => '',"NName" => '',"NAddrs" => '',"Nphone" => '',"NEmail" => '',"Relationship" => '',"AdminDate" => '2020-08-09',"OlevelRstDetails" => '',"OlevelRst" => '',"OlevelRst2" => '',"OtherCert" => '',"SeatNo" => '',"Title" => '',"RegNo" => '',"PUTMECombID" => '',"VenueID" => '',"admitted" => 0]);
	if($getstifR[1] > 0){
		$SUBJ1[1] = "";
		$SUBJ2[1] = "";
		$SUBJ3[1] = "";
		$SUBJ4[1] = "";
		die($errorCode['R23']);//inserted
	}else{
		die($errorCode['R03']);//error
	}
}
?>