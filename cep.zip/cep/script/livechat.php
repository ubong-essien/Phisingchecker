<?php
error_reporting(0);
require_once "../engine/Robot.php";
require_once "../engine/sha3encryptdecriptold.php";
$getJall = json_decode($_POST['data']);
$hashMessage = trim($_->SqlSafe($getJall->tel_chat_id));
$hashMessage = encryptSH3($hashMessage);//hash the description
$gtJorCat = $_->Insert("chat_tb",["PatientID" => trim($_->SqlSafe($getJall->home)),"DoctID" => "".$_->SqlSafe($getJall->opponent)."","Privilege" => trim($_->SqlSafe($getJall->privilege)),"Message" => $hashMessage]);
		if($gtJorCat[1] > 0){
			$rst = $_->Select("chat_tb","*","PatientID = ".trim($_->SqlSafe($getJall->home))." AND DoctID = ".$_->SqlSafe($getJall->opponent)." AND Active = 1");
			if($rst[1] > 0){
				$TB = '';
				while($row = $rst[0]->fetch_assoc()){
					if(trim($row['Privilege']) == trim($_->SqlSafe($getJall->privilege))){
						// allign text left
						$TB.='<div style="width:70%;position:relative;margin-top:30px;text-align: left;">
						<span style="width:auto;box-shadow:var(--app-box-shadow);background-color:#0a1014;padding:10px;border-top-left-radius: 10px;border-bottom-right-radius: 10px;">'.decryptSH3($row['Message']).'</span></div>
						';
					}else{
						// allign text right
						$TB.='
						<div style="width:auto;position:relative;margin-top:30px;text-align: right;">
							<span style="width:auto;box-shadow:var(--app-box-shadow);background-color:#0a1014;padding:10px;border-top-left-radius: 10px;border-bottom-right-radius: 10px;">
							'.decryptSH3($row['Message']).'
							</span>
						</div>
						';
					}
				}
				echo $TB;
			}
		}
?>