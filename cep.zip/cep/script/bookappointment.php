<?php
error_reporting(0);
require_once "../engine/Robot.php";
require_once "../engine/sha3encryptdecriptold.php";
$getJall = json_decode($_POST['data']);
// strings to hash
$illnessDestring = trim($_->SqlSafe($getJall->tel_doc_illness));//Descript the illness
$patientDoctorMeetingTime = trim($_->SqlSafe($getJall->tel_doc_timetomdoc));//meeting time with Doctor
$illnessDescriptionStringHash = encryptSH3($illnessDestring);//hash the description
$patientDoctorMeetingTimeHash = encryptSH3($patientDoctorMeetingTime);//hash the time
// insert appointment into DB
$gtJorCat = $_->Insert("patientappointment_db",["DoctorID" => trim($_->SqlSafe($getJall->tel_docName)),"VisitedDoctor" => "".$_->SqlSafe($getJall->tel_doc_visited)."","StudentStaff" => "".$_->SqlSafe($getJall->tel_doc_stafstudent)."","VisitReasons" => "".$_->SqlSafe($getJall->tel_doc_reasons)."","AppointmentFor" => trim($_->SqlSafe($getJall->tel_doc_appointmnt)),"ScheduleName" => "".$_->SqlSafe($getJall->tel_doc_schedulname)."","AppointmentTime" => "".$patientDoctorMeetingTimeHash."","Description" => "".$illnessDescriptionStringHash."","AppointmentDate" => "".date("Y-m-d")."","PatientID" => trim($_->SqlSafe($getJall->holdStafID))]);
		if($gtJorCat[1] > 0){
			die('1');
		}
?>