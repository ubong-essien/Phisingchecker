<?php
// die(json_encode(["SUCCESS" => ["Message" => "ui/ajax/cep/pages/academicdetails.php","menuHeaderTitle" => "ACADEMIC DETAILS"]]));
print_r($_POST);
?>