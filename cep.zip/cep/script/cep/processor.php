<?php
die(json_encode(["SUCCESS" => ["Message" => "ui/ajax/cep/pages/verifyrefnumbers.php","menuHeaderTitle" => "VERIFY NUMBERS"]]));
print_r($_POST);
?>