<?php
die(json_encode(["SUCCESS" => ["Message" => "ui/ajax/cep/pages/contactinfo.php","menuHeaderTitle" => "CONTACT INFORMATION"]]));
print_r($_POST);
?>