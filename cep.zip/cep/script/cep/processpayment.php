<?php
// die(json_encode(["SUCCESS" => ["Message" => "ui/ajax/cep/pages/paymentoption.php","menuHeaderTitle" => "Make Payment"]]));
print_r($_POST);
?>