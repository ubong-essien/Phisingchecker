<?php
require_once "../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
$rst = $_->Select("lga_tb","*","StateID = ".trim($_->SqlSafe($getJsonFile->cep__statID))."");
$TB = '<option value="" disabled selected>LGA</option>';
if($rst[1] > 0){
    while($row = $rst[0]->fetch_assoc()){
        $TB.='<option value="'.$row["LGAID"].'">'.strtoupper($row["LGAName"]).'</option>';
    }
}
die(json_encode(["SUCCESS" => ["Message" => $TB]]));
?>