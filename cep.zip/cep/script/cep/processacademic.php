<?php
die(json_encode(["SUCCESS" => ["Message" => "ui/ajax/cep/pages/finish.php","menuHeaderTitle" => "Registration Completed"]]));
// print_r($_POST);
?>