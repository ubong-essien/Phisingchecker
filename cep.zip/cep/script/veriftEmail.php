<?php
	require_once "../engine/Robot.php";
	$d_username = trim($_->SqlSafe($_POST['d_userD']));
	$getCours = $_->Select("studentinfo_tb","CONCAT(SurName,' ',FirstName,' ',OtherNames) as Name,Passport","JambNo = '".$d_username."' OR RegNo = '".$d_username."'");
	if($getCours[1] > 0){
		$rows = $getCours[0]->fetch_assoc();
		die($rows['Name'].'~'.$rows['Passport'].'~'.'<div class="come-in-left-slow" style="position: relative;z-index:1;"><div onclick="window.location=\'index.php\';" title="RELOAD" class="cor-column cor-text-col-bgr cor-text1-shaow " style="width:10%;height:30px;border:none;outline:none;border-top-left-radius:5px;cursor:pointer;">x</div>
		<div class="cor-column" style="width:80%;">
			<div style="width: 100%;"><input id="getPawrd" type="password" placeholder="Password" style="width: 98%;margin:auto;height:30px;border:none;outline:none;"></div>
		</div>
		<div onclick="Telemedicine.Login.verifyPasswrd()" title="SUBMIT" class="cor-column cor-text-col-bgr w3-display-container" style="width:10%;height:30px;border:none;outline:none;border-top-right-radius:5px;cursor:pointer;">
			<div id="showHCP" class="w3-display-middle"><i class="fa fa-angle-right cor-text1-shaow "></i></div>
			<div id="hideCSpnP" class="w3-display-middle" style="display: none;"><i class="fa fa-cog fa-spin cor-text1-shaow " ></i></div>
		</div></div>
		<div class="come-in-txt-right">
			<button onclick="Telemedicine.Login.verifyPasswrd();//__I.LoginDoorOpen(\'doorleft\',\'doorright\',\'exitSubLogin\')" title="SUBMIT" class="w3-button cor-text-col-bgr cor-text1-shaow" style="width: 100%;padding:3px;margin-top:1.5px;border-bottom-right-radius:5px;border-bottom-left-radius:5px;"><small>SUBMIT</small></button>
		</div>');
	}else{
		die('*3');
	}
?>