<?php
session_start();
require_once "../engine/Robot.php";
require_once "../engine/Roboti.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$getJall = json_decode($_POST['data']);
	// session
	$sesID = $_->Select("session_tb","SesID","Current = 1");
	$sesIDRow = $sesID[0]->fetch_assoc();
	$getReG = 	$getJall->RegNum;//reg num
	$getNewDept = $getJall->DEPT;//dept
	// check if canddita has been inserted in student info tb
	$getExistStudntInfo = $_->Select("studentinfo_tb","id","JambNo = '".trim($_->SqlSafe($getReG))."'");
	if($getExistStudntInfo[1] > 0){
		$getDEPTName = $_->Select("programme_tb","ProgID","(JambDeptName = '".trim($_->SqlSafe($getNewDept))."' OR ProgName = '".trim($_->SqlSafe($getNewDept))."')");
		if($getDEPTName[1] > 0){$rowNewDEpt = $getDEPTName[0]->fetch_assoc();}
		$rstupStuInfo = $_->Update("studentinfo_tb",["ProgID" => trim($_->SqlSafe($rowNewDEpt['ProgID'])),"StartSes" => trim($_->SqlSafe($sesIDRow['SesID']))],"JambNo = '".trim($_->SqlSafe($getReG))."'");
		die('*||');//admited aleady
	}
	//select the student from pstudent info if the student exist
	$getPstuinf = $_->Select("pstudentinfo_tb","*","JambNo = '".trim($_->SqlSafe($getReG))."'");
	//if exist
	if($getPstuinf[1] > 0){
		$rows = $getPstuinf[0]->fetch_assoc();
		//select new dept from JampDept
		$getDEPTName = $_->Select("programme_tb","ProgID","(JambDeptName = '".trim($_->SqlSafe($getNewDept))."' OR ProgName = '".trim($_->SqlSafe($getNewDept))."')");
		if($getDEPTName[1] > 0){$rowNewDEpt = $getDEPTName[0]->fetch_assoc();}
		//check if candidate has been admitted already
		$getAdmitdAlad = $_->Select("pstudentinfo_tb",'id',"JambNo = '".trim($_->SqlSafe($getReG))."' AND admitted = 1");
		if($getAdmitdAlad[1] > 0){
			$getUpProID = $_->Update("pstudentinfo_tb",["ProgID" => trim($_->SqlSafe($rowNewDEpt['ProgID'])),"StartSes" => trim($_->SqlSafe($sesIDRow['SesID']))],"JambNo = '".trim($_->SqlSafe($getReG))."'");
			if($getUpProID[1] > 0){
					$getUpSupalist = $_P->Update("supadmlist",["ProgID" => "".$_P->SqlSafe($rowNewDEpt['ProgID']).""],"JambNo = '".trim($_P->SqlSafe($getReG))."'");
					if($getUpSupalist){
						die('*||');//admited aleady
					}
			}else{
			    die('*||');//admited aleady
			}
		}else{
			/* Start transaction */
			$_->beginTransaction();
			try{
			//turn admitted from 0 to 1 in pstudentinfo_tb
			$rstUp = $_->Update("pstudentinfo_tb",["ProgID" => trim($_->SqlSafe($rowNewDEpt['ProgID'])),"admitted" => 1,"StartSes" => trim($_->SqlSafe($sesIDRow['SesID']))],"JambNo = '".trim($_->SqlSafe($getReG))."'");
			if(!$rstUp[1] > 0){die('@*|~');}
			//insert into superadmin
			$rstSup = $_P->Insert("supadmlist",["Surname" => trim($_->SqlSafe($rows['SurName'])),"FirstName" => trim($_->SqlSafe($rows['FirstName'])),"OtherNames" => trim($_->SqlSafe($rows['OtherNames'])),"JambNo" => trim($_->SqlSafe($rows['JambNo'])),"cangender" => trim($_->SqlSafe($rows['Gender'])),"ProgID" => trim($_->SqlSafe($rowNewDEpt['ProgID'])),"ModeOfEntry" => trim($_->SqlSafe($rows['ModeOfEntry']))]);
			if(!$rstSup[1] > 0){die('@*|~');}
			//insert into admissionlog_log
			$restAdm = $_->Insert("admissionlog_tb",["JambNo" => addslashes($rows['JambNo']),"ProgID" => addslashes($rowNewDEpt['ProgID']),"ModeOfEntry" => addslashes($rows['ModeOfEntry']),"PhoneNo" => $rows['Phone'],"AdmitedBy" => $_SESSION['idd'],"Sent" => 0,"SessID" => trim($_->SqlSafe($sesIDRow['SesID']))]);
			if(!$restAdm[1] > 0){die('@*|~');}
			// insert into activitylog_tb
			$rstAct = $_->Insert("activitylog_tb",["Details" => "Admin ".$_SESSION['idd']." admitted ".$_P->SqlSafe($getReG)."","Admin_id" => $_SESSION['idd'],"JambNo" => "".$_->SqlSafe($getReG).""]);
			if(!$rstAct > 0){die('@*|~');}
			$_->commitTransaction();
			die("~");
			}catch(Exception $e){
				$_->rollbackTransaction();
				die('@*|~');
			}
		}
	}else{
		
			$getAdmitdAlad1 = $_->Select("invalidcand_tb",'',"JambNo = '".$_->SqlSafe($getReG)."'");
			if($getAdmitdAlad1[1] > 0){}else{
				$getActlog = $_->Insert("invalidcand_tb",["JambNo" => $_->SqlSafe($getReG)]); 
			}
			die('@*|~');//return as invalid can
	}
	
}
?>
