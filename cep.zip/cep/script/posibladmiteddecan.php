<?php
require_once "../engine/Roboti.php";
$getJall = json_decode($_POST['data']);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$getR_r = $_P->Select("recommendation_tb r,programme_tb m,pstudentinfo_tb p","r.RegNo,m.ProgName,p.LGA,p.SurName,p.FirstName,p.OtherNames","r.RegNo LIKE '%".trim($_P->SqlSafe($getJall->toAjxCntr))."%' AND (r.ModeOfEntry = 2 OR r.ModeOfEntry = 3) AND r.RegNo = p.JambNo AND p.ProgID = m.ProgID AND r.AdmitStatus = 0 AND r.final_status = 1");
		if($getR_r[1] > 0){
			$cnt_1 = 0;
			$oupTB =<<<_E
			<ul class="w3-center"><li class="cor-border-bottom" style='animation:tablerow 0.5s ease-in-out '.$cnt_1.'s; opacity:0; animation-fill-mode:forwards'>
			<div class="w3-row ">
				<div class="w3-col s2 cor-text1-shaow spt-header-smr">RegNo</div>
				<div class="w3-col s4 cor-text1-shaow spt-header-smr">Name</div>
				<div class="w3-col s3 cor-text1-shaow spt-header-smr">Dept</div>
				<div class="w3-col s2 cor-text1-shaow spt-header-smr">L.G.A</div>
				<div class="w3-col s1 cor-text1-shaow spt-header-smr">Action</div>
			</div>
		</li>
_E;
			while($row = $getR_r[0]->fetch_assoc()){
				$Re_g = trim($row['RegNo']);
				$RegNo = trim($row['RegNo']);
				$ProgName = $row['ProgName'];//08066559566
				$LGA = $row['LGA'];//Enefiok ucfirst() 
				$row['SurName'] = rtrim($row['SurName'],',');
				$row['FirstName'] = rtrim($row['FirstName'],',');
				$row['OtherNames'] = rtrim($row['OtherNames'],',');
				$fulname = $row['SurName'].", ".$row['FirstName']." ".$row['OtherNames'];
				$RegNo = str_replace(ucfirst($getJall->toAjxCntr),'<span style="color: rgba(255, 0, 0, 0.712);">'.ucfirst($getJall->toAjxCntr)."</span>",$RegNo);
				$oupTB.=<<<_E
				<li id="li_id_$Re_g"  class="cor-border-bottom rep-bgr-hover cor-ul-fix cor-pointer cor-fadein-cnt" style='animation:tablerow 0.5s ease-in-out '.$cnt_1.'s; opacity:0; animation-fill-mode:forwards;'>
					<div class="w3-row">
						<div class="w3-col s2 cor-text1-shaow cor-header-smr spt-header-smr">$RegNo</div>
						<div class="w3-col s4 cor-text1-shaow cor-header-smr spt-header-smr">$fulname</div>
						<div class="w3-col s3 cor-text1-shaow cor-header-smr spt-header-smr">$ProgName</div>
						<div class="w3-col s2 cor-text1-shaow cor-header-smr spt-header-smr">$LGA</div>
						<div onclick="GEN.Admin.contrAdAction('$Re_g')" class="w3-col s1 cor-text1-shaow cor-header-smr spt-header-smr cor-pointer"><i class="fas fa-ellipsis-h"></i></div>
						<div id="dr_$Re_g" class="w3-black w3-card-4 cor-fadein-cnt yrt-tyr" style="position:absolute;right:0;width:100px;height:43px;z-index:3;margin-top:-12px;display:none;">
								<div class="cor-row " style="height:21.5px;">
									<div title="ADMIT CANDIDATE" id="btn121DE_$Re_g" onclick="GEN.Admin.admissions.admitC('btn121DE_$Re_g','ad_can_dt_$Re_g','li_id_$Re_g')" class="cor-column w3-center " style="width:50%;">
										<div id="ad_can_dt_$Re_g" class="w3-green w3-round cor-pointer w3-display-container " style="width:40px;margin:auto;height:20px;"><small><i class="fas fa-check w3-display-middle"></i></small></div>
									</div>
									<div title="REMOVE CANDIDATE" onclick="GEN.Admin.admissions.undo('btn121DE_$Re_g','del_cd_$Re_g','li_id_$Re_g','ad_can_dt_$Re_g')" class="cor-column w3-center " style="width:50%;">
										<div id="del_cd_$Re_g" class="w3-red w3-round cor-pointer w3-display-container " style="width:40px;margin:auto;height:20px;"><small><span class="fa fa-ban w3-display-middle"></span></small></div>
									</div>
								</div>
								<div title="Closs" onclick="this.parentElement.style.display='none'" style="height:21.5px;">
									<div class=" cor-pointer w3-display-container " style="width:18px;margin:auto;height:18px;border-radius:50%;"><small><span class="fa fa-times w3-display-middle"></span></small></div>
								</div>
						</div>
					</div>
				</li>
_E;

				
$cnt_1 += 0.4;
		}
		$oupTB.='</ul';
		echo $oupTB;
	}
}
?>
