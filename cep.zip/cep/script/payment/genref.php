<?php
sleep(1);
require_once "../engine/Robot.php";
require_once "../script/errormsg.php";
$rObj = json_decode($_POST['data']);
$rst = $_->Select("cstudentinfo_tb s,programme_tb p,dept_tb d,fac_tb f","CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as Name,s.Email,s.Phone,s.Passport,s.StartSes,s.ModeOfEntry,s.StudyID,p.ProgName,p.DeptID,d.DeptName,p.ProgID as progID,f.FacID,f.FacName","s.RegNo = '".trim($_->SqlSafe($rObj->__recT))."' AND s.ProgID = p.ProgID AND p.DeptID = d.DeptID AND d.FacID = f.FacID");
$explod = explode('_',$rObj->__modula);
$rstModule = $_->Select("item_tb","*","ModuleID = ".trim($_->SqlSafe($explod[1]))."");
if($rst[1] > 0){
    $row = $rst[0]->fetch_assoc();
    $rowMo = $rstModule[0]->fetch_assoc();
    $holdJsonArr = [];
    $genTenNo = null;
    $gen22No = null;
    // check if he has applied b4
    $rstAppliedr = $_->Select("applications_tb","ID","RegNo = '".trim($_->SqlSafe($rObj->__recT))."' AND ModuleID = ".trim($_->SqlSafe($explod[1]))."");
    if($rstAppliedr[1] > 0){
        // application already exist 
        die(json_encode(["SUCCESS" => ["Message" => 'No Set Up']]));
    }else{
        // fresh application 
        // transcirpt Fee/transaction charge
        $trFee = json_decode($rowMo['PayBrkDn']);
        $tranAmt = $trFee->TransactionCharge[0]==0?0:$trFee->TransactionCharge[1];
        // comput destination address
        $destAd = explode('~',$rObj->hold__Desstate__dataset);
        $sumDest = 0;
        foreach($destAd as $value) {
            if($value > 37){
                // non nigirian
                $rstDestAmount = $_->Select("itemlist_tb","*","ID = 2 AND Active = 1");
                $rowDest = $rstDestAmount[0]->fetch_assoc();
                $sumDest+=(int)$rowDest['Amt'];
            }else{
                $rstDestAmount = $_->Select("itemlist_tb","*","ID = 1 AND Active = 1");
                $rowDest = $rstDestAmount[0]->fetch_assoc();
                $sumDest+=(int)$rowDest['Amt'];
            }
        }
        $sumExtraCopy = 0;
        $xtraCopy = 0;
        if(count($destAd) > 1){
            $xtraCopy = count($destAd) - 1;
            $rstExtraCopy = $_->Select("item_tb","PayBrkDn","ID = 2");
            $rowExtr = $rstExtraCopy[0]->fetch_assoc();
            $etraCopy = json_decode($rowExtr['PayBrkDn']);
            $finVal = (int)$etraCopy->Amt * (int)(count($destAd) - 1);
            $sumExtraCopy+=$finVal;
        }
        $payAblefee = (int)$trFee->Amt + (int)$tranAmt + (int)$sumDest + (int)$sumExtraCopy;
        $holdJsonArr = [
            "PhoneNumber" => "".trim($rObj->__phon__no)."",
            "PersonalEmail" => "".trim($rObj->__personal__email)."",
            "DestinationEmails" => "".trim($rObj->hold__Emel)."",
            "PostageTypes" => "".trim($rObj->hold__PostaAddres)."",
            "DestinationAddresses" => "".trim($rObj->holdDestinAddres)."",
            "DestinationStateID" => "".trim($rObj->hold__Desstate__dataset)."",
            "DestinationStateNames" => "".trim($rObj->hold__Desstate)."",
            "FeesCharges" => [
                "".strtoupper($rowMo['ItemName'])."FEE" => $trFee->Amt,
                "TRANSACTIONCHARGE" => $tranAmt,
                "DestinationFee" => $sumDest,
                "NofEtraCopy" => $xtraCopy,
                "ExtraCopyFee" => $sumExtraCopy
            ],
            "GrandTotal" => $payAblefee
        ];
        // info
        $holdInfoArray = [
            "Name" => "".trim($_->SqlSafe($row['Name']))."",           
            "RegNo" => "".trim($_->SqlSafe($rObj->__recT))."",
            "ProgID" => "".trim($_->SqlSafe($row['progID']))."",
            "ProgName" => "".trim($_->SqlSafe($row['ProgName']))."",
            "DeptID" => "".trim($_->SqlSafe($row['DeptID']))."",
            "DeptName" => "".trim($_->SqlSafe($row['DeptName']))."",
            "FacID" => "".trim($_->SqlSafe($row['FacID']))."",
            "FacName" => "".trim($_->SqlSafe($row['FacName']))."",
            "StartSes" => "".trim($_->SqlSafe($row['StartSes']))."",
            "ModeOfEntry" => "".trim($_->SqlSafe($row['ModeOfEntry']))."",
            "StudyID" => "".trim($_->SqlSafe($row['StudyID']))."",
            "PayName" => "".strtoupper($_->SqlSafe($rowMo['ItemName']))." FEE"
        ];
        // sem proc
        $rstSem = $_->Select("semester_tb","ID","Current = 1");
        if($rstSem[1] > 0){
            $getSem = $rstSem[0]->fetch_assoc();
        }else{
            die(json_encode(["ERROR" => ["Message" => '|~~|']]));
        }
        // session id
        $rstSes = $_->Select("session_tb","SesID","Current = 1");
        if($rstSes[1] > 0){
            $getSes = $rstSes[0]->fetch_assoc();
        }else{
            die(json_encode(["ERROR" => ["Message" => '|~~|']]));
        }
        // check if order has been generated b4
        $rstSel = $_->Select("order_tb","ID,ExpiredRef,TransNum","RegNo = '".trim($_->SqlSafe($rObj->__recT))."' AND Sem = ".$getSem['ID']." AND Ses = ".$getSes['SesID']." AND ItemID = ".trim($_->SqlSafe($rowMo['ID']))."");
        if($rstSel[1] > 0){
            $getRefRow = $rstSel[0]->fetch_assoc();
            $expiredRefNos = '';
            $explodRef = explode(":",$getRefRow['ExpiredRef']);
            
            foreach($explodRef as $refVal) {
                $expiredRefNos.=''.$refVal.':';
            }
            $expiredRefNos.=''.trim($getRefRow['TransNum']).':';
            $genTenNo = $_->gidi10();
            $gen22No = $_->gidi22();
            // check if ref exist
            $rstCheck = $_->Select("order_tb","ID","TransNum = ".trim($_->SqlSafe($genTenNo))."");
            if($rstCheck[1] > 0){$genTenNo = $_->gidi10;$gen22No = $_->gidi22();}
            $rstUpdate = $_->Update("order_tb",["ItemNo" => trim($_->SqlSafe($gen22No)),"TransNum" => trim($_->SqlSafe($genTenNo)),"ExpiredRef" => trim($_->SqlSafe($expiredRefNos))],"RegNo = '".trim($_->SqlSafe($rObj->__recT))."' AND TransNum = ".trim($getRefRow['TransNum'])."");
            die(json_encode(["SUCCESS" => ["Message" => $genTenNo,"reportP" => [$genTenNo,$payAblefee,"AKSU ".$rowMo['ItemName']." PAYMENT"]]]));
        }else{
            // gen TransNum 
            $genTenNo = $_->gidi10();
            $gen22No = $_->gidi22();
            // check if ref exist
            $rstCheck = $_->Select("order_tb","ID","TransNum = ".trim($_->SqlSafe($genTenNo))."");
            if($rstCheck[1] > 0){$genTenNo = $_->gidi10;$gen22No = $_->gidi22();}
            // Insert
            $Itmnam = strtoupper($rowMo['ItemName']);
            $ItmnamDescript = strtoupper($rowMo['ItemDescr']);
            $rstInser = $_->Insert("order_tb",["ItemNo" => trim($_->SqlSafe($gen22No)),"TransNum" => trim($_->SqlSafe($genTenNo)),"ItemName" => trim($_->SqlSafe($Itmnam)),"ItemDescr" => trim($_->SqlSafe($ItmnamDescript)),"Amt" => trim($_->SqlSafe($payAblefee)),"RegNo" => trim($_->SqlSafe($rObj->__recT)),"SemPart" => 3,"Sem" => trim($_->SqlSafe($getSem['ID'])),"Lvl" => 1,"ItemID" => trim($_->SqlSafe($rowMo['ID'])),"Paid" => 0,"RegDate" => date("Y-m-d"),"Ses" => trim($_->SqlSafe($getSes['SesID'])),"BrkDwn" => trim(json_encode($holdJsonArr)),"Info" => trim(json_encode($holdInfoArray)),"ProgID" => trim($_->SqlSafe($row['progID']))]);
            if($rstInser[1] > 0){
                die(json_encode(["SUCCESS" => ["Message" => $genTenNo,"reportP" => [$genTenNo,$payAblefee,"AKSU ".$rowMo['ItemName']." PAYMENT"]]]));
                // what next?
            }
        }
    }
}else{
    die(json_encode(["ERROR" => ["Message" => $errorCode['|~~|@']]]));
}

?>