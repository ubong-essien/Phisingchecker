<?php
require_once "../../engine/Robot.php";
require_once "../../engine/sha3encryptdecriptold.php";
require_once "../errormsg.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Payment</title>
    <link href="../../assets/css/main.css" rel="stylesheet" type="text/css" />
    <link href="../../../LIB/FA5/css/all.min.css" rel="stylesheet" type="text/css" />
    <link href="../../../LIB/Engine/css/core.css" rel="stylesheet" type="text/css" />
    <link href="../../../LIB/w3c.CSS" rel="stylesheet" type="text/css" />
    <link href="../../../LIB/FA5/css/all.min.css" rel="stylesheet" type="text/css" />
    <script src="../../assets/js/main.js" type="text/javascript"></script>
</head>
<body>
    
<?php
    $localInit = "";
    $logo = 'http://localhost/cep/assets/images/FB_1.jpeg';
    $reg__No = '';
    $trxMsg = '';
    $reson = '';
    $trxMsgr = '';
    if($_GET['SUCCESS'] == "C"){
       
    // transac successful
        // select ref no details
        // Array ( [AMOUNT] => 35700.00 [DESCRIPTION] => AKSU TRANSCRIPT FEE [CHECKSUM] => 4bcfb038ab72d9440d2db264f22b0324 [EMAIL] => enefiokduke4info@gmail.com [SUCCESS] => C [MESSAGE] => Cancel [LOGO_URL] => http://localhost/records/assets/images/FB_1.jpeg [RESPONSE_URL] => http://localhost/records/script/responseurl.php [CURRENCY_CODE] => NGN [TERMINAL_ID] => 7007139840 [TRANSACTION_ID] => 3640891380 [MERCHANT_CODE] => 700602X3D6 [RESPONSE_CODE] => C [FINAL_CHECKSUM] => 2462FB6DBEB3C0A27CE38C7E01E210DD [STATUS_REASON] => Cancel [TRANS_NUM] => 01ESA20220122091718PLHBJE [CARD_NO] => null [CARD_TYPE] => null [TRANS_DATE] => null )
         // new checksum
        //  $key = 'Antman123456789@#__..__..__..'.date('Y');
        //  $iv = '2348022269656080';
        // get descript param
        $getDescp = explode("####",$_GET['DESCRIPTION']);
        // print_r($getDescp);die;
        // $newChecksum = str_replace(";", "", $getDescp[1]);
        // die(openssl_decrypt($getDescp[1], 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv));
        // $newChecksum = base64_encode($getDescp[1]);
        // $newChecksum1 = openssl_decrypt($newChecksum, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        $newChecksum1 = decryptSH3($getDescp[1]);
       // die($getDescp[1]);
        $verification_param = explode(':',$newChecksum1);
        $ordID = $verification_param[0];// record d for the order.
        // die("SELECT * FROM order_tb WHERE TransNum = ".trim($_->SqlSafe($_GET['TRANSACTION_ID']))." AND ID = ".$ordID."");
        $rstSelctRef = $_->Select("order_tb","*","TransNum = ".trim($_->SqlSafe($_GET['TRANSACTION_ID']))." AND ID = ".$ordID."");
        
        if($rstSelctRef[1] > 0){
            $row = $rstSelctRef[0]->fetch_assoc();
            $OtherInfo = json_decode($row['Info']);
            // payment details
            $rstTerminalID = $_->Select("thirdpartysyn_tb","*","ItemID = ".$row['ItemID']."");
            $terminalId = '';
            // $terminalId = '7007139840';
            $sk = '';
            // $sk = 'fxPP2Yf3XuhnrCGa';
            if($rstTerminalID[1] > 0){
                $rowRstTerminalID = $rstTerminalID[0]->fetch_assoc();
                $terminalId = trim($rowRstTerminalID['TerminalID']);
                $sk = trim($rowRstTerminalID['SecurityKey']);
            }else{die($errorCode['R16']);}            
            // $terminalId = '7007139840';
            $responseurl = 'http://localhost/cep/script/payment/responseurl.php';
            // $sk = 'fxPP2Yf3XuhnrCGa';
            // 2,200.00~7007139556~8200582757~http://localhost/gss/script/responseurl.php~ZVdJc5ruai7tpcqu
            // 2200.00~7007139556~8037693617~http://localhost/gss/script/responseurl.php
            $AmtPaid = $row['Amt'];
            // die($_GET['AMOUNT'].'~'.$_GET['TERMINAL_ID'].'~'.$_GET['TRANSACTION_ID'].'~'.$_GET['RESPONSE_URL']);
            // die($AmtPaid.'~'.$terminalId.'~'.$row['TransNum'].'~'.$responseurl.'~'.$sk);

            $cheksum = md5($AmtPaid.$terminalId.$_GET['TRANSACTION_ID'].$responseurl.$sk);
            if($_GET['CHECKSUM'] != $cheksum)die($errorCode['R13']);
            // session id
            // $rstSes = $_->Select("session_tb","SesID","Current = 1");
            // if($rstSes[1] > 0){
            //     $getSes = $rstSes[0]->fetch_assoc();
            // }
            // check if payment exist
            $rstCheck = $_->Select("payhistory_tb","ID","RegNo = '".trim($_->SqlSafe($row['RegNo']))."' AND TransID = ".$row['TransNum']." AND PayID = ".$row['ItemID']."");
            if($rstCheck[1] > 0){
                $localInit = '0';
            }else{
                    // update order tb set paid to 1 AK15/AGR/CRS/015
                    $rstUpdate = $_->Update("order_tb",["Paid" => 1],"TransNum = ".$row['TransNum']."");
                    //$rstUpdateR = $_->Update("payhistory_tb",["Active" => 0],"RegNo = '".trim($_->SqlSafe($row['RegNo']))."' AND Sem = ".$getSem['ID']." AND Ses = ".$getSes['SesID']." AND Lvl = ".trim($_->SqlSafe($row['Lvl']))."");
                    // insert into payhistory tb
                    $aksl = $row['TransNum'].$row['ItemNo'];
                    $rstInsertPay = $_->Insert("payhistory_tb",["RegNo" => "".trim($_->SqlSafe($row['RegNo']))."","Lvl" => "".trim($_->SqlSafe($row['Lvl']))."","Sem" => trim($_->SqlSafe($row['Sem'])),"SemPart" => 3,"Ses" => trim($_->SqlSafe($row['Ses'])),"Amt" => trim($_->SqlSafe($row['Amt'])),"TransID" => trim($_->SqlSafe($row['TransNum'])),"PayID" => trim($_->SqlSafe($row['ItemID'])),"PayBrkDn" => "".trim($row['BrkDwn'])."","Bank" => "".trim($_->SqlSafe($_GET['CARD_TYPE']))."","BnkBranch" => "".trim($_->SqlSafe($_GET['CARD_NO']))."","itemNum" => trim($_->SqlSafe($row['ItemNo'])),"PayDate" => "".trim(date("Y-m-d"))."","validationNo" => "".trim($_->SqlSafe($_GET['TRANS_NUM']))."","aksl" => trim($_->SqlSafe($aksl)),"Info" => "".trim($row['Info'])."","TransAmt" => trim($_->SqlSafe($row['Amt'])),"ProgID" => trim($_->SqlSafe($row['ProgID']))]);
                    // insert into application tb
                    if($rstInsertPay[2] > 0){
                        if($row['ItemID'] <= 2){

                            $rstUpdatePstInfo = $_->Update("pstudentinfo_tb",["RegLevel" => 2],"JambNo = '".trim($_->SqlSafe($row['RegNo']))."'");

                        }
                        // update regLevel for registration process
                        // $rstPInfo = $_->Select("pstudentinfo_tb","RegLevel","JambNo = '".trim($_->SqlSafe($row['RegNo']))."'");
                        // if($rstPInfo[1] > 0){
                        //     $getRowPInfo = $rstPInfo[0]->fetch_assoc();
                        //     if($getRowPInfo['RegLevel'] == 1){
                        //         $rstUpdatePstInfo = $_->Update("pstudentinfo_tb",["RegLevel" => 2],"JambNo = '".trim($_->SqlSafe($row['RegNo']))."'");
                        //     }
                        // }
                        $localInit = '0';
                        $reg__No = $row['RegNo'];
                        $trxMsgr = 'PAYMENT SUCCESSFUL';
                        $trxMsg = '
                                <div class="w3-center w3-margin aks-records-btn-inner-txt aks-records-module-font">PAYMENT SUCCESSFUL</div>
                                <div class="w3-display-container" style="width:50px;height:50px;margin:auto;border-radius:50%;background-color:green;color:white;">
                                    <i class="fas fa-check w3-display-middle"></i>
                                </div>
                        ';
                    }else{
                        $localInit = '-1';
                    }
            }

        }else{
            die($errorCode['R24']);
        }
    }else{
    //transac failed
        $localInit = '-1';
        $rstSelctRef = $_->Select("order_tb","*","TransNum = ".trim($_->SqlSafe($_GET['TRANSACTION_ID']))."");
        if($rstSelctRef[1] > 0){
            $row = $rstSelctRef[0]->fetch_assoc();
            $reg__No = $row['RegNo'];
            $trxMsgr = 'PAYMENT FAILED';
            $trxMsg = '
                <div class="w3-center w3-margin aks-records-btn-inner-txt aks-records-module-font">PAYMENT FAILED</div>
                <div class="w3-display-container" style="width:50px;height:50px;margin:auto;border-radius:50%;background-color:red;color:white;">
                    <i class="fas fa-times w3-xlarge w3-display-middle"></i>
                </div>
            ';            
            $reson = '<div class="w3-row" style="margin-top:5px;">
            <div class="w3-col s4" style="font-size:12px;font-weight:700;">
            REASON
            </div>
            <div class="w3-col s8" style="font-size:12px;font-weight:700;">
            '.$_GET['RESPONSE_CODE'].'
            </div>
        </div>';
        }
    }
?>
<!-- body -->
<div class="w3-light-grey" style="width:100%;min-height:100vh;position:relative;padding:50px;">
    <div style="position:relative;width:100%;max-width:330px;margin:auto;height:100%;min-height:420px;box-shadow:0 3px 6px rgb(0 0 0 / 16%), 0 3px 6px rgb(0 0 0 / 23%);background-color:#fff;padding:10px;border-radius:20px;">
        <div style="width:100%;height:calc( 100% - 50px )">
            <div style="width:100px;margin:auto;height:100px;">
                <img src="<?=$logo?>" alt="photo" width="100%" height="100%">
            </div>
            <div>
                <div style="font-size:13px;font-weight:700;text-align:center;">
                    <div><?=$trxMsg?></div>
                </div>
                <div style="width:100%;font-size:11px;font-weight:200;margin-top:10px;">
                    <div class="w3-row" style="margin-top:5px;">
                        <div class="w3-col s4" style="font-size:12px;font-weight:700;">
                        PAYMENT TYPE
                        </div>
                        <div class="w3-col s8" style="font-size:12px;font-weight:700;">
                        <?=$getDescp[0]?>
                        </div>
                    </div>
                    <div class="w3-row" style="margin-top:5px;">
                        <div class="w3-col s4" style="font-size:12px;font-weight:700;">
                        REFERENCE NO.
                        </div>
                        <div class="w3-col s8" style="font-size:12px;font-weight:700;">
                        <?=$_GET['TRANSACTION_ID']?>
                        </div>
                    </div>
                    <div class="w3-row" style="margin-top:5px;">
                        <div class="w3-col s4" style="font-size:12px;font-weight:700;">
                        AMOUNT
                        </div>
                        <div class="w3-col s8" style="font-size:12px;font-weight:700;">
                        <?=number_format($_GET['AMOUNT'],2)?>
                        </div>
                    </div>
                    <div class="w3-row" style="margin-top:5px;">
                        <div class="w3-col s4" style="font-size:12px;font-weight:700;">
                        REG NUMBER
                        </div>
                        <div class="w3-col s8" style="font-size:12px;font-weight:700;">
                        <?=$reg__No?>
                        </div>
                    </div>
                    <div class="w3-row" style="margin-top:5px;">
                        <div class="w3-col s4" style="font-size:12px;font-weight:700;">
                        STATUS
                        </div>
                        <div class="w3-col s8" style="font-size:12px;font-weight:700;">
                        <?=$trxMsgr?>
                        </div>
                    </div>
                    <div><?=$reson?></div>
                    <div class="w3-row" style="margin-top:5px;">
                        <div class="w3-col s4" style="font-size:12px;font-weight:700;">
                        DATE
                        </div>
                        <div class="w3-col s8" style="font-size:12px;font-weight:700;">
                        <?=date("d/m/Y")?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div style="width:80%;margin:auto;height:50px;">
            <button onclick="CEP.Modules.Modulator.closeWindowObj();" class="w3-button w3-margin-top aks-records-btn-inner-txt w3-red aks-records-font-10" style="width:100%;border-radius:20px;text-align:center;">CLOSE</button>
        </div>
    </div>
</div>
<!-- script -->
<script>
function getM(){
    var getSucesMsg = <?=json_encode($localInit)?>;
    if(getSucesMsg != "") {
        if(getSucesMsg == "0"){
            // set
            let getSuce,getUnSuce,xi,xy;
            getSuce = localStorage.getItem("SUCCESS");
            getUnSuce = localStorage.getItem("UNSUCCESSFULL");
            if(getSuce != undefined || getSuce != ""){
                xi = localStorage.removeItem("SUCCESS");
                xy = localStorage.removeItem("UNSUCCESSFULL");
            }
            getUnSuce = localStorage.setItem("SUCCESS", "0");
        }else{
            // unset
            let getSuce,getUnSuce,xi,xy;
            getSuce = localStorage.getItem("SUCCESS");
            getUnSuce = localStorage.getItem("UNSUCCESSFULL");
            if(getUnSuce != undefined || getUnSuce != ""){
                xi = localStorage.removeItem("SUCCESS");
                xy = localStorage.removeItem("UNSUCCESSFULL");
            }
            getUnSuce = localStorage.setItem("UNSUCCESSFULL", "-1");
        }
    }
}
getM();
</script>
</body>
</html>
