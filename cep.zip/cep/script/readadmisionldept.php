<?php
$mimeType = array("text/csv","application/vnd.ms-excel","text/plain","text/tsv");
if(in_array($_FILES['file1']['type'],$mimeType)){
$handle = fopen($_FILES['file1']['tmp_name'], "r");
$headers = fgetcsv($handle, 1000, ",");
// $data = fgetcsv($handle, 1000, ",");
$getArr = array();
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE){
	if(strlen($data[0]) < 10){die('*78');}
// 	if(strlen($data[6]) != 8){die('*79');}
	$getArr[] = ["REGNUM" => $data[0], "DEPT" => $data[5]];
}
fclose($handle);
if(count($getArr) > 0){
	die(json_encode($getArr));
}else{
	die('*78');//contact ict
}
}else{
	die('@!*');//csv format needed
}
?>