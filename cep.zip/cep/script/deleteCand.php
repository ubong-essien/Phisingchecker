<?php
session_start();
require_once "../engine/Robot.php";
require_once "../engine/Roboti.php";
$getJall = json_decode($_POST['data']);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$gtDl = $_->Delete("studentinfo_tb","JambNo = '".$_->SqlSafe($getJall->toregN)."'");
	if($gtDl){
		$gtDSuadm = $_P->Delete("supadmlist","JambNo = '".trim($_P->SqlSafe($getJall->toregN))."'");
		if($gtDSuadm){
			$gtRec = $_P->Update("recommendation_tb",["AdmitStatus" => 0],"RegNo = '".trim($_P->SqlSafe($getJall->toregN))."'");
			if($gtRec){
				$gtDadmlog = $_->Delete("admissionlog_tb","JambNo = '".$_->SqlSafe($getJall->toregN)."'");
				if($gtDadmlog){
							$getActlog = $_->Insert("activitylog_tb",["Details" => "Admin ".$_SESSION['idd']." deleted ".trim($_P->SqlSafe($getJall->toregN))." from the admission list","Admin_id" => "".$_SESSION['idd']."","JambNo" => "".trim($_P->SqlSafe($getJall->toregN)).""]);
							if($getActlog){
								//die('Activity Log Added');
								// print_r($_POST);exit;
							}
				}

			}
		}
	}
}
?>
