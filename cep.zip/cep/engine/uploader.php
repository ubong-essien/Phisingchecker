<?php
class FileManager{

    public $MinSize = 20000;
    public $MaxSize = 200000;

      //#Uploader - upload file send via aim Ajax Post

  //get file type
  private function file_mime_type($file, $encoding=true) {
    $mime=false;

    if (function_exists('finfo_file')) {
        $finfo = finfo_open(FILEINFO_MIME);
        $mime = finfo_file($finfo, $file);
        finfo_close($finfo);
    }
    else if (substr(PHP_OS, 0, 3) == 'WIN') {
        $mime = mime_content_type($file);
    }
    else {
        $file = escapeshellarg($file);
        $cmd = "file -iL $file";

        exec($cmd, $output, $r);

        if ($r == 0) {
            $mime = substr($output[0], strpos($output[0], ': ')+2);
        }
    }

    if (!$mime) {
        return false;
    }

    if ($encoding) {
        return $mime;
    }

    return substr($mime, 0, strpos($mime, '; '));
}

private function CheckSize($fsize){
    if(!is_null($this->MinSize) && $fsize < (float)$this->MinSize){ //if less than min size
        return "File too Small";
    }

    if(!is_null($this->MaxSize) && $fsize > (float)$this->MaxSize){ //if less than min size
        return "File too Large";
    }
    return true;
}

  public function Uploader($path = "../aim-files/",$sfile="",$filename = "",$mimetypes = "image/gif,image/jpeg,image/jpg,image/pjpeg,image/png"){
      //	$conds = (($mimetype == "image/gif") || ($mimetype == "image/jpeg") || ($mimetype == "image/jpg") || ($mimetype == "image/pjpeg"));
      $mimetypes = (is_string($mimetypes) && trim($mimetypes) == "")?"image/gif,image/jpeg,image/jpg,image/pjpeg,image/png":$mimetypes;
      $mimetypes = !is_array($mimetypes)?explode(",",strtolower($mimetypes)):$mimetypes;
    $rptfailed = $rptsuccess = [];$single=false;$seen=false;
   // $rptfailed[$key] = "aaa";
   foreach($_FILES as $key=>$file){
    $filename = trim($filename) == ""?$key:$filename;
       if(trim($sfile) != ""){
           if(trim($key) != trim($sfile))continue;
           $single = true;
       }

     
       
   //if($_FILES[$nme]){ //get passport
      $fileTmpLoc = $file["tmp_name"];
      //check if multiple file sent 
      if(is_array($fileTmpLoc)){
          foreach($fileTmpLoc as $ind=>$val){
            $file_name = $file["name"][$ind];
            $file_temp = $val;
            $fsize = $file["size"][$ind];
            $cheksize = $this->CheckSize($fsize);
            if($cheksize !== true){
                if(!isset($rptfailed[$key])){
                    $rptfailed[$key] = $cheksize . ";";
                }else{
                    $rptfailed[$key] .= $cheksize. ";";
                }
                continue;
            }
            //get mime type
            $mimet = $this->file_mime_type($file_temp,false);
            if(in_array($mimet,$mimetypes)){
               $file_dest = rtrim($path,"/\\")."/";$file_fname = $filename."_".$ind;
                $rnamarr = explode(".",$file_name);
                $file_ext = $rnamarr[count($rnamarr) - 1];
                $performu = $this->PerformUpload($file_name,$file_temp,$file_dest,$file_fname,$file_ext);
                if($performu !== true){
                    if(!isset($rptfailed[$key])){
                        $rptfailed[$key] = $performu . ";";
                    }else{
                        $rptfailed[$key] .= $performu . ";";
                    }
                    
                }else{
                    if(!isset($rptsuccess[$key])){
                        $rptsuccess[$key]= $file_dest . $file_fname.".".$file_ext.";";
                    }else{
                       $rptsuccess[$key] .= $file_dest . $file_fname.".".$file_ext.";"; 
                    }
                    
                } 
            }else{
                if(!isset($rptfailed[$key])){
                    $rptfailed[$key] = "Invalid File Type" . ";";
                }else{
                    $rptfailed[$key] .= "Invalid File Type" . ";";
                }
               
            }
            
          }
          if(isset($rptfailed[$key]))rtrim($rptfailed[$key],";");
          if(isset($rptsuccess[$key]))rtrim($rptsuccess[$key],";");
      }else{//single file
        $fsize = $file["size"];
        $cheksize = $this->CheckSize($fsize); //check file size
            if($cheksize !== true){
                $rptfailed[$key] = $cheksize;
            }else{
               $mimet = $this->file_mime_type($fileTmpLoc,false);
        if(in_array($mimet,$mimetypes)){
        $rnamarr = explode(".",$file["name"]);
        $file_ext = $rnamarr[count($rnamarr) - 1];
        $performu = $this->PerformUpload($file["name"],$fileTmpLoc,rtrim($path,"/\\")."/",$filename,$file_ext);
        if($performu !== true){
            $rptfailed[$key] = $performu;
        }else{
            $rptsuccess[$key] = rtrim($path,"/\\")."/" . $filename.".".$file_ext;
        }
    }else{
        $rptfailed[$key] = "Invalid File Type";
    }  
            }
       
      }
      $seen = true;
      if($single)break;
   //}
  }
  if(!$seen){
      //$sfile
      $rptfailed[$sfile] = "No File Found";
  }
  return array("Failed"=>$rptfailed,"Success"=>$rptsuccess);
}



private function PerformUpload($file_name,$file_temp,$file_dest,$file_fname,$file_ext){
    $rnam = $file_name;
      
     //return "yommy";
      if($file_temp){
          if(!file_exists($file_dest)){
              
              $mkd = mkdir($file_dest,0777,true);
              if(!$mkd){
                return "Cannot create distination Directory";
              }
          }
          //../asset/customer/passport/6411311.jpg
          if(!move_uploaded_file($file_temp, $file_dest."$file_fname.$file_ext")){ //upload file
             // exit("#Operation Aborted: Passport Upload Failed");
             return "Moving file to destination failed";
          }else{
           return true;
          }
      }
      return "Invalid File";
}
//proccess upload file
//#SaveFile
public function SaveFile($file,$dir="./file/",$savename= "",$mimetypes = "image/gif,image/jpeg,image/jpg,image/pjpeg,image/png"){
    //global $_;
    //upload the passport
    if(isset($file) && $file != ""){
        $filname = trim($savename) == ""?mt_rand(10000,99999).time():$savename;
         $uplrst = $this->Uploader($dir,$file,$filname,$mimetypes);
         if(!isset($uplrst['Success'][$file])){
             return json_decode('{"Error":true,"Message":"'.$uplrst['Failed'][$file].'","FileName":""}');
         }
         return json_decode('{"Error":false,"Message":"File Saved","FileName":"'.$uplrst['Success'][$file].'"}');
    }
}
}

$FileManager = new FileManager();

/*
//Usage
$FileMg = new FileManager();
$rst = $FileMg->SaveFile($file,$distination_dir,$save_name,$file_type);
if($rst['Error']){
    //Error Occur
    echo $rst['Message'];
}else{ //Successful
  echo $rst['FileName'];//multiple file => filenames will be seperated with semicolunm
}
*/

?>