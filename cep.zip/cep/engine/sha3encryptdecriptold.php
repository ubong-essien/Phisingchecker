<?php
 error_reporting(0);
// Store the cipher method
$ciphering = "AES-128-CBC";
// Store the encryption key
$encryption_key = "Antman123456@#TELEMEDiCINE~@";
// encrypt the end
 function encryptSH3($simple_string){
   global $ciphering;
   global $encryption_key;
    // Use OpenSSl Encryption method
    $iv_length = openssl_cipher_iv_length($ciphering);

    $options = 0;
    $encryption_iv = base64_encode($iv_length);
        // Use openssl_encrypt() function to encrypt the data
     $encryption = openssl_encrypt($simple_string, $ciphering,
     $encryption_key, $options, $encryption_iv);
     return $encryption;
 }
//  decryptEnd
function decryptSH3($encryption){
        global $ciphering;
        global $encryption_key;
        $iv_length = openssl_cipher_iv_length($ciphering);
        $options = 0;
        $decryption_iv = base64_encode($iv_length);
        // Use openssl_decrypt() function to decrypt the data
      $decryption = openssl_decrypt ($encryption, $ciphering, 
      $encryption_key, $options, $decryption_iv);
      return $decryption;
} 
// how to encrypt the string
// $encryptedEnd = encryptSH3($simple_string);
// how to decrypt string
// $decrytpEnd = decryptSH3("avmH1SEjpq6tPzsBUeWUDz1abwXZTghlf3k/a9Itf2XqVBeMUIlbXg==");
?>