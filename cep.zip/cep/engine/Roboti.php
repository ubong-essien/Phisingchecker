<?php
$__CONFIG = "";
date_default_timezone_set("Africa/Lagos");
class AIM__I{
    //hold global static var for connection strings
    public static $Connection;
    //hold Database name
    public static $DBName;
    public function __construct($config=""){
        global $__CONFIG;
        if(trim($config) == ""){
            if(trim($__CONFIG) != ""){
                $config = $__CONFIG;
            }else{
                $config = dirname(__FILE__)."/config.json";
            }
        }       //get the config file
        $configFile = file_get_contents($config);
        //decode the json file
        $decode = json_decode($configFile,true);
        self::$DBName = $decode['PG_DB']['DBName'];
        //check if db name is provided
       if($decode['PG_DB']['Type'] != "auto"){
           //establish connection to db
            $con = new mysqli($decode['PG_DB']['ServerName'],$decode['PG_DB']['UserName'], $decode['PG_DB']['Password'], $decode['PG_DB']['DBName']);
            //check connection
            if($con->connect_error){
                die("Connection failed: " .$con->connect_error);
            }
            self::$Connection = $con;
       }else{
           //create db
       }
    }
    public function SqlSafe(&$data){
        $data = mysqli_real_escape_string(self::$Connection,$data);
        return $data;
    }
    //insert into tb
    public function Insert($TB,$fields = []){
        //hold current db name
        $DBName = self::$DBName;
        //check if the table name exist in the said db
        $sql = "SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE table_schema = '$DBName' AND table_name = '$TB' LIMIT 1";
        if(self::$Connection->query($sql)){
            if(count($fields) > 0){
                    //hold fieldfMAX
                    $holdFields= '';
                    //hold field values
                    $holdValues ='';
                    foreach($fields as $fieldName => $value){
                        $holdFields.=$fieldName.',';
                        if(is_string($value)){
                            $this->SqlSafe($value);
                            $holdValues.= "'".$value."',";
                        }else{
                            $holdValues.=$value.',';
                        }
                    }
                $holdFields = rtrim($holdFields,',');
                $holdValues = rtrim($holdValues,',');
                $sql = "INSERT INTO $TB($holdFields) VALUES($holdValues)";
                return $this->Query($sql);
            }
        }else{
            //create table before tryiing to insert again 
            exit('Table Does not Exist');
        }
	}
	//function to update multiplecol to db
	public function InsertMultiQury($sql,$msg){
		$result = self::$Connection->multi_query($sql);
			if($result === TRUE){return ["SUCCESS" => ["Message" => $msg]];}else{echo "Error:" . $sql . "<br>".self::$Connection->error;}
	}
	//truncate tb
	public function truncateTB($table_name,$msg){
		$sql = "TRUNCATE TABLE ".$table_name."";
		$rst = self::$Connection->query($sql);
		if($rst === TRUE){return ["SUCCESS" => $msg];}else{echo "Error:" . $sql . "<br>".self::$Connection->error;}
	}
	//close Connection
	public function clCon(){
		self::$Connection->close();
	}
    //selcted from tb
    public function Select($TB,$feilds = "",$conditions = ""){
        $feilds = trim($feilds) == ""?"*":$feilds;
        $conditions = trim($conditions) == ""?"1=1":$conditions;
        $sql = "SELECT $feilds FROM $TB WHERE $conditions";
        return $this->Query($sql);
    }
    //update tb
    public function Update($TB,$fields = [],$conditions = ""){
            //hold field names = value
            $conditions = trim($conditions) == ""?"1=1":$conditions;
            $q=[];
            foreach($fields as $fieldName => $value){
                $value = $this->SqlSafe($value);
                if(is_string($value)){
                    $value = "'".$value."'";
                }
                $q[] = $fieldName.'='.$value;
            }
            $holdFields = implode(",",$q);
            $sql = "UPDATE $TB SET $holdFields WHERE $conditions";
            return $this->Query($sql);
    }
    //delet tb
    public function Delete($TB,$conditions = ""){
        $conditions = trim($conditions) == ""?"1=1":$conditions;
        $sql = "DELETE FROM $TB WHERE $conditions";
        return $this->Query($sql);
    }
	
    //delet tb
    public function Query($sql = ""){
        $sql = trim($sql);
        $cmd = strtolower(substr($sql,0,6));
        $rst = self::$Connection->query($sql);
        if(!$rst === true){return self::$Connection->error;}
        //print_r($rst);exit;
        switch($cmd){
            //insert opera
            case "select":
                return [$rst,$rst->num_rows];
            break;
            //update opera
            case "update":
                return [$rst,self::$Connection->affected_rows];
            break;
            //delete opera
            case "delete":
                return [$rst,self::$Connection->affected_rows];
            break;
            //select opera
            case "insert":
                return [$rst,self::$Connection->affected_rows,self::$Connection->insert_id];
            break;

            default:
            break;
            
        }
	}
	public function BeginTransaction()
	{
		return self::$Connection->begin_transaction();
	}

	public function CommitTransaction()
	{
		return	self::$Connection->commit();
	}

	public function RollbackTransaction()
	{
		return	self::$Connection->rollback();
	}
	// form AC
	function FormACAlph(){
		$charset = array('a','B','c','D','e','F','g','H','I','j','K','l','M','n','o','p','Q','r','S','t','U','v','w','X','y','Z');
		$ac = "";
		$s=1;
		while($s < 9){
		$rand = mt_rand(0,25);
		$ac .= $charset[$rand];
		$s++;	
		}
		return $ac;
	}
    //hold state from json
    public function GetState(){
        //get the config file
        $configFile = file_get_contents(dirname(__FILE__)."/state.json");
        return $configFile;
        //echo __FILE__;
        //echo "<br/>";
        //echo $_SERVER['PHP_SELF'];
    }
    public function canvasProgress($styl = "",$cl = "",$content = ""){
        echo '
        <div id="shwReGPrinting" class=" spt-bigBox-cont-dst" style="display:none;">
            <div style="position: absolute;left:50%;top:50%;transform:translate(-50%,-50%);">
                <div class="w3-right"><div onclick="__I.exitContainer(\'shwReGPrinting\',\'shwReGPrinting\');" class="w3-display-container cor-pointer w3-round" style="width:25px;height:25px;background-color:red;"><span class="w3-display-middle w3-text-white">x</span></div></div>
                <div id="dispDtailPintin" class="w3-center">
                    <div style="background-color: rgb(0, 0, 0);background-color: rgba(0, 0, 0,0.99);min-width:300px;'.$styl.'" class="cor-modul-btn '.$cl.'">
                        <div class="counter w3-center">
                            <canvas id="counter" width = "200" height = "200" style=""></canvas>
                        </div>
                        <div id="reMoblik" class="w3-center mva-blink w3-text-white"><i>Uplo<span style="color:#FF6600;">ading</span>...</i></div><div id="reMoblik2" class="w3-center mva-blink w3-text-white" style="display:none;"><i>Uplo<span style="color:#FF6600;">aded</span></i></div>
                        <div>'.$content.'</div>
                    </div>
                    
                </div>
            </div>
        </div>		
        ';
    }
    // footer
    public function footerDescrip($colr){
	$output = '
	<div style="position:fixed;bottom:0;width:100%;height:40px;border-top:solid thin #aaaaaa33;background-color: rgb(0, 0, 0);background-color: rgba(0, 0, 0,0.7);overflow:hidden;z-index:10;font-size:13px;">
			<div style="width:100%;">
			<div class="w3-center w3-text-white" style="padding: 5px;">
				<div class="putme-display-inline3 spt-header-smr '.$colr.'"><i class="fa fa-copyright spt-header-smr "></i>AKSUICT-'.date('Y').'</div>
				<div class="putme-display-inline3">|</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium spt-header-smr"><i class="fa fa-phone spt-header-smr"></i> +2348023635890</div>
				<div class="putme-display-inline3 spt-header-smr w3-hide-large"><i class="fa fa-envelope spt-header-smr"></i> support@aksu.edu.ng</div>
				<div class="putme-display-inline3">|</div><div class="putme-display-inline3  w3-hide-large"> &nbsp;&nbsp;&nbsp;<i title="PLACE A CALL" class="fa fa-phone alv2-phne-contr w3-large '.$colr.' putme-smr-sh-phon" onclick="__I.showPhoneNos()" style="cursor:pointer;position:relative;z-index:2;"></i></div>
				<div class="putme-display-inline3 '.$colr.' w3-hide-small w3-hide-medium"><i class="fa fa-envelope"></i> support@aksu.edu.ng</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium">|</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium"><i class="fa fa-phone"></i> +2347032874388</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium">|</div>
				<div class="putme-display-inline3 '.$colr.' w3-hide-small w3-hide-medium"><i class="fa fa-phone"></i> +2348180540499</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium">|</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium"><i class="fa fa-phone"></i> +2348068693680</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium">|</div>
				<div class="putme-display-inline3 w3-hide-small w3-hide-medium"><i class="fa fa-phone"></i> +2348022269656</div>
			</div>
		</div>
		<div id="getPhCnt" class="w3-text-white alv2-phn-cnt-smr w3-hide-large" style="position:fixed;bottom:40px;right:0;width:0px;height:155px;overflow:none;background-color: rgb(0, 0, 0);background-color: rgba(0, 0, 0,0.9);padding:1px;border-radius:5px;transition: 0.4s ease-in-out;">
			<div onclick="window.open(\'tel:+2348023635890\')" id="zph_n0" class="w3-row w3-animate-right" style="margin-top:7px;display:none;transition:0.4s ease-in-out 2s;">
				<div class="putme-displ-inl-sidbr1">+23480<span class="'.$colr.'">236</span>35890</div>
				<div class="putme-displ-inl-sidbr1"><i class="fa fa-phone alv2-phne-contr '.$colr.'"></i></div>
			</div>
			<div onclick="window.open(\'tel:+2347032874388\')" id="zph_n1" class="w3-row w3-animate-right" style="margin-top:7px;display:none;transition:0.4s ease-in-out 2s;">
				<div class="putme-displ-inl-sidbr1">+23470<span class="'.$colr.'">328</span>74388</div>
				<div class="putme-displ-inl-sidbr1"><i class="fa fa-phone alv2-phne-contr '.$colr.'"></i></div>
			</div>
			<div onclick="window.open(\'tel:+2348155212097\')" id="zph_n2" class="w3-row w3-animate-right" style="margin-top:7px;display:none;transition:0.4s ease-in-out 2s;">
				<div class="putme-displ-inl-sidbr1">+23481<span class="'.$colr.'">552</span>12097</div>
				<div class="putme-displ-inl-sidbr1"><i class="fa fa-phone alv2-phne-contr '.$colr.'"></i></div>
			</div>
			<div onclick="window.open(\'tel:+2348022269656\')" id="xph_n3" class="w3-row w3-animate-right" style="margin-top:7px;display:none;transition:0.4s ease-in-out 2s;">
				<div class="putme-displ-inl-sidbr1">+23480<span class="'.$colr.'">222</span>69656</div>
				<div class="putme-displ-inl-sidbr1"><i class="fa fa-phone alv2-phne-contr '.$colr.'"></i></div>
			</div>
		</div>
	</div>
	';
	
	return $output;
	}

    public function inputFrame($id_1,$descp1,$contentFram,$brcolr){
		$output =<<<_INPUTFRAME
			<div id="$id_1" style="position:relative;">
				<div class="cor-border-bottom"><strong>$descp1</strong></div>
				<div class="w3-container" style="padding:2px;">
					<div class="$brcolr" style="width:100%;height:140px;border-bottom-left-radius:1px;border-bottom-right-radius:1px;">
						<div class="" style="padding:2px;">
							$contentFram
						</div>
					</div>
				</div>
			</div>
_INPUTFRAME;
return $output;
		}

		public function inputlogoutSecur($id_1,$descp1,$contentFram){
			$output =<<<_INPUTFRAME
				<div id="$id_1">
					<div class="w3-border-bottom">$descp1</div>
					<div class="w3-container" style="padding:2px;">
						<div class="w3-white" style="width:100%;height:150px;">
							<div class="" style="padding:5px;">
								$contentFram
							</div>
						</div>
					</div>
				</div>
_INPUTFRAME;
return $output;
            }
//mpdf v6.1.3
public function generategeneratePDFv6($html,$marginLeft,$marginRight,$watermakText,$footer = ""){
    include dirname(__FILE__)."./../../LIB/mpdf-6.1.3/mpdf.php";
    //include("../../../LIB/mpdf-6.1.3/mpdf.php");
    $mpdf=new mPDF('','',0,'',$marginLeft,$marginRight,1,15,0,0,'P');
    $mpdf->SetTitle('Print Slip');
    $stylsheet = file_get_contents('../../../LIB/w3c.CSS');
    $stylsheet1 = file_get_contents('../../ui/asset/css/main.css');
    $stylsheet2 = file_get_contents('../../ui/asset/css/core.css');
    $mpdf->SetDisplayMode('fullpage');
    $mpdf->SetWatermarkText("$watermakText");
    $mpdf->showWatermarkText = true;
    $mpdf->SetFooter('<div style="margin:0px;">{PAGENO} / {nb}</div>');
    $mpdf->WriteHTML($stylsheet,1);
    $mpdf->WriteHTML($stylsheet1,1);
    $mpdf->WriteHTML($stylsheet2,1);
    $mpdf->WriteHTML($html,2);
    $mpdf->Output();
    //exit;
    }
	// v7
	public function generatePDF($html,$marginLeft,$marginRight,$watermakText){
		require_once __DIR__ . '../../../LIB/vendorv7/autoload.php';
		$mpdf = new Mpdf\mPDF([
			'mode' => 'UTF-8',
			'format' => 'Legal',//
			'default_font_size' => 0,//
			'default_font' => '',
			'margin_left' => $marginLeft,//
			'margin_right' => $marginRight,//
			'margin_top' => 5,//
			'margin_bottom' => 16,//
			// 'margin_header' => 9,
			// 'margin_footer' => 9,
			'orientation' => 'P',//
		]);
	$mpdf->SetTitle('Print Slip');
	$stylsheet = file_get_contents('../assets/w3c.CSS');
	$stylsheet1 = file_get_contents('../assets/cssRevision.css');
	$mpdf->SetWatermarkText("$watermakText");
	$mpdf->showWatermarkText = true;
	$mpdf->setFooter('{PAGENO}');
	$mpdf->WriteHTML($stylsheet,1);
	$mpdf->WriteHTML($stylsheet1,1);
	$mpdf->WriteHTML($html,2);
	$mpdf->SetDisplayMode('fullpage');
	// $mpdf->SetFooter('{PAGENO} / {nb}');
	$mpdf->Output('mpdf.pdf', \Mpdf\Output\Destination::INLINE);
	}
	//send bulk or single sms
	public function sendEbulkSMS($SName,$messagetext,$recipients){
		// $gettxt = $SName." ".$messagetext." ".$recipients;
		// //echo strlen($messagetext);
		// return $gettxt;
		$sendToBetasms = "";
		$getsplitedMobilNum = explode(",",$recipients);
		foreach($getsplitedMobilNum as $values){ //loop and send 500 numbers per at once
			$suNum =  trim(substr($values,1));
			$sendToBetasms.= "234".$suNum.",";
		}
		$sendToBetasms =  rtrim($sendToBetasms,",");
		$query_str = http_build_query(array(
			"username" => 'enefiokduke@aksu.edu.ng',
			"apikey" => 'f4dd291643903ecc1068bbf34cbd7a838bedfdbf',
			"sender" => $SName,//sender name e.g FOLIM or TAQUATECH
			"messagetext" => $messagetext,//sender msg
			"flash" => 0,
			"recipients" => trim($sendToBetasms)
		));
		$url = 'http://api.ebulksms.com:8080/sendsms?'.$query_str;
		$handle = curl_init();
		curl_setopt($handle, CURLOPT_URL, $url);
		$data = curl_exec($handle);
		curl_close($handle);
		return $data;
	}
	
	//proper checks for passport
	public function fInfoFileHandler($filename,$p_H9){
		// Get file info
		$finfo = new finfo();
		$fileinfo = $finfo->file($filename);                    // return JPEG image data, JFIF standard 1.01, resolution (DPI), density 72x72, segment length 16, progressive, precision 8, 875x350, frames 3
		$info = $finfo->file($filename, FILEINFO_MIME);         // return 'image/jpeg; charset=binary'
		$type = $finfo->file($filename, FILEINFO_MIME_TYPE);    // return 'image/jpeg'
		switch($type){
			case 'image/jpg':
			case 'image/jpeg':
			case 'image/gif':
			case 'image/png':
				// code...
				echo $this->fileUpoadAndCheckingStaf("../images/resources/",$filename,"".$p_H9."");
				break;

			default:
				// error...
				echo 'Password Upload Failed';
				break;
		}
	}
	//generate 10 digit number
	public function gidi10(){
		$tranDDTEST =  mt_rand(10000, 99999);
		$tranIDD =  mt_rand(788, 998);
		$getSUBtr = substr(time(),8);
		$transId = $tranDDTEST.$tranIDD.$getSUBtr;
		return $transId;
	}
	//generate 20 digit number
	public function gidi22(){
		$tranDDTEST =  mt_rand(1000000, 9999999);
		$tranIDD =  mt_rand(7888, 9988);
		$getSUBtr = substr(time(),9);
		$dateTm = date('msdhH');
		$transId = $tranDDTEST.$tranIDD.$getSUBtr.$dateTm;
		return $transId;
	}
    		//file checking and upload for first sitting
		public function fileUpoadAndCheckingStaf($partToFileUpload,$getEleFileName,$stafName){
			//return $partToFileUpload.' '.$getEleFileName.' '.$stafName;exit;
			//$target_dir = "../uploads/";
			$target_dir = $partToFileUpload;//note $partToFileUpload=../uploads/,$getEleFileName=file1
				$target_file = $target_dir . basename($_FILES[$getEleFileName]["name"]);
				$getLPSLASHplus = (strrpos("".$target_file."","/"))+1;
				$getLPSLASHplus1 = (strrpos("".$target_file."",""))+0;//this to to remove ../../epconfig/UserImages/STAFF/staffname.jpeg and be left with staffname.jpeg
				$getWordbwdtwo = substr_replace("".$target_file."","".$stafName."","".$getLPSLASHplus."",-4);
				$getWordbwdtwo1 = substr_replace("".$target_file."","".$stafName."","".$getLPSLASHplus1."",-4);
					$uploadOk = 1;
						$imageFileType = strtolower(pathinfo($getWordbwdtwo,PATHINFO_EXTENSION));
							// Check if image file is a actual image or fake image
							if(isset($_POST[$getEleFileName])) {
							$check = getimagesize($_FILES[$getEleFileName]["tmp_name"]);
							if($check !== false) {
								echo "File is an image - " . $check["mime"] . ".";
								$uploadOk = 1;
							} else {
								//echo "File is not an image.";
								return "@";
								//$uploadOk = 0;
							}
						}
							//exit();
							// Check if file already exists
							//if (file_exists($getWordbwdtwo)) {
								//echo "Sorry, file already exists.";
							//	return "@&";
							//	$uploadOk = 0;
							//}
							//exit();
							// Check file size
							if ($_FILES[$getEleFileName]["size"] > 100000) {
								//echo "Sorry, your file is too large.";
								return "@&@";
								//$uploadOk = 0;
							}
							//exit();
							// Allow certain file formats
							if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "gif" && $imageFileType !="jpeg" ) {
								//echo "Sorry, only JPG, JPEG, PDF, PNG & GIF files are allowed.";
								return "&@";
								//$uploadOk = 0;
							}
							/////
							////
							//exit();
							// Check if $uploadOk is set to 0 by an error

							if ($uploadOk == 0) {
								//echo "Sorry, your file was not uploaded.";
								return "9@";
							// if everything is ok, try to upload file

								} else {
									if (move_uploaded_file($_FILES[$getEleFileName]["tmp_name"], $getWordbwdtwo)) {
										//echo "The file ". basename( $_FILES[$getEleFileName]["name"]). " has been uploaded.";
											$dosya = $_FILES[$getEleFileName]["name"];
											//return 	$dosya;
											return 	$getWordbwdtwo1;
											//return 	 "3@";
											
									} else {
										//echo "Sorry, there was an error uploading your file.";
										return "2@";
									}
								}

		}//end of fileUpoadAndChecking method
    //function toupload image
	public function returnImage($imgeName,$imgWidth,$imgHeight){
		$imagePhoto = '<img id="repl" class="w3-circle w3-center" src="images/resources/'.$imgeName.'" width="'.$imgWidth.'" height="'.$imgHeight.'" alt="photo" >';
		return $imagePhoto;
	}
	public function returnImagesqure($imgeName,$imgWidth,$imgHeight){
		$imagePhoto = '<img id="repl" class=" w3-center" src="../'.$imgeName.'" width="'.$imgWidth.'" height="'.$imgHeight.'" alt="photo" >';
		return $imagePhoto;
    }
    function insertBodyCSS(){
        return '<link href="../css/w3c.CSS" rel="stylesheet" type="text/css" />
        <link href="../css/main.css" rel="stylesheet" type="text/css" />
        <link href="../assets/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <script src="../js/IntelligentJS.js" type="text/javascript"></script>
        <style>
            body{
                background-image:url("../Images/bg6.jpg");
                background-repeat:no-repeat;
                background-size:cover;
                background-position:center;
                background-attachment:fixed;
                margin: 0;
                padding: 0;
            }
        </style>
        ';
    }
    //  log page
	public function logPage(){
		//echo $this->insertBodyCSS();
		return <<<_PIN
		<div id="exitsubPinPg" class="putme-PinLog-cont1 w3-animate-opacity">
			<div style="position:relative;width:100%;height:100%;overflow:hidden;">
				<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);color:white;width:300px;height:400px;background-color:white;border-radius:10px;">
					<div style="width:width:100%;height:100px;background-color: #e71f05!important;color:white;border-top-left-radius:10px;border-top-right-radius:10px;position:relative;">
						<div class="cor-text1-shaow" style="text-align:center;"><strong>ENTER PIN</strong></div>
						<div style="position:absolute;bottom:0;width:100%;height:50px;padding:10px;">
							<div title="CLEAR" class="w3-center">
								<input id="getTvlue" type="hidden">
								<span id="getCalVal"></span>
								<div onclick="__I.Pin.calclear(this,'getCalVal')" class="w3-right"><div class="w3-circle w3-button w3-light-grey w3-small" style="margin-top:-10px;">X</div></div>
							</div>
						</div>
					</div>
					<div class="w3-container">
						<div class="w3-row-padding w3-margin">
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">7</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">8</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">9</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">A</button>
							</div>
						</div>
						<div class="w3-row-padding w3-margin">
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">4</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">5</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">6</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">B</button>
							</div>
						</div>
						<div class="w3-row-padding w3-margin">
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">1</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">2</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">3</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">C</button>
							</div>
						</div>
						<div class="w3-row-padding w3-margin">
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">0</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">*</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button w3-light-grey w3-circle w3-large">@</button>
							</div>
							<div class="w3-col s3">
								<button onclick="__I.Pin.calC(this,'exitsubPinPg','exitLogPinpage','getCalVal','getTvlue')" class="w3-button  w3-circle w3-large" style="background-color: #e71f05!important;color:white;">#</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
_PIN;
	}
   	//function that allows u to call day automatically
	public function selectDay(){
			//date
	//echo '<select name="day">';
	for($i = 1; $i <= 31; $i++){
		echo "<option value=\"$i\">$i</option>";
	} 
	}
	//function that allows u to call month automatically
	public function selectMonth(){
				//month
	//echo '<select name="month">';
	for($i = 1; $i <= 12; $i++){
		$dt = DateTime::createFromFormat('!m', $i);
		echo "<option value=\"$i\">".$dt->format('F')."</option>";
	}
	}
	//function that allows u to call year automatically
	public function selectYear(){
	//year
	//echo '<select name="year">';
	for($i = date('Y'); $i >= date('Y', strtotime('-90 years')); $i--){
	echo "<option value=\"$i\">$i</option>";
	} 
	}
	//method to remove string and return only numbers
	public function getNumFromStr($getStr){
	return preg_replace('/[^0-9]/', '', $getStr);
	} 
	public function SendMail($from,$to,$subject,$body,$attachement=[]){
		//$attachement should have the following structure [["FilePath","FileMime"],....]
	include('Mail.php'); // includes the PEAR Mail class, already on your server.
	include 'Mail/mime.php' ;
	$username = 'ngmoinfo@ngmsys.a2hosted.com'; // your email address
	$password = 'Antman1234@#'; // your email address password
	$text = strip_tags($body);
	$html = '<html><body>'.$body.'</body></html>';
	$crlf = "\n";
	$mime = new Mail_mime(array('eol' => $crlf));
	
	$mime->setTXTBody($text);
	$mime->setHTMLBody($html);
	if(count($attachement) > 0){
		foreach($attachement as $attach){
			$att= $mime->addAttachment($attach[0], $attach[1]);
			if (PEAR::isError($att)){
			return "<p>" . $att->getMessage() . "</p>";
			}
		}
	}
	//$file = './mailatt.txt';
	
	
	$headers = array ('From' => $from, 'To' => $to, 'Subject' => $subject); // the email headers
	$body = $mime->get();
	$headers = $mime->headers($headers);
	$smtp = Mail::factory('smtp', array ('host' =>'localhost', 'auth' => true, 'username' => $username, 'password' => $password, 'port' => '25')); // SMTP protocol with the username and password of an existing email account in your hosting account
	$mail = $smtp->send($to, $headers, $body); // sending the email
	if (PEAR::isError($mail)){
	return "<p>" . $mail->getMessage() . "</p>";
	}
	else {
	return true;
	// header("Location: http://www.example.com/"); // you can redirect page on successful submission.
	}
	}

}
$_P = new AIM__I();
?>