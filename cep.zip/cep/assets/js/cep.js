var CEP = {
    Engine:{
        preNxtEngine:{
            holdVistedPages:[],
            keepPagesID:[],
            holdLastVisitedArrIndex:null,
            enter:false,
            setPreviousPage:(page,moduleTile,menuNameDescr)=>{
                const container = document.createElement('div');
                container.id = 'divId_'+Date.now()+Math.random();
                container.className  = 'divId_all';
                container.innerHTML = page;
                container.style.display = "none";
                CEP.Engine.preNxtEngine.holdTiles.push(moduleTile);
                CEP.Engine.preNxtEngine.holdSubTiles.push(menuNameDescr);
                CEP.Engine.preNxtEngine.holdVistedPages.push(container.id);
                document.body.appendChild(container);
            },
            holdTiles:[],
            holdSubTiles:[],
            callBackPages:()=>{
                if(CEP.Modules.RegisterNow.regLvl == 4){
                    const parentElement = document.querySelector("#inerCntMot");
                    const childElements = parentElement.children;
                    while (childElements.length > 1) {
                    parentElement.removeChild(childElements[0]);
                    }
                    CEP.Engine.preNxtEngine.removeBackArrow();
                    let holdT = document.getElementsByClassName("cep__pageCount")[0].getAttribute("data-titlename");
                    if(holdT==undefined)return;
                    holdT = JSON.parse(holdT);
                    _('holdHeader__inner').innerText = holdT.titleName;
                    CEP.Modules.RegisterNow.holdOlvSuj2 = {};
                    CEP.Modules.RegisterNow.holdOlvSuj1 = {};
                    return;
                }
                const list = document.getElementById("inerCntMot");
                list.removeChild(list.firstElementChild);
                CEP.Engine.preNxtEngine.removeBackArrow();
                let holdT = document.getElementsByClassName("cep__pageCount")[0].getAttribute("data-titlename");
                if(holdT==undefined)return;
                holdT = JSON.parse(holdT);
                _('holdHeader__inner').innerText = holdT.titleName;
                CEP.Modules.RegisterNow.holdOlvSuj2 = {};
                CEP.Modules.RegisterNow.holdOlvSuj1 = {};
            },
            backRowHTML:()=>{
                return '<div id="getRR" title="Previous" class="w3-text-white w3-large cor-pointer" style="display:block;transition:0.4s ease-in-out 0s"><i onclick="CEP.Engine.preNxtEngine.callBackPages()" class="fas fa-long-arrow-alt-left vik-CEP-btn-inner-txt" style="width:30px;margin-top:2px;"></i></div>';
            },
            removeBackArrow:()=>{
                var parentEl = _('inerCntMot');
                const childern = parentEl.children;
                if(childern.length > 1){
                    _('holdPreviousIcon').innerHTML = CEP.Engine.preNxtEngine.backRowHTML();
                }else{
                    _('holdPreviousIcon').innerHTML = "";
                }
            },
            clearRemoteOutstanding:()=>{
                if(CEP.Engine.preNxtEngine.holdVistedPages.length > 0){
                    let cl = document.getElementsByClassName('divId_all');
                    for(let i = 0; i < CEP.Engine.preNxtEngine.holdVistedPages.length; i++) {
                        document.getElementById(CEP.Engine.preNxtEngine.holdVistedPages[i]).outerHTML = "";
                    }
                    // clear with class too
                    for(let j = 0; j < cl.length; j++){
                        cl[j].outerHTML = '';
                    }
                    // clear the array
                    CEP.Engine.preNxtEngine.holdVistedPages = [];
                    CEP.Engine.preNxtEngine.holdTiles = [];
                    CEP.Engine.preNxtEngine.holdSubTiles = [];
                    _('holdPreviousIcon').innerHTML = '';
                    CEP.Modules.Sales.cartStock = false;
                }
            },
            currentYearTxt:'',
            callYear:()=>{
                var CurrentYear = new Date().getFullYear();
                Fom.Controller.currentYearTxt = CurrentYear;
                _('getCurYear').innerText = CurrentYear;
            },
            showPopup:(previoeIcon,headerTitle,innCnt)=>{
                __I.S_how('sideNav_id');
                _('sideNav_id').classList.add('w3-animate-opacity');
                _('sideNav_id').classList.remove('come-slide-down');
                _('holdPreviousIcon').innerHTML = previoeIcon===''?'':previoeIcon;
                _('holdHeader').innerHTML = headerTitle;
                _('inerCntMot').innerHTML = innCnt;
    
            },
        },
        moduleName:'',
        moduleID:'',
        popModal:()=>{
            //document.getElementsByClassName('vik-popup-cnt')[0].classList.add('vik-pop-contro');
            __I.S_how('sideNav_id');
        },
        exitWindow:function(id_main_win){
            _(id_main_win).classList.remove('w3-animate-opacity');
            _(id_main_win).classList.add('come-slide-down');
            setTimeout(()=>{_(id_main_win).style.display = 'none';_(id_main_win).classList.remove('come-slide-down');},500);
            _('inerCntMot').innerHTML = '';
        },
        exitOlvWindow:function(id_main_win){
            _(id_main_win).style.display = 'none';
            // setTimeout(()=>{_(id_main_win).style.display = 'none';_(id_main_win).classList.remove('come-slide-down');},500);
            // _('inerCntMot').innerHTML = '';
        },
        controlAjax:(URL,param,moduleName,menuContrID)=>{
            // __I.notifyLoader.notify('Loading '+moduleName.toLowerCase()+'...');
            var holdObj = {};
            holdObj['data'] = param==''?'':param;
            _(menuContrID).classList.add('cor-go-out-slowly');
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        __I.notifyLoader.exitNoyify();
                        var responsses = __I.T_trim(this.responseText);
                        try {
                            jesm = JSON.parse(responsses);
                            _(menuContrID).classList.remove('cor-go-out-slowly');
                            _(menuContrID).innerHTML = jesm.SUCCESS.Message;
                            // _('getModuleName').innerHTML = moduleName;
                        } catch (error) {
                           __I.FormAlart.mainInit('Loading error...');
                        }
                    }
                }
            },"data="+encodeURIComponent(JSON.stringify(holdObj)));
        },
        controlPaymentAjax:(URL,param,menuContrID)=>{
            // __I.notifyLoader.notify('Loading '+moduleName.toLowerCase()+'...');
            // var holdObj = {};
            // holdObj['data'] = param==''?'':param;
            _(menuContrID).classList.add('cor-go-out-slowly');
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        __I.notifyLoader.exitNoyify();
                        var responsses = __I.T_trim(this.responseText);
                        // console.log(responsses);return;
                        try {
                            // jesm = JSON.parse(responsses);
                            _(menuContrID).classList.remove('cor-go-out-slowly');
                            _(menuContrID).innerHTML = responsses;
                            // _('getModuleName').innerHTML = moduleName;
                        } catch (error) {
                           __I.FormAlart.mainInit('Loading error...contact ict');
                        }
                    }
                }
            },"data="+encodeURIComponent(JSON.stringify(param)));
        },
        activeTabs:(moduleID,menuContrID,moduleName,menuURL)=>{
            let i,cl;
            cl = document.getElementsByClassName('vik-contr-active');
            for(i = 0; i < cl.length; i++){
                cl[i].classList.remove('vik-contr-active-tab');
            }
            cl['trModul_'+moduleID].classList.add('vik-contr-active-tab');
            CEP.Engine.menuController(menuContrID,moduleName,menuURL,moduleID);
            CEP.Engine.moduleName = moduleName;
            CEP.Engine.moduleID = moduleID;
            // document.getElementsByClassName('vik-link-smr-hgt-wid-subnav')[0].remove('vik-smr-none');
            _('gtSubNav').classList.remove('vik-smr-none');
            _('appSideNav').classList.add('vik-subNav-width-tr');

        },
        menuController:(menuContrID,moduleName,menuURL,moduleID)=>{
            CEP.Engine.controlAjax(menuURL,moduleID,moduleName,menuContrID);
        },
    },
    Modules: {
        cep__ModeOfEntry:null,
        menuNameDescr:'',
        grandParent:'',
        Stabilizer:{
            controller:(obj)=>{
                __I.notifyLoader.notify(obj.menuHeaderTitle+'...');
                ajaxPOST("ui/ajax/cep/"+obj.url+".php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            __I.notifyLoader.exitNoyify();
                            var responsses = __I.T_trim(this.responseText);
                            // console.log(responsses);
                            try {
                                var responsses = JSON.parse(responsses);
                                __I.S_how('sideNav_id');
                                __I.S_how('hideMePls');
                                _('holdHeader__inner').innerText = obj.menuHeaderTitle;
                                // console.log(responsses.SUCCESS.Message);
                                CEP.Modules.grandParent = _('inerCntMot');
                                CEP.Modules.grandParent.insertAdjacentHTML("afterbegin",responsses.SUCCESS.Message);
                                __I.H_ide('hideMePls');
                                CEP.Engine.preNxtEngine.removeBackArrow();
                            } catch (error) {
                            __I.FormAlart.mainInit('Loading error...'+error);
                            }
                        }
                    }
                },"data="+encodeURIComponent(JSON.stringify({})));
            },
            startNow:(menuHeaderTitle,cep__ModeOfEntry,subDescr,url)=>{
                __I.notifyLoader.notify('Loading '+menuHeaderTitle.toLowerCase()+'...');
                ajaxPOST("ui/ajax/cep/pages/"+url+"",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            __I.notifyLoader.exitNoyify();
                            // console.log(responsses);
                            _('inerCntMot').classList.add('cor-go-out-slowly');
                            try {
                                setTimeout(()=>{
                                    var responsses = __I.T_trim(this.responseText);
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.cep__ModeOfEntry = cep__ModeOfEntry;
                                    _('holdHeader__inner').innerText = menuHeaderTitle;
                                    _('inerCntMot').classList.remove('cor-go-out-slowly');
                                    CEP.Modules.grandParent.insertAdjacentHTML("afterbegin",responsses.SUCCESS.Message);
                                    CEP.Engine.preNxtEngine.removeBackArrow();
                                },500);
                            } catch (error) {
                            __I.FormAlart.mainInit('Loading error...'+error);
                            }
                        }
                    }
                },"data="+encodeURIComponent(JSON.stringify({"subDescr":subDescr,"menuHeaderTitle":menuHeaderTitle})));
            },
            nextPages:(menuHeaderTitle,subDescr,url,otherParam,jsonParam)=>{
                ajaxPOST(""+url+"",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            _('inerCntMot').classList.add('cor-go-out-slowly');
                            try {
                                setTimeout(()=>{
                                    var responsses = __I.T_trim(this.responseText);
                                    _('holdHeader__inner').innerText = menuHeaderTitle;
                                    _('inerCntMot').classList.remove('cor-go-out-slowly');
                                    CEP.Modules.grandParent.insertAdjacentHTML("afterbegin",responsses);
                                    CEP.Engine.preNxtEngine.removeBackArrow();
                                },500);
                            } catch (error) {
                            __I.FormAlart.mainInit('Loading error...'+error);
                            }
                        }
                    }
                },"data="+encodeURIComponent(JSON.stringify({"subDescr":subDescr,"otherParam":otherParam,"cep__phone__":CEP.Modules.RegisterNow.holdRegNum,"cep__ModeOfEntry":CEP.Modules.cep__ModeOfEntry,"jsonParam":jsonParam})));
            },
        },
        RegisterNow:{
             phonenumber:(inputtxt)=>{
                var phoneno = /^\d{11}$/;
                if((inputtxt.match(phoneno))){
                    return true;
                    }else{
                        return false;
                    }
            },
            holdRegNum:'',
            verificationProcess:(menuHeaderTitle,url)=>{
                __I.notifyLoader.notify(menuHeaderTitle.toLowerCase()+'...');
                if(CEP.Modules.RegisterNow.phonenumber(_('cep__phone__').value) == true) {
                    __I.H_ide('NextBtn__');
                    __I.S_how('showProgress__');
                    var API = 'api/registration/Verify_candidate/';
                    // ajaxPOST("script/cep/"+url+".php",function(){
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide('showProgress__');
                                __I.S_how('NextBtn__');
                                var responsses = __I.T_trim(this.responseText);
                                console.log(responsses);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.RegisterNow.holdRegNum = __I.T_trim(_('cep__phone__').value);
                                    CEP.Modules.RegisterNow.regLvl = responsses.SUCCESS.Reglvl;
                                    CEP.Modules.Stabilizer.nextPages(responsses.SUCCESS.menuHeaderTitle,'',responsses.SUCCESS.Message,responsses.SUCCESS.amt,{"passport":responsses.SUCCESS.passport,"Name":responsses.SUCCESS.Name,"moe":responsses.SUCCESS.moe,"Programme":responsses.SUCCESS.Programme,"Gender":responsses.SUCCESS.Gender});
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__phone__":__I.T_trim(_('cep__phone__').value),"cep__ModeOfEntry":CEP.Modules.cep__ModeOfEntry})));
                }else{
                    __I.FormAlart.mainInit('Wrong phone number');
                    __I.notifyLoader.exitNoyify();
                }
            },
            basicDetails:(menuHeaderTitle,url)=>{
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                __I.H_ide('NextBtn__pages__2');
                    __I.S_how('showProgress__pages__2');
                    var API = 'api/registration/capture_candidate/';
                    // ajaxPOST("script/cep/"+url+".php",function(){
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide('showProgress__pages__2');
                                __I.S_how('NextBtn__pages__2');
                                var responsses = __I.T_trim(this.responseText);
                                // console.log(responsses);return;
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.Stabilizer.nextPages(responsses.SUCCESS.menuHeaderTitle,'',responsses.SUCCESS.Message,responsses.SUCCESS.amt);
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__phone__":CEP.Modules.RegisterNow.holdRegNum,"cep__ModeOfEntry":CEP.Modules.cep__ModeOfEntry,"cep__surnm":__I.T_trim(_('cep__surnm').value),"cep__firstnm":__I.T_trim(_('cep__firstnm').value),"cep__othernm":__I.T_trim(_('cep__othernm').value),"cep__gendr":__I.T_trim(_('cep__gendr').value)})));
            },
            processPayment:(menuHeaderTitle,url)=>{
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                // __I.H_ide('NextBtn__pages__2');
                //     __I.S_how('showProgress__pages__2');
                var API = 'api/registration/process_payment/';
                    ajaxPOST(API,function(){
                        // ajaxPOST("script/cep/"+url+".php",function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                // __I.H_ide('showProgress__pages__2');
                                // __I.S_how('NextBtn__pages__2');
                                var responsses = __I.T_trim(this.responseText);
                                console.log(responsses);
                                try {
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.Modulator.holdSucessPrint = responsses.SUCCESS.reportP;
                                    CEP.Modules.RegisterNow.__sendClearOut(responsses.SUCCESS.Message,responsses.SUCCESS.reportP[1]);
                                    __I.S_how('sideNav_idcep');
                                } catch (error) {
                                    
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__phone__":CEP.Modules.RegisterNow.holdRegNum,"cep__ModeOfEntry":CEP.Modules.cep__ModeOfEntry})));
            },
            verifyAdmissionProcess:(menuHeaderTitle,url)=>{
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                __I.H_ide('NextBtn__bio');
                    __I.S_how('showProgress__bio');
                var API = 'api/admission/verify_admission/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide('showProgress__bio');
                                __I.S_how('NextBtn__bio');
                                var responsses = __I.T_trim(this.responseText);
                                console.log(responsses);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.RegisterNow.holdRegNum = responsses.SUCCESS.JambNo;
                                    CEP.Modules.RegisterNow.regLvl = responsses.SUCCESS.Reglvl + 1;
                                    CEP.Modules.Stabilizer.nextPages(responsses.SUCCESS.menuHeaderTitle,'',responsses.SUCCESS.Message,'',{"passport":responsses.SUCCESS.passport,"Name":responsses.SUCCESS.Name,"moe":responsses.SUCCESS.moe,"Programme":responsses.SUCCESS.Programme,"Gender":responsses.SUCCESS.Gender});
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__phone__":__I.T_trim(_('cep__jmb__').value)})));
            },
            genRegSlip:(responsses)=>{
                // window.location = 'script/printers/slip.php?s_t='+responsses+'&separator=3';return;
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?s_t='+responsses+'&separator=3');
            },
            genBiodataRegSlip:(responsses)=>{
                if(isNaN(responsses)){responsses = Telemedicine.Login.holdRegno}
                // window.location = 'script/printers/slip.php?s_t='+responsses+'&separator=4';return;
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?s_t='+responsses+'&separator=4');
            },
            biodataFormReg:(menuHeaderTitle,url)=>{
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                __I.H_ide('NextBtn__bio');
                    __I.S_how('showProgress__pages__formbio');
                var API = 'api/admission/capture_candidate/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide('showProgress__pages__formbio');
                                __I.S_how('NextBtn__bio');
                                var responsses = __I.T_trim(this.responseText);
                                //   console.log(responsses);return;
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.RegisterNow.holdRegNum = responsses.SUCCESS.JambNo;
                                    CEP.Modules.RegisterNow.regLvl = responsses.SUCCESS.Reglvl;
                                    CEP.Modules.Stabilizer.nextPages(responsses.SUCCESS.menuHeaderTitle,'',responsses.SUCCESS.Message,'',{"passport":responsses.SUCCESS.passport,"Name":responsses.SUCCESS.Name,"moe":responsses.SUCCESS.moe,"Programme":responsses.SUCCESS.Programme,"Gender":responsses.SUCCESS.Gender});
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__phone__":__I.T_trim(_('cep__jmb__').value),"cep__name__bioda":__I.T_trim(_('cep__name__bioda').value),"cep__phone__biodata":__I.T_trim(_('cep__phone__biodata').value),"cep__address__nok":__I.T_trim(_('cep__address__nok').value)})));
            },
            processBiodataPayment:(menuHeaderTitle,moe)=>{
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                // __I.H_ide('NextBtn__pages__2');
                //     __I.S_how('showProgress__pages__2');
                var API = 'api/admission/process_acceptance_payment/';
                    ajaxPOST(API,function(){
                        // ajaxPOST("script/cep/"+url+".php",function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                // __I.H_ide('showProgress__pages__2');
                                // __I.S_how('NextBtn__pages__2');
                                var responsses = __I.T_trim(this.responseText);
                                console.log(responsses);
                                try {
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.Modulator.holdSucessPrint = responsses.SUCCESS.reportP;
                                    CEP.Modules.RegisterNow.ragPayee = responsses.SUCCESS.Pay_Item;
                                    CEP.Modules.RegisterNow.__sendClearOut(responsses.SUCCESS.Message,responsses.SUCCESS.reportP[1]);
                                    __I.S_how('sideNav_idcep');
                                } catch (error) {
                                    
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__phone__":CEP.Modules.RegisterNow.holdRegNum,"cep__ModeOfEntry":moe})));
            },
            contactInformation:(menuHeaderTitle,url)=>{
                if(CEP.Modules.RegisterNow.phonenumber(_('cep__phoneno').value) != true)return __I.FormAlart.mainInit('Wrong phone number');
                // if(__I.phonenumber(_('cep__sponsorphonumber').value) != true)return __I.FormAlart.mainInit('Wrong phone number');
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                    var data = new FormData();
                    data.append("file1", document.querySelector("#file_15").files[0]);
                    data.append("getAllFromAjax", JSON.stringify({"cep__dob":__I.T_trim(_('cep__dob').value),"cep__homeaddress":__I.T_trim(_('cep__homeaddress').value),"cep__maritsts__page3":__I.T_trim(_('cep__maritsts__page3').value),"cep__spouseName":__I.T_trim(_('cep__spouseName').value),"cep__phoneno":__I.T_trim(_('cep__phoneno').value),"cep__email":__I.T_trim(_('cep__email').value),"cep__nationality":__I.T_trim(_('cep__nationality').value),"cep__lga":__I.T_trim(_('cep__lga').value),"cep__sponsorName":__I.T_trim(_('cep__sponsorName').value),"cep__statID":__I.T_trim(_('cep__statID').value),"cep__sponsorAddress":__I.T_trim(_('cep__sponsorAddress').value),"cep__sponsorphonumber":__I.T_trim(_('cep__sponsorphonumber').value),"cep__ModeOfEntry":CEP.Modules.cep__ModeOfEntry,"cep__jambNo__":CEP.Modules.RegisterNow.holdRegNum}));
                    __I.H_ide('NextBtn__pages__3');
                    __I.S_how('showProgress__pages__3');
                    var API = 'api/registration/process_contact_details/';
                    ajaxPOSTFile(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide('showProgress__pages__3');
                                __I.S_how('NextBtn__pages__3');
                                var responsses = __I.T_trim(this.responseText);
                                // console.log(responsses);return;
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                var responsses = JSON.parse(responsses);
                                CEP.Modules.Stabilizer.nextPages(responsses.SUCCESS.menuHeaderTitle,'',responsses.SUCCESS.Message);
                                    }
                                }
                            }
                        }
                    },data);
            },
            loadLGA:()=>{
                __I.notifyLoader.notify('Loading...');
                ajaxPOST("script/cep/loadlga.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            __I.notifyLoader.exitNoyify();
                            var responsses = __I.T_trim(this.responseText);
                            try {
                                var responsses = JSON.parse(responsses);
                                _('cep__lga').innerHTML = responsses.SUCCESS.Message;
                            } catch (error) {
                                __I.FormAlart.mainInit(error); 
                            }
                        }
                    }
                },"data="+encodeURIComponent(JSON.stringify({"cep__statID":_('cep__statID').value})));
            },
            SubID1:null,
            SubID2:null,
            gradeHoldID1:'',
            gradeHoldID2:'',
            subName:'',
            subName2:'',
            holdOlvSuj1:{},
            holdOlvSuj2:{},
            computeOlvResult:(SubID1,gradeHoldID1,subName)=>{
                CEP.Modules.RegisterNow.SubID1 = SubID1;
                CEP.Modules.RegisterNow.gradeHoldID1 = gradeHoldID1;
                CEP.Modules.RegisterNow.subName = subName;
                if(CEP.Modules.RegisterNow.holdOlvSuj1['olvSubjID_'+SubID1]){
                    _(CEP.Modules.RegisterNow.gradeHoldID1).innerHTML = "";
                    _(CEP.Modules.RegisterNow.gradeHoldID1).classList.remove('cep-grdholder-cnt-bgr-col');
                    delete CEP.Modules.RegisterNow.holdOlvSuj1['olvSubjID_'+SubID1];
                }else{
                    __I.S_how('getTop');
                    CEP.Engine.exitOlvWindow('getTop2');
                }
            },
            computeGrade:(gradID,gradeName)=>{

                _(CEP.Modules.RegisterNow.gradeHoldID1).innerHTML = gradeName;
                _(CEP.Modules.RegisterNow.gradeHoldID1).classList.add('cep-grdholder-cnt-bgr-col');
                CEP.Engine.exitOlvWindow('getTop');
                CEP.Modules.RegisterNow.holdOlvSuj1['olvSubjID_'+CEP.Modules.RegisterNow.SubID1] = [CEP.Modules.RegisterNow.SubID1,gradID,gradeName,CEP.Modules.RegisterNow.subName];
            },
            computeOlvResult2:(SubID2,gradeHoldID2,subName2)=>{
                CEP.Modules.RegisterNow.SubID2 = SubID2;
                CEP.Modules.RegisterNow.gradeHoldID2 = gradeHoldID2;
                CEP.Modules.RegisterNow.subName2 = subName2;
                if(CEP.Modules.RegisterNow.holdOlvSuj2['olvSubjID2_'+SubID2]){
                    _(CEP.Modules.RegisterNow.gradeHoldID2).innerHTML = "";
                    _(CEP.Modules.RegisterNow.gradeHoldID2).classList.remove('cep-grdholder-cnt-bgr-col');
                    delete CEP.Modules.RegisterNow.holdOlvSuj2['olvSubjID2_'+SubID2];
                }else{
                    __I.S_how('getTop2');
                    CEP.Engine.exitOlvWindow('getTop');
                }
            },
            computeGrade2:(gradID2,gradeName2)=>{

                _(CEP.Modules.RegisterNow.gradeHoldID2).innerHTML = gradeName2;
                _(CEP.Modules.RegisterNow.gradeHoldID2).classList.add('cep-grdholder-cnt-bgr-col');
                CEP.Engine.exitOlvWindow('getTop2');
                CEP.Modules.RegisterNow.holdOlvSuj2['olvSubjID2_'+CEP.Modules.RegisterNow.SubID2] = [CEP.Modules.RegisterNow.SubID2,gradID2,gradeName2,CEP.Modules.RegisterNow.subName2];
            },
            regLvl:null,
            ragPayee:null,
            basicAcademicDetails:(menuHeaderTitle,url)=>{
                var data = new FormData();
                if(!__I.objCount(CEP.Modules.RegisterNow.holdOlvSuj1) > 0)return __I.FormAlart.mainInit('Select olevel subject');
                data.append("firstSitObj", JSON.stringify(CEP.Modules.RegisterNow.holdOlvSuj1));
                data.append("cep__examType1", __I.T_trim(_('cep__examType1').value));
                data.append("cep__examsYear1", __I.T_trim(_('cep__examsYear1').value));
                data.append("cep__examsNumber", __I.T_trim(_('cep__examsNumber').value));
                data.append("cep__proposed__prog", __I.T_trim(_('cep__proposed__prog').value));
                data.append("cep__jambNo__", CEP.Modules.RegisterNow.holdRegNum);
                data.append("file1", document.querySelector("#file_firstsitting").files[0]);
                // comput second sititngd
                if(_('cep__examType2').value != "" || _('cep__examsYear2').value != ""){
                    if(!__I.objCount(CEP.Modules.RegisterNow.holdOlvSuj2) > 0)return __I.FormAlart.mainInit('Select Olevel Subject2');
                    if(_('cep__examsYear2').value == "" || _('cep__examsNumber2').value == "" || _('file_secondsitting').value == ""){
                        return __I.FormAlart.mainInit('Select all input in second sittings');
                    }
                    data.append("cep__examType2", __I.T_trim(_('cep__examType2').value));
                    data.append("cep__examsYear2", __I.T_trim(_('cep__examsYear2').value));
                    data.append("cep__examsNumber2", __I.T_trim(_('cep__examsNumber2').value));
                    data.append("SecondSitObj", JSON.stringify(CEP.Modules.RegisterNow.holdOlvSuj2));
                    data.append("file2", document.querySelector("#file_secondsitting").files[0]);
                }
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                    __I.H_ide('NextBtn__pages__acad');
                    __I.S_how('showProgress__pages__acad');
                    var API = 'api/registration/process_acad_details/';
                    ajaxPOSTFile(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                //CEP.Modules.RegisterNow.holdOlvSuj1 = {};
                                //CEP.Modules.RegisterNow.holdOlvSuj2 = {};
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide('showProgress__pages__acad');
                                __I.S_how('NextBtn__pages__acad');
                                var responsses = __I.T_trim(this.responseText);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                var responsses = JSON.parse(responsses);
                                CEP.Modules.RegisterNow.regLvl = responsses.SUCCESS.Reglvl;
                                CEP.Modules.Stabilizer.nextPages(responsses.SUCCESS.menuHeaderTitle,'',responsses.SUCCESS.Message,'',{"passport":responsses.SUCCESS.passport,"Name":responsses.SUCCESS.Name,"moe":responsses.SUCCESS.moe,"Programme":responsses.SUCCESS.Programme,"Gender":responsses.SUCCESS.Gender});
                                    }
                                }
                            }
                        }
                    },data);
            },
            __sendClearOut:(pointerID,amt)=>{
                // __I.notifyLoader.exitNoyify();
                // __I.S_how('sideNav_id');
                // _('sideNav_id').classList.add('w3-animate-opacity');
                _('getAmtPayAble').innerText = amt;
                _('getClickEvt__').setAttribute("onclick", "CEP.Modules.RegisterNow.loadCardRepairs('"+pointerID+"','requesturl')");
                _('getCliBankRep__').setAttribute("onclick", "CEP.Modules.RegisterNow.loadBankRepairs('"+pointerID+"','requesturl')");
            },
            loadCardRepairs:(pointerID,URL)=>{
                __I.notifyLoader.notify('initializing Payment...');
               setTimeout(()=>{
                __I.notifyLoader.exitNoyify();
               closeWindowOpen = window.open("script/payment/"+URL+".php?r="+pointerID, "AKSU", "scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,width=450,height=540,left=450,top=100");
               Records.Engine.exitWindow('sideNav_idcep');
               },1000)
            },
            loadBankRepairs:(pointerID)=>{
                alert('Use Card Option');
            },
        },
        verifyRef:{
            verifyNumbers:(menuHeaderTitle,url)=>{
                __I.notifyLoader.notify(menuHeaderTitle+'...');
                __I.H_ide('prevBtnSend__ref');
                    __I.S_how('showProgress__ref');
                    ajaxPOST("script/cep/"+url+".php",function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide('showProgress__ref');
                                __I.S_how('prevBtnSend__ref');
                                var responsses = __I.T_trim(this.responseText);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.Stabilizer.nextPages(responsses.SUCCESS.menuHeaderTitle,'',responsses.SUCCESS.Message);
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__phone__ref":__I.T_trim(_('cep__phone__ref').value)})));
            },
            verifyRefNumbers:(ref,amt)=>{
                CEP.Modules.RegisterNow.__sendClearOut(ref,amt);
                __I.S_how('sideNav_idcep');
            },
        },
        LoginHere:{
            accessPoint:()=>{
                __I.S_how('exitSubLogin__');
            },
        },
        Modulator:{
            printConfrimSlip:()=>{
                __I.notifyLoader.notify('Preparing Slip...');
               setTimeout(()=>{
                __I.notifyLoader.exitNoyify();
                // window.open('script/printers/slip.php?s_t='+__I.T_trim(_('transacID__paym__tID').innerText)+'&sSaptor='+2);return;
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?s_t='+__I.T_trim(_('transacID__paym__tID').innerText)+'&sSaptor='+2);
               },500)
            },
            closeWindowOpen:null,
            closeWindowObj:()=>{
                closeWindowOpen.close();
            },
            holdSucessPrint:null,
            rebootSuccessMsg:()=>{
                var allObj,jsnhold;
                allObj = CEP.Modules.Modulator.holdSucessPrint;
                jsnhold = {};
                jsnhold['TransID'] = allObj[0];
                jsnhold['amt'] = allObj[1];
                jsnhold['itemPaid'] = allObj[2];
                jsnhold['__Erorr'] = 0;
                __I.notifyLoader.notify('Analizing Payment...');
                ajaxPOST("ui/ajax/onsuccesserrorpage.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            _('removeLoginPage').classList.add('cor-go-out-slowly');
                            //Records.Engine.MainUser.closeWindowOpen.close();
                            var responsses = __I.T_trim(this.responseText);
                            setTimeout(function(){
                                __I.notifyLoader.exitNoyify();
                                _('removeLoginPage').classList.remove('cor-go-out-slowly');
                                _('removeLoginPage').innerHTML = responsses;
                            },500);
                        }
                    }
                 },'data='+encodeURIComponent(JSON.stringify(jsnhold)));
            },
            rebootErrorMsg:()=>{
                var allObj,jsnhold;
                allObj = CEP.Modules.Modulator.holdSucessPrint;
                jsnhold = {};
                jsnhold['TransID'] = allObj[0];
                jsnhold['amt'] = allObj[1];
                jsnhold['itemPaid'] = allObj[2];
                jsnhold['__Erorr'] = -1;
                __I.notifyLoader.notify('Analizing Payment...');
                ajaxPOST("ui/ajax/cep/onsuccesserrorpage.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            __I.notifyLoader.exitNoyify();
                            _('inerCntMot').classList.add('cor-go-out-slowly');
                            //Records.Engine.MainUser.closeWindowOpen.close();
                            setTimeout(()=>{
                                var responsses = __I.T_trim(this.responseText);
                                _('holdHeader__inner').innerText = "TRANSACTION FAILED";
                                _('inerCntMot').classList.remove('cor-go-out-slowly');
                                CEP.Modules.grandParent.insertAdjacentHTML("afterbegin",responsses);
                                CEP.Engine.preNxtEngine.removeBackArrow();
                            },500);
                        }
                    }
                 },'data='+encodeURIComponent(JSON.stringify(jsnhold)));
            },
        },
        Course:{
            holdCourses:{},
            processCourseRegistrattion:(moduelID,title,URL,descriFixCol,param)=>{
                CEP.Modules.Course.sum = 0;
                CEP.Modules.Course.holdCourses = {};
                CEP.Modules.Payment.colorManipulation(moduelID,title,URL,descriFixCol,param);
                __I.notifyLoader.notify('Loading...');
                var API = 'api/courses/load_courses/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                var responsses = __I.T_trim(this.responseText);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Engine.controlPaymentAjax("ui/ajax/cep/course/course.php",responsses.SUCCESS.Message,"removeLoginPage");
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__jmbno__":Telemedicine.Login.holdRegno})));
            }, 
            loadCourseHistory:(moduelID,title,URL,descriFixCol,param)=>{
                CEP.Modules.Course.holdCourses = {};
                CEP.Modules.Payment.colorManipulation(moduelID,title,URL,descriFixCol,param);
                __I.notifyLoader.notify('Loading...');
                var API = 'api/courses/coursereg_history/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                var responsses = __I.T_trim(this.responseText);
                                console.log(responsses);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Engine.controlPaymentAjax("ui/ajax/cep/course/coursehistory.php",responsses.SUCCESS.Message,"removeLoginPage");
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__jmbno__":Telemedicine.Login.holdRegno})));
            },
            sum:0,
            computeCourseReg:(cID,cCH,cTitl,cChode)=>{
                sum = 0;
                if(sum > 24)return __I.FormAlart.mainInit("Maximum limit exceeded");
                if(CEP.Modules.Course.holdCourses['courseCID_'+cID]){
                    delete CEP.Modules.Course.holdCourses['courseCID_'+cID];
                    _('courseCID_'+cID).classList.remove('cep-course-bg');
                }else{
                    CEP.Modules.Course.holdCourses['courseCID_'+cID] = [cID,cChode,cTitl,cCH];
                    _('courseCID_'+cID).classList.add('cep-course-bg');
                }
                _('spnSel').innerText = __I.objCount(CEP.Modules.Course.holdCourses)
                var i,sum,sunVal;
                sunVal = Object.values(CEP.Modules.Course.holdCourses);
                for(i = 0; i < sunVal.length; i++){
                    sum+=sunVal[i][3];
                }
                _('spnTch').innerText =  sum;
                CEP.Modules.Course.sum = sum;
            },
            sendSelectedCourses:()=>{
                if(!__I.objCount(CEP.Modules.Course.holdCourses) > 0){
                    return __I.FormAlart.mainInit("Select courses");
                     
                }
                __I.notifyLoader.notify('Loading...');
                __I.H_ide("NextBtn__pages__acad1");
                __I.S_how("showProgress__pages__acad1");
                var API = 'api/courses/register_courses/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                __I.H_ide("showProgress__pages__acad1");
                                __I.S_how("NextBtn__pages__acad1");
                                var responsses = __I.T_trim(this.responseText);
                                // console.log(responsses);return;
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    __I.FormAlart.mainInit(jesm.SUCCESS.Message);
                                    Records.Printer.admitToday('idGet_ui','script/printers/slip.php?s_t='+jesm.SUCCESS.CID+'&separator=11');
                                    CEP.Engine.controlPaymentAjax("ui/ajax/cep/course/registeredcourses.php?rty="+jesm.SUCCESS.CID+"",CEP.Modules.Course.holdCourses,"removeLoginPage");
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__jmbno__":Telemedicine.Login.holdRegno,"holdCourses":CEP.Modules.Course.holdCourses,"totalCh":CEP.Modules.Course.sum})));
            },
        },
        Payment:{
            processPayment:(moduelID,title,URL,descriFixCol,param)=>{
                CEP.Modules.Payment.colorManipulation(moduelID,title,URL,descriFixCol,param);
                __I.notifyLoader.notify('Loading...');
                var API = 'api/payments/process_fee_payment/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                var responsses = __I.T_trim(this.responseText);
                                console.log(responsses);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    // console.log(responsses.SUCCESS.Message);return;
                                    CEP.Engine.controlPaymentAjax("ui/ajax/cep/payment/paymentui.php",responsses.SUCCESS.Message,"removeLoginPage");
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__jmbno__":Telemedicine.Login.holdRegno})));
            },
            payFlag:false,
            commitPay:(payAble,flag)=>{
                CEP.Modules.Payment.payFlag = false;
                __I.notifyLoader.notify('Loading...');
                var API = 'api/payments/generate_fee_payment/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                var responsses = __I.T_trim(this.responseText);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    CEP.Modules.Modulator.holdSucessPrint = responsses.SUCCESS.reportP;
                                    CEP.Modules.RegisterNow.__sendClearOut(responsses.SUCCESS.Message,responsses.SUCCESS.reportP[1]);
                                    __I.S_how('sideNav_idcep');
                                    CEP.Modules.Payment.payFlag = true;
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__jmbno__":Telemedicine.Login.holdRegno,"payable":payAble,"flag":flag})));
            },
            processPaymentHistory:(moduelID,title,URL,descriFixCol,param)=>{
                CEP.Modules.Payment.colorManipulation(moduelID,title,URL,descriFixCol,param);
                __I.notifyLoader.notify('Loading...');
                var API = 'api/payments/payment_history/';
                    ajaxPOST(API,function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                __I.notifyLoader.exitNoyify();
                                var responsses = __I.T_trim(this.responseText);
                                console.log(responsses);
                                if(__I.isJson(responsses) == true){
                                    jesm = JSON.parse(responsses);
                                    if(jesm.ERROR){
                                        __I.FormAlart.mainInit(jesm.ERROR.Message);
                                        return;
                                    }else{
                                    var responsses = JSON.parse(responsses);
                                    // console.log(responsses.SUCCESS.Message);return;
                                    CEP.Engine.controlPaymentAjax("ui/ajax/cep/payment/paymenthistoryui.php",responsses.SUCCESS.Message,"removeLoginPage");
                                    }
                                }
                            }
                        }
                    },"data="+encodeURIComponent(JSON.stringify({"cep__jmbno__":Telemedicine.Login.holdRegno})));
            },
            colorManipulation:(moduelID,title,URL,descriFixCol,param)=>{
                let cl = document.getElementsByClassName('adm__');
                let cl2 = document.getElementsByClassName('xxyy');
                for(let i = 0; i < cl.length; i++){
                    cl[i].classList.remove('aks-records-module-bg');
                    cl2[i].classList.remove('aks-txt-app-inner-discor');
                }
                cl[moduelID].classList.add('aks-records-module-bg');
                cl2[descriFixCol].classList.add('aks-txt-app-inner-discor');
            },
        },
    },
};
window.onstorage = function(e){
    // console.log('The ' + e.key +
    //   ' key has been changed from ' + e.oldValue +
    //   ' to ' + e.newValue + '.');
    if(e.key == "SUCCESS" && e.newValue == "0"){
        // call login
        if(CEP.Modules.RegisterNow.ragPayee == 3 || CEP.Modules.RegisterNow.ragPayee == 4){
            CEP.Modules.Stabilizer.nextPages("BIODATA REGISTRATION",'',"ui/ajax/cep/pages/biodataform.php");
        }
        // xxsch p
        if(CEP.Modules.Payment.payFlag == true){
            CEP.Modules.Modulator.rebootSuccessMsg();
        }
        return;
    }
    if(e.key == "UNSUCCESSFULL" && e.newValue == "-1"){
        // call logout
        __I.notifyLoader.notify('Payment Failled...');
        CEP.Modules.Modulator.rebootErrorMsg();
        return;
    }
};
// CEP.Modules.RegisterNow.genBiodataRegSlip('08066550526')