var Records = {
    Printer:{
        clarTy:null,
        admitToday:function(id_main_win,ULR){
            clearTimeout(this.clarTy);
            _('getPDFFile').src = "";
            // window.location = ULR;return;;
            this.clarTy = setTimeout(()=>{
                _(id_main_win).classList.remove('come-slide-down');
            _(id_main_win).classList.add('w3-animate-zoom');
            _(id_main_win).style.display = 'block';
            __I.S_how('cogRoll');
            // window.location = URL;return;
            _('getPDFFile').src = ULR;
            _('getPDFFile').onload = ()=>{__I.H_ide('cogRoll');};
            },100);
        },
        closeWindow:function(id_main_win){
            _(id_main_win).classList.remove('w3-animate-zoom');
            _(id_main_win).classList.add('come-slide-down');
            setTimeout(()=>{_(id_main_win).style.display = 'none';},500);
        },
        printConfrimSlip:()=>{
            __I.notifyLoader.notify('Preparing Slip...');
           setTimeout(()=>{
            __I.notifyLoader.exitNoyify();
            // window.open('script/printers/slip.php?s_t='+__I.T_trim(_('transacID__paym__tID').innerText)+'&sSaptor='+2);return;
            Records.Printer.admitToday('idGet_ui','script/printers/slip.php?s_t='+__I.T_trim(_('transacID__paym__tID').innerText)+'&separator='+2);
           },500)
        },
    },
    APP:{
        TopBar2:{//Records.APP
            disableRecords:()=>{
                if(Records.APP.MainBody.mID == null || Records.APP.MainBody.keepregn == '')return __I.FormAlart.mainInit("Operation Failed");
                const jsonOj = {};
                jsonOj['xx__reg'] = Records.APP.MainBody.keepregn;
                jsonOj['xx__mid'] = Records.APP.MainBody.mID;
                __I.notifyLoader.notify('Preparing Delete...');
                ajaxPOST('../script/deletetRecord.php',function(){//readAdmisionList.php
                    if (this.readyState == 4) {
                        if(this.status == 200){
                        __I.notifyLoader.exitNoyify();
                        var responsses = __I.T_trim(this.responseText);
                        if(__I.isJson(responsses) == true){
                            jesm = JSON.parse(responsses);
                            if(jesm.ERROR){
                                __I.FormAlart.mainInit(jesm.ERROR.Message);
                                return;
                           }else{
                            __I.FormAlart.mainInit(jesm.SUCCESS.Message);
                           }
                        }else{return __I.FormAlart.mainInit("INVALID PARAMETER SUPPLIED");}  
                        }
                    }
                },'data='+encodeURIComponent(JSON.stringify(jsonOj)));

            },
            refreshPage:()=>{
                Records.Engine.trackNavSide = [];
            },
            resetAll:()=>{
                let cl = document.getElementsByClassName('aks-cl-comp');
                let cl2 = document.getElementsByClassName('xxyy');
                for(let i = 0; i < cl.length; i++){
                    cl[i].classList.remove('aks-Records-module-bg');
                    cl2[i].classList.remove('aks-txt-app-inner-discor');
                }
                document.getElementsByClassName('aks-cl-comp')[0].classList.add('aks-Records-module-bg');
                document.getElementsByClassName('xxyy')[0].classList.add('aks-txt-app-inner-discor');
            },
            enter:false,
            enterSmr:false,
            minimize:()=>{
                Records.APP.TopBar2.enterSmr = true;
                if(Records.APP.TopBar2.enter == false){
                    // Records.APP.TopBar2.animateBtns();
                    _('appSideNav').classList.remove('cor-go-out-slowly');
                    _('appSideNav').classList.add('w3-animate-left');
                    _('appSideNav').classList.remove('w3-hide-small');
                    _('appSideNav').classList.remove('w3-hide-medium');
                    _('appSideNav').classList.add('aks-Records-left-sidenav-smr');
                    Records.APP.TopBar2.enter = true;
                }else{
                    _('appSideNav').classList.remove('w3-animate-left');
                    _('appSideNav').classList.add('cor-go-out-slowly');
                    _('appSideNav').classList.add('w3-hide-small');
                    _('appSideNav').classList.add('w3-hide-medium');
                    _('appSideNav').classList.remove('aks-Records-left-sidenav-smr');
                    Records.APP.TopBar2.enter = false;
                }
            },
            removeAnimation:null,
            removeAnimation1:null,
            animateBtns:()=>{
                let cl,i,cnt,cl2,x;
                cl = document.getElementsByClassName('aks-app-topnv2');
                cl2 = document.getElementsByClassName('aks-app-ordering-cnt');
                for(i = 0; i < cl.length; i++){
                    cnt = i + 1;
                    let cnt2 = (cnt/10);
                    cl[i].style.animation = "projectUp 0.9s forwards ease-in-out "+cnt2+"s";
                }
                Records.APP.TopBar2.removeAnimation = setTimeout(()=>{
                    for(i = 0; i < cl.length; i++){
                        cnt = i + 1;
                        cl[i].style.animation = "";
                        clearTimeout(Records.APP.TopBar2.removeAnimation);
                    }
                },3000);
                for(x = 0; x < cl2.length; x++){
                    let cnt = x + 1;
                    let cnt2 = (cnt/10);
                    cl2[x].style.animation = "projectUp 0.9s forwards ease-in-out "+cnt2+"s";
                }
                Records.APP.TopBar2.removeAnimation1 = setTimeout(()=>{
                    for(x = 0; x < cl2.length; x++){
                        cl2[x].style.animation = "";
                        clearTimeout(Records.APP.TopBar2.removeAnimation1);
                    }
                },3000);

            },
            removeAni:null,
            animateBtnNormal:()=>{
                let cl,i,cnt;
                cl = document.getElementsByClassName('aks-app-proce-appl');
                for(i = 0; i < cl.length; i++){
                    cnt = i + 1;
                    cl[i].style.animation = "projectUp 0.9s forwards ease-in-out 0."+cnt+"s";
                }
                Records.APP.TopBar2.removeAni = setTimeout(()=>{
                    for(i = 0; i < cl.length; i++){
                        cnt = i + 1;
                        cl[i].style.animation = "";
                        cl[i].classList.add("aks-Records-heart-beat");
                        clearTimeout(Records.APP.TopBar2.removeAni);
                    }
                },1500);
            },
        },
        RightBar:{//Records.APP.RightBar
            controlCanvas:()=>{
                ajaxPOST('../script/controlconvas.php',function(){//readAdmisionList.php
                    if (this.readyState == 4) {
                        if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                            if(__I.isJson(responsses) == true){
                                jesm = JSON.parse(responsses);
                                if(jesm.ERROR){
                                    __I.FormAlart.mainInit(jesm.ERROR.Message);
                                    return;
                            }else{
                                _('__pendorde').innerText = jesm.SUCCESS.Message[0];
                                _('__allappl').innerText = jesm.SUCCESS.AllApplications[0];
                                _('__trackOrder').innerText = jesm.SUCCESS.trackOrder[0];
                                _('__dispatch').innerText = jesm.SUCCESS.dispatchOrder[0];
                                _('__result__upload').innerText = jesm.SUCCESS.result[0];
                                _('__result__trsnacript').innerText = jesm.SUCCESS.TretedTranscript[0];
                                _('__reslut__perc__trsnacript').innerText = jesm.SUCCESS.TretedTranscript[1]+'%';
                                _('__reslut__perc').innerText = jesm.SUCCESS.result[1]+'%';
                                _('__gtwidth').style.width = ""+jesm.SUCCESS.result[1]+"%";
                                _('__gtwidth_trsnacript').style.width = ""+jesm.SUCCESS.TretedTranscript[1]+"%";
                                __I.CanvasObj.canvas(Math.floor(jesm.SUCCESS.Message[1]),'shwReGPrinting12','counter123','#e91e63');
                                __I.CanvasObj.canvas(Math.floor(jesm.SUCCESS.AllApplications[1]),'shwReGPrinting124','counter1234','#009688');
                                __I.CanvasObj.canvas(Math.floor(jesm.SUCCESS.trackOrder[1]),'shwReGPrinting13','counter12345','brown');
                                __I.CanvasObj.canvas(Math.floor(jesm.SUCCESS.dispatchOrder[1]),'shwReGPrinting1','counter1','pink');
                            }
                            }else{return __I.FormAlart.mainInit("INVALID PARAMETER SUPPLIED");}  
                        }
                    }
                },'');
            },
            remoteController:(rcll,bodyCntrll)=>{
                let i,rt,cl;
                cl = document.getElementsByClassName('panels__');
                rt = ["30px","102px","172px","242px"];
                _('rtg_pr').style.setProperty("margin-left",""+rt[rcll]+"","important");
                for(i = 0; i < cl.length; i++){
                    cl[i].style.display = "none";
                }
                _(bodyCntrll).style.display = "block";
            },
        },
        MainBody:{
            disEnableToolBars:()=>{return;
                let cl,i;
                cl = document.getElementsByClassName('x__x__x');
                for(i = 0; i < cl.length; i++){
                    cl[i].classList.add('w3-hide');
                }
            },
        },
    },
    LeftController:{
        loadAjax:(moduelID,title,URL,descriFixCol,param)=>{
            let cl = document.getElementsByClassName('adm__');
            let cl2 = document.getElementsByClassName('xxyy');
            for(let i = 0; i < cl.length; i++){
                cl[i].classList.remove('aks-records-module-bg');
                cl2[i].classList.remove('aks-txt-app-inner-discor');
            }
            cl[moduelID].classList.add('aks-records-module-bg');
            cl2[descriFixCol].classList.add('aks-txt-app-inner-discor');
            Records.APP.MainBody.disEnableToolBars();
            Records.Engine.injectController(moduelID,URL,'removeLoginPage',title,param);
            
        },
    },
    Engine:{//Records.Engine
        loadComputedLegger:(url)=>{
        __I.notifyLoader.notify('Loading...');
        ajaxPOST(url,function(){//readAdmisionList.php
            if (this.readyState == 4) {
                if(this.status == 200){
                    var responsses = __I.T_trim(this.responseText);
                    _('removeLoginPage').classList.add('cor-go-out-slowly');
                    setTimeout(function(){
                        __I.notifyLoader.exitNoyify();
                        _('removeLoginPage').classList.remove('cor-go-out-slowly');
                        _('removeLoginPage').innerHTML = responsses;
                    },500);
                }
            }
        },'param='+encodeURIComponent(Telemedicine.Login.holdRegno));
    },
        pointer:0,
        holdArr:'',
        processRequest:(mID,mRegno,title)=>{
            __I.notifyLoader.notify('Preparing '+title+'...');
            if(Records.APP.MainBody.keepReadyStatus == 5){//5 is ready
                __I.notifyLoader.exitNoyify();
                // window.open('../script/printers/slip.php?s_t='+mRegno+'&sSaptor='+mID+'');return;
                Records.Printer.admitToday('idGet_ui','../script/printers/slip.php?s_t='+mRegno+'&sSaptor='+mID+'');
            }else{
                __I.notifyLoader.exitNoyify();
                return __I.FormAlart.mainInit(""+title+" Not Ready");
            }
        },
        increamPointer:1,
        receiveToLength:0,
        receiveToUper:0,
        holdTem:0,
        holdArr:[],
        enter:false,
        incrementMode:(increaOrder)=>{
            Records.APP.TopBar2.resetAll();
            var incrementa;
            if(Records.Engine.enter == true){
                if(increaOrder < 0){
                    _('next___').classList.remove('w3-hide');
                    Records.Engine.increamPointer = Records.Engine.increamPointer - 1;
                    Records.Engine.createAjax('../ui/ajax/allinbox.php','removeLoginPage',Records.Engine.increamPointer);
                    Records.Engine.enter = false;
                }
                return;
            }
           incrementa = Records.Engine.increamPointer+=increaOrder;
           if(incrementa < 1){Records.Engine.increamPointer = 1;return;};
          if(increaOrder == 1){
            __I.notifyLoader.notify('Preparing Next...');
           }else{
            __I.notifyLoader.notify('Preparing Previous...');
           }
           Records.Engine.createAjax('../ui/ajax/allinbox.php','removeLoginPage',incrementa);
        },
        createAjax:(URL,URLID,pointer)=>{
            _('getVisibility').style.visibility = "visible";
            Records.APP.MainBody.disEnableToolBars();
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        __I.notifyLoader.exitNoyify();
                        var responsses = __I.T_trim(this.responseText);
                        let yt = responsses.split('||');
                        if(yt[3] == '~'){Records.Engine.enter = true;_('next___').classList.add('w3-hide');}
                        if(yt[1] == undefined){
                            Records.Engine.enter = true;
                            Records.Engine.increamPointer = Records.Engine.increamPointer - 1;//this can be remove if there is error
                            return;
                        };
                        _('getFrntEn').innerText = yt[1];
                        _(URLID).innerHTML = yt[0];
                    }
                }
             },'pointer='+encodeURIComponent(pointer));
        },
        remoteControl:(URL,URLID,param)=>{
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        if(__I.isJson(responsses) == true){
                            jesm = JSON.parse(responsses);
                            if(jesm.ERROR){
                                __I.FormAlart.mainInit(jesm.ERROR.Message);
                                return;
                           }else{
                            _(URLID).innerHTML = jesm.SUCCESS.Message;
                           }
                        }else{return __I.FormAlart.mainInit("INVALID PARAMETER SUPPLIED");}
                    }
                }
             },'param='+encodeURIComponent(param));
        },
        trackNavSide:[],
        injectController:(SideNavID,URL,removBodyID,title,param)=>{
            var holdObj = {};
            holdObj["param"] = param;
            holdObj["moduleID"] = Telemedicine.Stabilizer.moduleID;
            holdObj["holdStafID"] = Telemedicine.Login.holdRegno;
            if(param == '0'){
                _('getVisibility').style.visibility = "visible";
            }else{
                _('getVisibility').style.visibility = "hidden";
            }
            if(Records.Engine.trackNavSide.includes(SideNavID))return;
            if(SideNavID=='tr_1' || SideNavID=='tr_5'){Records.Engine.prepareDashboard('','',URL,'removeLoginPage',JSON.stringify(holdObj));return;}
            clearTimeout(Telemedicine.ChatBox.updateChat);
            __I.notifyLoader.notify('Preparing '+title+'...');
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        _(removBodyID).classList.add('cor-go-out-slowly');
                        var responsses = __I.T_trim(this.responseText);
                        // console.log(responsses);
                        setTimeout(function(){
                            clearTimeout(Telemedicine.ChatBox.updateChat);
                            __I.notifyLoader.exitNoyify();
                            _(removBodyID).classList.remove('cor-go-out-slowly');
                            if(Records.Engine.enterSmr == true){Records.Engine.minimize();}
                            if(Records.APP.TopBar2.enterSmr == true){Records.APP.TopBar2.minimize();}
                            if(Records.Engine.trackNavSide.length > 0){
                                Records.Engine.trackNavSide = [];
                                Records.Engine.trackNavSide.push(SideNavID);
                            }else{
                                Records.Engine.trackNavSide.push(SideNavID);
                            }
                            let yt = responsses.split('||');
                            _(removBodyID).innerHTML = yt[0];
                            // Records.Engine.prepareDashboard('','',URL,'removeLoginPage',JSON.stringify(holdObj));
                            if(Records.APP.putOnApp == true){
                                // begin app
                                Records.APP.MainBody.animateApplicationModule();
                            }

                        },500);
                    }
                }
             },'data='+encodeURIComponent(JSON.stringify(holdObj)));
        },
        prepareDashboard:(moduelID,rtu,URL,htmlBody,param)=>{
            if(URL == "")return;
            _('removeLoginPage').innerHTML = "";
            Records.Engine.trackNavSide = [];
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                    var responsses = __I.T_trim(this.responseText);
                    try {
                    var spl = JSON.parse(responsses);
                    var arrR = spl[1];
                    var arrR2 = spl[2];
                    var arrR3 = spl[3];
                    var arrR4 = spl[4];
                    var arrR5 = spl[5];
                    var arrR6 = spl[6];
                    var arrR7 = spl[7];
                    var arrR8 = spl[8];
                    var arrR9 = spl[9];
                    var arrR10 = spl[10];
                    var arrR11 = spl[11];
                    var arrR12 = spl[12];
                    var arrR13 = spl[13];
                    var getElem = arrR[0];
                      _('removeLoginPage').innerHTML = spl[0];
                      _(getElem[0]).innerHTML = getElem[1];
                    //   Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting12','counter123','#e91e63',8);
                      Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting12F','counter123F','#e91e63',4);
                      Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting12prog','counter123prog','rgb(255,165,0)',4);
                      Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting12R','counter123R','rgb(0,128,0)',4);
                      Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting12pat','counter123pat','rgb(0,128,128)',15);
                      Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting12Min','counter123Min','rgb(255,255,0)',4);
                    //   Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting','counter','rgb(255,255,0)',12);
                    //   Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting1','counter1','rgb(255,165,0)',10);
                    //   Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(100),'shwReGPrinting13','counter12345','rgb(0,128,0)',13);
                      ///////////////////////////////
                      _(arrR2[0]).innerText = arrR2[1];
                      _(arrR3[0]).innerText = arrR3[1];
                      _(arrR4[0]).innerText = arrR4[1];
                      _(arrR5[0]).innerText = arrR5[1];
                      _(arrR7[0]).innerText = arrR7[1];
                    //   _(arrR8[0]).innerText = arrR8[1];
                    //   _(arrR8[2]).innerText = arrR8[3];
                    //   _(arrR8[4]).style.width = arrR8[3];
                      /////////////////////////////
                    //   _(arrR8[5]).innerText = arrR8[6];
                    //   report
                     ///////////////////
                    //  _(arrR9[0]).innerText = arrR9[1];
                    //  _(arrR9[6]).style.width = arrR9[3];
                    //  _(arrR9[2]).innerHTML = arrR9[3];
                     //////////
                    //   _(arrR9[4]).innerText = arrR9[5];
                    //   total fac
                    // _(arrR10[0]).innerText = arrR10[1];
                    // _(arrR10[2]).innerText = arrR10[3];//
                    //   total rograms
                    // _(arrR11[0]).innerText = arrR11[1];
                    // _(arrR11[2]).innerText = arrR11[3];//
                    //   total result
                    // _(arrR12[0]).innerText = arrR12[1];
                    // _(arrR12[2]).innerText = arrR12[3];//
                    //   total MIN
                    // _(arrR13[0]).innerText = arrR13[1];
                    // _(arrR13[2]).innerText = arrR13[3];//
                      google.charts.setOnLoadCallback(Records.Engine.drawChartCandidate(arrR6[0]));
                    } catch (error) {
                        _('removeLoginPage').innerHTML = '<h2 class="w3-center w3-margin">No Display Yet</h2>';
                    }
                    }
                }
            },'data='+encodeURIComponent(param));
        },
        drawChartCandidate:(arrInd)=>{
            // Create the data table for Sarah's pizza.
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Topping');
            data.addColumn('number', 'Slices');
            data.addRows(arrInd);
            var options = {
                'title':'STATISTICS',
                is3D: true,
                'width':"100%", 
                'height':"100%",
                hAxis : { 
                    textStyle : {
                        fontSize: 7 // or the number you want
                    }
            
                },
                hAxis: {
                    title: 'Request Status',
                    titleTextStyle: {
                        color: "#000",
                        fontName: "sans-serif",
                        fontSize: 11,
                        bold: true,
                        italic: false
                    }
                },
                vAxis: {
                    title: 'Amount requested ($)',
                    titleTextStyle: {
                        color: "#000",
                        fontName: "sans-serif",
                        fontSize: 11,
                        bold: true,
                        italic: false
                    }
                },
                annotations: {
                    alwaysOutside: true,
                    textStyle: {
                        fontSize: 14,
                        auraColor: 'none'
                    }
                },
                cssClassName:{
                    headerRow:'aks-vot-smr-chart-body',
                    hoverTableRow:'aks-vot-smr-chart-body',
                },
            };
            // Instantiate and draw the chart for Sarah's pizza.
            var chart = new google.visualization.PieChart(document.getElementById('facChart'));
            chart.draw(data, options);
        },
        rebootAction:(btnID,robootCntr)=>{
            let cl,i;
            if(robootCntr == 'btnr_1'){
                _('rootID').style.left = "25%";
            }else{
                _('rootID').style.left = "73%";
            }
            cl = document.getElementsByClassName('clxx');
            for(i = 0; i < cl.length; i++){
                cl[i].style.display = "none";
            }
            _(btnID).style.display = "block";
        },
        enter:false,
        enterSmr:false,
        minimize:()=>{
            Records.Engine.enterSmr = true;
            if(Records.Engine.enter == false){
                _('errwer').classList.add('w3-animate-left');
                _('errwer').classList.remove('w3-hide-small');
                _('errwer').classList.remove('w3-hide-medium');
                _('errwer').classList.add('aks-records-left-sidenav-smr');
                Records.Engine.enter = true;
            }else{
                _('errwer').classList.add('w3-hide-small');
                _('errwer').classList.add('w3-hide-medium');
                _('errwer').classList.remove('aks-records-left-sidenav-smr');
                Records.Engine.enter = false;
            }
        },
        closeWindow:function(id_main_win){
            _(id_main_win).classList.remove('w3-animate-opacity');
            _(id_main_win).classList.add('av2-anim-right');
            setTimeout(()=>{_(id_main_win).style.display = 'none';_(id_main_win).classList.remove('av2-anim-right');},500);
        },
        exitWindow:function(id_main_win){
            _(id_main_win).classList.remove('w3-animate-opacity');
            _(id_main_win).classList.add('come-slide-down');
            setTimeout(()=>{_(id_main_win).style.display = 'none';_(id_main_win).classList.remove('come-slide-down');},500);
        },
    },
};
var Telemedicine = {
    AudioMain:{
        play:function(showPause,hidePlay){
             __I.H_ide(hidePlay);
            __I.S_how(showPause);
            Telemedicine.Modules.AddCandidate.audio = true;
            Telemedicine.Modules.AddCandidate.clAjF(Telemedicine.Modules.AddCandidate.audioPointer);
        },
        pause:function(hidePlay,showPause){
            __I.S_how(hidePlay);
            __I.H_ide(showPause);
            Telemedicine.Modules.AddCandidate.audio = false;
        },
        stop:function(msgBxProInvADMITTED){
            Telemedicine.Modules.AddCandidate.audio = false; 
            Telemedicine.Modules.AddCandidate.tempinvPH = 0;
            Telemedicine.Modules.AddCandidate.temp = 0;
            __I.H_ide(msgBxProInvADMITTED);
            window.location = "index.php";
        },
    },
    ChatBox:{
        docID:'',
        patientID:'',
        doctPatientPrivilege:'',
        beginChat:(docID,patientID,doctPatientPrivilege__,clr)=>{
            Telemedicine.ChatBox.docID = docID;//store docar ID
            Telemedicine.ChatBox.patientID = patientID;//store docar ID
            Telemedicine.ChatBox.doctPatientPrivilege = doctPatientPrivilege__;//store docar or patient privilege
            var holdJsonArr = {};
            holdJsonArr['docID'] = Telemedicine.ChatBox.docID;
            holdJsonArr['patientID'] = Telemedicine.ChatBox.patientID;
            holdJsonArr['doctPatientPrivilege'] = Telemedicine.ChatBox.doctPatientPrivilege;
            // get all the cl
            var cl = document.getElementsByClassName('tel-chat-rows-hover');
            for(let i = 0; i < cl.length; i++){
                cl[i].classList.remove('tel-chat-rows-fix-col');
            }
            cl[clr].classList.add('tel-chat-rows-fix-col');
            ajaxPOST("ui/ajax/beginchatting.php",function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        Telemedicine.ChatBox.startLiveChat();
                        var responsses = __I.T_trim(this.responseText);
                        _('getbeginchatingbody').innerHTML = responsses;
                        __I.S_how('getbeginchatingbody');
                        // call the live function here to update live messages 
                        
                    }
                }
             },'data='+encodeURIComponent(JSON.stringify(holdJsonArr)));

        },
        docIDLive:'',
        patientIDLive:'',
        doctPatientPrivilegeLive:'',
        liveChat:(opponent,home,privilege)=>{
            Telemedicine.ChatBox.docIDLive = opponent;
            Telemedicine.ChatBox.patientIDLive = home;
            Telemedicine.ChatBox.doctPatientPrivilegeLive = privilege;
            var holdJsonArr = {};
            if(_('tel_chat_id').value == "")return;
            holdJsonArr["opponent"] = Telemedicine.ChatBox.docIDLive;
            holdJsonArr["home"] = Telemedicine.ChatBox.patientIDLive;
            holdJsonArr["privilege"] = Telemedicine.ChatBox.doctPatientPrivilegeLive;
            holdJsonArr["tel_chat_id"] = __I.T_trim(_('tel_chat_id').value);
            ajaxPOST("script/livechat.php",function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        _('tel_chat_id').value = '';
                        var responsses = __I.T_trim(this.responseText);
                        if( _('getlivechatinfo') == null)return;
                        _('getlivechatinfo').innerHTML = responsses;
                        // call the live function here to update live messages 
                        
                    }
                }
             },'data='+encodeURIComponent(JSON.stringify(holdJsonArr)));
        },
        updateChat:null,
        startLiveChat:()=>{
            var holdJsonArr = {};
            holdJsonArr['docID'] = Telemedicine.ChatBox.docID;
            holdJsonArr['patientID'] = Telemedicine.ChatBox.patientID;
            holdJsonArr['doctPatientPrivilege'] = Telemedicine.ChatBox.doctPatientPrivilege;
            ajaxPOST("script/startlivechat.php",function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        if( _('getlivechatinfo') == null)return;
                        _('getlivechatinfo').innerHTML = responsses;
                        // update chat after 2 min
                        Telemedicine.ChatBox.updateChat = setTimeout(Telemedicine.ChatBox.startLiveChat(),5000);
                        // call the live function here to update live messages     
                    }
                }
             },'data='+encodeURIComponent(JSON.stringify(holdJsonArr)));
        },
    },
    // controls all the outer activities
    Stabilizer:{
        backToHomePage:(id_main_win)=>{
            _(id_main_win).classList.add('come-slide-down');
            setTimeout(()=>{_(id_main_win).style.display = 'none';_(id_main_win).classList.remove('come-slide-down');},500);
        },
        CanvasObj:{
            canvas:function(RoTno,ID,ID1){
                __I.S_how(ID);
                var canvas = _(ID1);
                var canvasbg = _(ID1+"_bg");
                var diff;
                if(canvas.getContext){
                    var counter = canvas.getContext('2d');
                    //var no = 0;
                    // var ratio = Math.floor((e.loaded / e.total) * 100) + '%';
                    var no = RoTno;
                    var pointToFill = 4.72;//point from wher you want to fill the circle
                    var cw = counter.canvas.width;//return height
                    var ch = counter.canvas.height;//return height
                    // diff = Math.floor((e.loaded / e.total) * 100);//previously used
                    diff = RoTno;
                    counter.clearRect(0,0,cw,ch);
                    counter.lineWidth = 4;//width counter
                    counter.fillStyle = '#fff';//stroke color %
                    counter.strokeStyle = "rgba(210, 20, 172, 1)";//stroke color #FF6600
                    counter.textAlign = 'center';
                    counter.font = "15px monospace";
                    counter.fillText(no+'%',50,55);
                    //counter.fillText('3456',60,65);
                    counter.beginPath();
                    //counter.arc(100,100,90,pointToFill,diff/10+pointToFill);//context.arc(x,y,r,sAngle,eAngle,counterclockwise);
                    counter.arc(50,50,30,pointToFill,diff/15.91+pointToFill);//context.arc(x,y,r,sAngle,eAngle,counterclockwise);
                    counter.stroke();
                }
                if(canvasbg != null && canvasbg.getContext){
                    var counter = canvasbg.getContext('2d');
                    RoTno = 100;
                    //var no = 0;
                    // var ratio = Math.floor((e.loaded / e.total) * 100) + '%';
                    var no = RoTno;
                    var pointToFill = 4.72;//point from wher you want to fill the circle
                    var cw = counter.canvas.width;//return height
                    var ch = counter.canvas.height;//return height
                    // diff = Math.floor((e.loaded / e.total) * 100);//previously used
                    diff = RoTno;
                    counter.clearRect(0,0,cw,ch);
                    counter.lineWidth = 4;//width counter
                    counter.fillStyle = '#fff';//stroke color %
                    counter.strokeStyle = "rgba(255, 255, 255, 0.1)";//stroke color #FF6600
                    //counter.textAlign = 'center';
                    //counter.font = "15px monospace";
                    //counter.fillText(no+'%',50,55);
                    //counter.fillText('3456',60,65);
                    counter.beginPath();
                    //counter.arc(100,100,90,pointToFill,diff/10+pointToFill);//context.arc(x,y,r,sAngle,eAngle,counterclockwise);
                    counter.arc(50,50,30,pointToFill,diff/15.91+pointToFill);//context.arc(x,y,r,sAngle,eAngle,counterclockwise);
                    counter.stroke();
                }
            },
        },
        holdVistedPages:[],
        callPages:()=>{
            var arrLeg = Telemedicine.Stabilizer.holdVistedPages.length;
            arrLeg = arrLeg - 1;
            if(arrLeg < 0)return;
            var getDetails = Telemedicine.Stabilizer.holdVistedPages[arrLeg];
            Telemedicine.Stabilizer.motorController(getDetails[0],getDetails[1],'');
            __I.S_how('getRR');
            alert(arrLeg);
            if(arrLeg == 0){  
                __I.H_ide('getRR');
            }
        },
        backRowHTML:()=>{
            return '<div id="getRR" title="Previous" class="w3-text-white w3-xlarge cor-pointer" style="padding:6px;display:none;"><i onclick="Telemedicine.Stabilizer.callPages()" class="fas fa-long-arrow-alt-left"></i></div>';
        },
        uiSimulator:(moduleName,moduleXID,ModuleCog,URL,param)=>{
            __I.notifyLoader.notify(moduleName+'...');
            param = param.split('~');
            _(param[1]).innerHTML = moduleName;
            _(param[0]).classList.add('w3-animate-opacity');
            _(param[0]).classList.remove('come-slide-down');
            __I.S_how(param[0]);
            Telemedicine.Stabilizer.motorController(URL,param[2],'');
        },
        motorController:(URL,responseBody,param)=>{
            var inArr = [URL,responseBody,param];
            Telemedicine.Stabilizer.holdVistedPages.push(inArr);
            ajaxPOST(URL,function(){//readAdmisionList.php
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        __I.notifyLoader.exitNoyify();
                       _(responseBody).innerHTML = responsses;
                    }
                }
            },'');
        },
        dashboardController:(URL,responseBody,param)=>{
            ajaxPOST(URL,function(){//readAdmisionList.php
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        __I.notifyLoader.exitNoyify();
                       _(responseBody).innerHTML = responsses;
                    }
                }
            },'data='+encodeURIComponent(param));
        },
        holdUserPrivileges:'',
        moduleID:null,
        moduleController:(moduleName,paramID,cogID,URL,jsFuncParam,subURL,DashboardFuc)=>{
            // moduleName is the name of the module
            // paramID is module ID
            // cogID is cog ID
            // URL is the redirect URL 
            // jsFuncParam is parameter that is passed into the javascript function
            // subURL is a call back url on page upload
            // store all the varibles in json format 
            var privilaram,jsnhold;
            // privilaram = JSON.parse(Telemedicine.Stabilizer.holdUserPrivileges);
            // if(!privilaram.includes(paramID))return;
            jsnhold = {};
            __I.notifyLoader.notify(moduleName+'...');
            __I.S_how(cogID);
            Telemedicine.Stabilizer.moduleID = paramID;
            jsnhold['moduleID'] = paramID;
            jsnhold['holdStafID'] = Telemedicine.Login.holdRegno;
            // jsnhold['privilg'] = Telemedicine.Login.privilg;
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        __I.S_how('backToHomePage');//resolve and display thecontainer
                        __I.notifyLoader.exitNoyify();
                        __I.H_ide(cogID);
                        var responsses = __I.T_trim(this.responseText);
                        _('getModuleNam').innerText = moduleName;
                       // __I.runTime('runTyme');//will be used after login
                        _('appSideNav').innerHTML = responsses;
                        Records.APP.TopBar2.animateBtns();//call after login
                        __I.S_how('exitMenus');
                        // call back URL here 
                        // Telemedicine.Stabilizer.dashboardController(subURL,'removeLoginPage',JSON.stringify(jsnhold));
                        _('getTheuseracutn').style.backgroundRepeat = "no-repeat";
                        _('getTheuseracutn').style.backgroundSize = "cover";
                        _('getTheuseracutn').style.backgroundPosition = "center";
                        _('getTheuseracutn').style.backgroundAttachment = "fixed";
                        _('getTheuseracutn').style.backgroundImage = "url('"+Telemedicine.Login.passport+"')";
                        //Telemedicine.Stabilizer.prepareDashboard('','',subURL,'removeLoginPage',JSON.stringify(jsnhold));
                        console.log(subURL);return;
                        Records.Engine.prepareDashboard('','',subURL,'removeLoginPage',JSON.stringify(jsnhold));
                        Telemedicine.Modules.AdmissionList.progStat();
                    }
                }
             },'data='+encodeURIComponent(JSON.stringify(jsnhold)));
        },
        showPop:(URL,moduleName)=>{
            __I.S_how('sideNav_id');
            _('holdHeader').innerHTML = moduleName;
            ajaxPOST(URL,function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        try {
                            _('inerCntMot').innerHTML = responsses;
                        } catch (error) {
                            __I.FormAlart.mainInit("Error processing...");return;
                        }
                    }
                }
             },'');
        }, 
    },
    // control all the modules 
    Modules:{
        changeProgramme:{
            changeProg:()=>{
                const holdObj = {};
                holdObj['getJmNo'] = __I.T_trim(_('tel_jam_number_ch').value);
                __I.S_how('rtt');
                ajaxPOST('script/changeprogramme.php',function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            var responsses = __I.T_trim(this.responseText);
                            try {
                                if(responsses != '*3'){
                                    __I.H_ide('rtt');
                                    _('tel_jam_caName').value = JSON.parse(responsses).CanName;
                                    _('tel_jam_numberrr').value = JSON.parse(responsses).CandJamb;
                                    _('tel_jam_dept').value = JSON.parse(responsses).progNr;
                                }else{
                                    _('tel_jam_caName').value = "";
                                    _('tel_jam_numberrr').value = "";
                                    _('tel_jam_dept').value = "";
                                }
                            } catch (error) {
                                __I.FormAlart.mainInit("Error processing...");return;
                            }
                        }
                    }
                 },'data='+encodeURIComponent(JSON.stringify(holdObj)));
            },
            newProgramme:()=>{
                const holdObj = {};
                holdObj['getJmNo'] = __I.T_trim(_('tel_jam_number_ch').value);
                holdObj['getDpet_rr'] = __I.T_trim(_('getDpet_rr').value);
                __I.H_ide('NextBtn__');
                __I.S_how('showProgress__');
                ajaxPOST('script/addnewprogram.php',function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            __I.H_ide('showProgress__');
                            __I.S_how('NextBtn__');
                            var responsses = __I.T_trim(this.responseText);
                            try {
                                Records.Engine.exitWindow('sideNav_id');
                                __I.FormAlart.mainInit("Updated");return;
                            } catch (error) {
                                __I.FormAlart.mainInit("Error processing...");return;
                            }
                        }
                    }
                 },'data='+encodeURIComponent(JSON.stringify(holdObj)));
            },
        },
        // Doc Modules
        AddCandidate:{
            dashboardFuc:()=>{
                
            },
            arrEl:'',
            audio:true,
            pointer:0,
            audioPointer:null,
            temp:1,
            getPh:null,//REMOV IF ERROR EXPLODE
            tempinvPH:1,
            currntUpdatedValue:null,
            jamb:()=>{
                var data = new FormData();
                data.append("file1", document.querySelector("#file_123").files[0]);
                __I.H_ide('shoC_cog__');
                __I.S_how('shoC_cogjolps');
                ajaxPOSTFile('script/readjamblistcsv.php',function(){//readAdmisionList.php
                    if (this.readyState == 4) {
                        if(this.status == 200){
                        __I.H_ide('shoC_cogjolps');
                        __I.S_how('shoC_cog__');
                            try{
                                var responsses = __I.T_trim(this.responseText);
                                // if(responsses == "|~|"){__I.FormAlart.mainInit("Please upload candidate list");return;}
                                if(responsses != "@!*"){
                                    if(responsses != "*78"){
                                        Telemedicine.Modules.AddCandidate.arrEl = JSON.parse(responsses);
                                        Telemedicine.Modules.AddCandidate.clAjF(Telemedicine.Modules.AddCandidate.pointer);
                                        }else{__I.FormAlart.mainInit("Delete serial number column");return;}
                                }else{__I.FormAlart.mainInit("CHOOSE CSV FILE");__I.loadAjx('csvs.php','fixedcocsv');return;}
                            } catch (error) {
                                __I.FormAlart.mainInit("Refresh and upload candidate list");return;
                            }
                        }
                    }
                },data);
            },
        clAjF:(pointer)=>{
        if(Telemedicine.Modules.AddCandidate.audio == false)return;
        Telemedicine.Modules.AddCandidate.audioPointer = pointer;//this will hold the current pointer on paus
        var getRows = Telemedicine.Modules.AddCandidate.arrEl[pointer];
        var holdObj = {};
        holdObj["JAMBNO"] =  getRows.JAMBNO;
        holdObj["CNAME"] =  getRows.CNAME;
        holdObj["GENDER"] =  getRows.GENDER;
        holdObj["STATE"] =  getRows.STATE;
        holdObj["LGA"] =  getRows.LGA;
        holdObj["JAMBSCOR"] =  getRows.JAMBSCOR;
        holdObj["COURSE"] =  getRows.COURSE;
        holdObj["SUBJ1"] =  getRows.SUBJ1;
        holdObj["SCORE1"] =  getRows.SCORE1;
        holdObj["SUBJ2"] =  getRows.SUBJ2;
        holdObj["SCOR2"] =  getRows.SCOR2;
        holdObj["SUBJ3"] =  getRows.SUBJ3;
        holdObj["SCOR3"] =  getRows.SCOR3;
        holdObj["SCOR4"] =  getRows.SCOR4;
            ajaxPOST("script/updateutme.php",function(){//08022269656
                if (this.readyState == 4) {
                    if(this.status == 200){
                    var responsses = __I.T_trim(this.responseText);
                    switch(responsses){

                        case "*|3":
                            __I.H_ide('msgBoxUpdted');
                            pointer =  pointer + 1;
                            _('totalNumberOfCiN').innerText = Telemedicine.Modules.AddCandidate.temp;
                             _('getProgresCADMITTED').innerHTML = (Telemedicine.Modules.AddCandidate.temp) +'/'+ Telemedicine.Modules.AddCandidate.arrEl.length;
                            __I.S_how('msgBoxCandidte');
                            if(pointer < Telemedicine.Modules.AddCandidate.arrEl.length){
                                Telemedicine.Modules.AddCandidate.temp++;
                                Telemedicine.Modules.AddCandidate.clAjF(pointer);
                            } 
                            _('dededeinsrted').innerText = Telemedicine.Modules.AddCandidate.temp;
                            _('dededeupftd').innerText = Telemedicine.Modules.AddCandidate.tempinvPH - 1;
                            _('dedededetransactC').innerText = parseInt(Telemedicine.Modules.AddCandidate.temp) + parseInt((Telemedicine.Modules.AddCandidate.tempinvPH - 1));
                            _('rtyrin').innerText = ((Telemedicine.Modules.AddCandidate.temp+Telemedicine.Modules.AddCandidate.tempinvPH - 1)/Telemedicine.Modules.AddCandidate.arrEl.length)*100+'%';
                            if(pointer == Telemedicine.Modules.AddCandidate.arrEl.length){
                                _('etyn').classList.add('mva-blink');
                            }
                        break;
                        
                        default:
                            __I.H_ide('msgBoxCandidte');//hide main prog upd REMOV IF ERROR EXPLODE
                            _('uptoNumberOfCAd').innerText =  Telemedicine.Modules.AddCandidate.tempinvPH;
                            _('upgetInvADMITTED').innerHTML = (Telemedicine.Modules.AddCandidate.tempinvPH) +'/'+ Telemedicine.Modules.AddCandidate.arrEl.length;
                            __I.S_how('msgBoxUpdted');//REMOV IF ERROR EXPLODE
                            pointer =  pointer + 1;//2

                            if(pointer < Telemedicine.Modules.AddCandidate.arrEl.length){
                                Telemedicine.Modules.AddCandidate.tempinvPH++;
                                Telemedicine.Modules.AddCandidate.clAjF(pointer);
                            }
                            _('dedeinsrted').innerText = Telemedicine.Modules.AddCandidate.temp - 1;
                            _('dedeupftd').innerText = Telemedicine.Modules.AddCandidate.tempinvPH;
                            _('dededetransactC').innerText = parseInt((Telemedicine.Modules.AddCandidate.temp - 1)) + parseInt(Telemedicine.Modules.AddCandidate.tempinvPH);
                            _('rtyr').innerText = ((Telemedicine.Modules.AddCandidate.temp+Telemedicine.Modules.AddCandidate.tempinvPH - 1)/Telemedicine.Modules.AddCandidate.arrEl.length)*100+'%';
                            if(pointer == Telemedicine.Modules.AddCandidate.arrEl.length){
                                _('bgtry').classList.add('mva-blink');
                            }
                        break;
                    }
                }
                }
            },'data='+encodeURIComponent(JSON.stringify(holdObj)));
            },
        //de jam screening list
        DeJambList:{
            jambDe:()=>{
                var data = new FormData();
                data.append("file1", document.querySelector("#file_1237").files[0]);
                __I.H_ide('shuplod1');
                __I.S_how('shoC_cog1');
                ajaxPOSTFile('script/readjamblistdecsv.php',function(){//readAdmisionList.php
                    if (this.readyState == 4) {
                        if(this.status == 200){
                        __I.H_ide('shoC_cog1');
                        __I.S_how('shuplod1');
                        var responsses = __I.T_trim(this.responseText);
                        // console.log(responsses);
                        if(responsses != "@!*"){
                            if(responsses != "*78"){
                                try {
                                    Telemedicine.Modules.AddCandidate.DeJambList.arrEl = JSON.parse(responsses);
                                    Telemedicine.Modules.AddCandidate.DeJambList.clAjF(Telemedicine.Modules.AddCandidate.DeJambList.pointer);
                                } catch (error) {
                                    __I.FormAlart.mainInit("Refresh and upload DE candidate list");return;
                                }
                            }else{__I.FormAlart.mainInit("Delete serial number column");return;}
                            
                        }else{__I.FormAlart.mainInit("CHOOSE CSV FILE");return;}
                        }
                    }
                },data);
            },
            //update etransact fees
            arrEl:"",
            pointer:0,
            //update manager
            temp:1,
            getPh:null,//REMOV IF ERROR EXPLODE
            tempinvPH:1,
            audio:true,
            audioPointer:null,
            currntUpdatedValue:0,
            clAjF:(pointer)=>{
            if(Telemedicine.Modules.AddCandidate.DeJambList.audio == false)return;
            Telemedicine.Modules.AddCandidate.DeJambList.audioPointer = pointer;//this will hold the current pointer on paus
            var getRows = Telemedicine.Modules.AddCandidate.DeJambList.arrEl[pointer];
            var holdObj = {};
            holdObj["JAMBNO"] =  getRows.JAMBNO;
            holdObj["CNAME"] =  getRows.CNAME;
            holdObj["GENDER"] =  getRows.GENDER;
            holdObj["STATE"] =  getRows.STATE;
            holdObj["LGA"] =  getRows.LGA;
            holdObj["COURSE"] =  getRows.COURSE;
                ajaxPOST("script/updatedeutme.php",function(){//08022269656
                    if (this.readyState == 4) {
                        if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        switch(responsses){
                            case "*|3":
                                __I.H_ide('demsgBoxUpdted');
                                pointer =  pointer + 1;
                                _('detotalNumberOfCiN').innerText = Telemedicine.Modules.AddCandidate.DeJambList.temp;
                                 _('degetProgresCADMITTED').innerHTML = (Telemedicine.Modules.AddCandidate.DeJambList.temp) +' / '+ Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length;
                                __I.S_how('demsgBoxCandidte');
                                if(pointer < Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length){
                                    Telemedicine.Modules.AddCandidate.DeJambList.temp++;
                                    Telemedicine.Modules.AddCandidate.DeJambList.clAjF(pointer);
                                } 
                                _('deinsrted').innerText = Telemedicine.Modules.AddCandidate.DeJambList.temp;
                                _('deupftd').innerText = Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH - 1;
                                _('dedetransactC').innerText = parseInt(Telemedicine.Modules.AddCandidate.DeJambList.temp) + parseInt((Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH - 1));
                                _('dertyrin').innerText = ((Telemedicine.Modules.AddCandidate.DeJambList.temp+Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH - 1)/Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length)*100+'%';
                                if(pointer == Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length){
                                    _('blkkk').classList.add('mva-blink');
                                }
                            break;
                            
                            default: 
                                __I.H_ide('demsgBoxCandidte');//hide main prog upd REMOV IF ERROR EXPLODE
                                _('deuptoNumberOfCAd').innerText = Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH;
                                _('deupgetInvADMITTED').innerHTML = (Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH) +' / '+ Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length;
                                __I.S_how('demsgBoxUpdted');//REMOV IF ERROR EXPLODE
                                //__I.ExelHandler.DeJambList.currntUpdatedValue = pointer;
                                pointer =  pointer + 1;//2
                                if(pointer < Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length){
                                    Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH++;
                                    Telemedicine.Modules.AddCandidate.DeJambList.currntUpdatedValue = pointer;
                                    Telemedicine.Modules.AddCandidate.DeJambList.clAjF(pointer);
                                }
                                //if(pointer == __I.ExelHandler.DeJambList.arrEl.length){
                                    _('insrted').innerText = Telemedicine.Modules.AddCandidate.DeJambList.temp - 1;
                                    _('upftd').innerText = Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH;
                                    _('detransactC').innerText = parseInt((Telemedicine.Modules.AddCandidate.DeJambList.temp - 1)) + parseInt(Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH);;
                                    //__I.S_howV('gttran');
                                //}
                                _('deuprtyrin').innerText = ((Telemedicine.Modules.AddCandidate.DeJambList.temp+Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH - 1)/Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length)*100+'%';
                                if(pointer == Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length){
                                    _('getbli').classList.add('mva-blink');
                                }
                            break;
                        }
                    }
                    }
                },'data='+encodeURIComponent(JSON.stringify(holdObj)));
                },
                calSum:()=>{
                    return parseInt(Telemedicine.Modules.AddCandidate.DeJambList.arrEl.length) - parseInt(Telemedicine.Modules.AddCandidate.DeJambList.currntUpdatedValue);
                },
                AudioMain:{
                    play:function(showPause,hidePlay){
                         __I.H_ide(hidePlay);
                        __I.S_how(showPause);
                        Telemedicine.Modules.AddCandidate.DeJambList.audio = true;
                        Telemedicine.Modules.AddCandidate.DeJambList.clAjF(Telemedicine.Modules.AddCandidate.DeJambList.audioPointer);
                    },
                    pause:function(hidePlay,showPause){
                        __I.S_how(hidePlay);
                        __I.H_ide(showPause);
                        Telemedicine.Modules.AddCandidate.DeJambList.audio = false;
                    },
                    stop:function(msgBxProInvADMITTED){
                        Telemedicine.Modules.AddCandidate.DeJambList.audio = false; 
                        Telemedicine.Modules.AddCandidate.DeJambList.tempinvPH = 0;
                        Telemedicine.Modules.AddCandidate.DeJambList.temp = 0;
                        __I.H_ide(msgBxProInvADMITTED);
                        window.location = "index.php";
                    },
                }
            },
            
            contr:function(tdr){
                tdr.parentElement.classList.toggle('open');
           },
            // method that views appointment
            loadLGA:(ID)=>{
                __I.notifyLoader.notify('Loading LGA...');
                var getJsonAtr = {};
                getJsonAtr['param'] = _(ID).value;
                ajaxPOST("script/loadlga.php",function(){//readAdmisionList.php
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            var responsses = __I.T_trim(this.responseText);
                            __I.notifyLoader.exitNoyify();
                            _('getLGA').innerHTML = responsses;
                        }
                    }
                },'data='+encodeURIComponent(JSON.stringify(getJsonAtr)));
            },
            addNewCandidateDE:()=>{
                var holdObj = {};
                holdObj['tel_sur_name'] = __I.T_trim(_('tel_sur_name').value);//store 
                holdObj['tel_fn_name'] = __I.T_trim(_('tel_fn_name').value);
                holdObj['tel_othr_names'] = __I.T_trim(_('tel_othr_names').value);//store 
                holdObj['tel_jam_number'] = __I.T_trim(_('tel_jam_number').value);//store 
                holdObj['getstate'] = __I.T_trim(_('getstate').value);
                holdObj['getLGA'] = __I.T_trim(_('getLGA').value);
                holdObj['adm__DoB'] = __I.T_trim(_('adm__DoB').value);
                holdObj['getDpet'] = __I.T_trim(_('getDpet').value);
                holdObj['tel_modentry'] = __I.T_trim(_('tel_modentry').value);
                holdObj['getNationality'] = __I.T_trim(_('getNationality').value);
                // holdObj['tel_Gender'] = __I.T_trim(_('tel_Gender').value);
                holdObj['holdStafID'] = Telemedicine.Login.holdRegno;
                if((__I.T_trim(_('adm__DoB').value)).length != 10)return __I.FormAlart.mainInit('Wrong date format');
                __I.H_ide('NextBtn__');
                __I.S_how('showProgress__');
                ajaxPOST("script/addnewcandidatede.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            _('tel_sur_name').value = '';
                            _('tel_fn_name').value = '';
                            _('tel_othr_names').value = '';
                            _('tel_jam_number').value = '';
                            _('getstate').value = '';
                            _('getLGA').value = '';
                            _('adm__DoB').value = '';
                            _('getDpet').value = '';
                            _('tel_modentry').value = '';
                            _('getNationality').value = '';
                            __I.H_ide('showProgress__');
                            __I.S_how('NextBtn__');
                            var responsses = __I.T_trim(this.responseText);
                            Records.Engine.exitWindow('sideNav_id');
                            __I.FormAlart.mainInit(responsses);return;
                        }
                    }
                 },"data="+encodeURIComponent(JSON.stringify(holdObj)));
            },
            addNewCandidate:()=>{
                var holdObj = {};
                holdObj['tel_sur_name'] = __I.T_trim(_('tel_sur_name').value);//store 
                holdObj['tel_fn_name'] = __I.T_trim(_('tel_fn_name').value);
                holdObj['tel_othr_names'] = __I.T_trim(_('tel_othr_names').value);//store 
                holdObj['tel_jam_number'] = __I.T_trim(_('tel_jam_number').value);//store 
                holdObj['getstate'] = __I.T_trim(_('getstate').value);
                holdObj['getLGA'] = __I.T_trim(_('getLGA').value);
                holdObj['Subject1__'] = __I.T_trim(_('Subject1__').value);
                holdObj['Subject2__'] = __I.T_trim(_('Subject2__').value);
                holdObj['Subject3__'] = __I.T_trim(_('Subject3__').value);
                holdObj['Subject4__'] = __I.T_trim(_('Subject4__').value);
                holdObj['tel_jambScor'] = __I.T_trim(_('tel_jambScor').value);
                holdObj['adm__DoB'] = __I.T_trim(_('adm__DoB').value);
                holdObj['getDpet'] = __I.T_trim(_('getDpet').value);
                holdObj['tel_modentry'] = __I.T_trim(_('tel_modentry').value);
                holdObj['getNationality'] = __I.T_trim(_('getNationality').value);
                holdObj['tel_Gender'] = __I.T_trim(_('tel_Gender').value);
                holdObj['holdStafID'] = Telemedicine.Login.holdRegno;
                if((__I.T_trim(_('adm__DoB').value)).length != 10)return __I.FormAlart.mainInit('Wrong date format');
                __I.H_ide('NextBtn__');
                __I.S_how('showProgress__');
                ajaxPOST("script/addnewcandidate.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            _('tel_sur_name').value = '';
                            _('tel_fn_name').value = '';
                            _('tel_othr_names').value = '';
                            _('tel_jam_number').value = '';
                            _('getstate').value = '';
                            _('getLGA').value = '';
                            _('Subject1__').value = '';
                            _('Subject2__').value = '';
                            _('Subject3__').value = '';
                            _('Subject4__').value = '';
                            _('tel_jambScor').value = '';
                            _('adm__DoB').value = '';
                            _('getDpet').value = '';
                            _('tel_modentry').value = '';
                            _('getNationality').value = '';
                            _('tel_Gender').value = "";
                            __I.H_ide('showProgress__');
                            __I.S_how('NextBtn__');
                            var responsses = __I.T_trim(this.responseText);
                            Records.Engine.exitWindow('sideNav_id');
                            __I.FormAlart.mainInit(responsses);return;
                        }
                    }
                 },"data="+encodeURIComponent(JSON.stringify(holdObj)));
            },
        },
        // patient modules
        AdmissionList:{
            temp:1,
            getPh:null,//REMOV IF ERROR EXPLODE
            tempinvPH:1,
            pointer:0,
            computePhoneObj:(obj)=>{
                __I.notifyLoader.notify('Loading...');
                let dpet = _(obj).getAttribute('data-stabilizer');
                var gljsVar = JSON.parse(dpet);
                Telemedicine.Modules.AdmissionList.hlObj = gljsVar.holdPhoneEmail;
                Telemedicine.Modules.AdmissionList.sendSms(Telemedicine.Modules.AdmissionList.pointer);
                setTimeout(__I.notifyLoader.exitNoyify(),1000);
            },
            hlObj:'',
            updateSMSCounter:function(){
                __I.H_ide('msgBxProInvPNum');
                __I.tempinvPH = 1;
                Telemedicine.Modules.AdmissionList.sendCan();
            },
            //send notification sms to all the cand
            sendCan:function(){
                ajaxPOST("sendSMScnt.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                             var responsses = __I.T_trim(this.responseText);
                             _('getSnt_Msg').innerHTML = responsses;
                        }
                    }
                 })
               },
            sendSms:(pointer)=>{
                var getRows = Telemedicine.Modules.AdmissionList.hlObj[pointer];
                var holdObj = {};
                holdObj["Pho_neN"] = __I.T_trim(getRows[1]);
                holdObj["email"] = __I.T_trim(getRows[0]);
                holdObj["Program_Name"] = __I.T_trim(getRows[2]);
                holdObj["Jam_bN"] = __I.T_trim(getRows[3]);
                            // GEN.Admin.ManageSMS.getPh = getRows.Pho_neN;//REMOV IF ERROR EXPLODE
                            ajaxPOST("script/sentTextSMS.php",function(){//08022269656
                            if (this.readyState == 4) {
                                if(this.status == 200){
                                var responsses = __I.T_trim(this.responseText);
                                var getRRPnse = responsses.split("|");
                                var ans = getRRPnse[0];
                                switch(ans){

                                    case "SUCCESS":
                                        ajaxPOST("script/updatadmlog.php",function(){
                                            if (this.readyState == 4) {
                                                if(this.status == 200){
                                                    var responsses = __I.T_trim(this.responseText);
                                                    pointer =  pointer + 1;
                                                    _('getProgres').innerHTML = (Telemedicine.Modules.AdmissionList.temp) +' / '+Telemedicine.Modules.AdmissionList.hlObj.length;
                                                    // __I.FormAlart.exitMainBody();
                                                    __I.H_ide('msgBxProInvPNum');//hide invalid phone num REMOV IF ERROR EXPLODE
                                                    __I.S_how('msgBxProUpdated');
                                                    if(pointer < Telemedicine.Modules.AdmissionList.hlObj.length){
                                                        Telemedicine.Modules.AdmissionList.temp++;
                                                        Telemedicine.Modules.AdmissionList.sendSms(pointer);
                                                    }
                                                }
                                            }
                                        },'jam_bN='+encodeURIComponent(__I.T_trim(getRows[3]))) 
                                    break;
                                    
                                    default:  
                                        // __I.FormAlart.exitMainBody();
                                        __I.H_ide('msgBxProUpdated');//hide main prog upd REMOV IF ERROR EXPLODE
                                        _('getInvPhNum').innerHTML =  Telemedicine.Modules.AdmissionList.tempinvPH;//REMOV IF ERROR EXPLODE
                                        __I.S_how('msgBxProInvPNum');//REMOV IF ERROR EXPLODE
                                        pointer =  pointer + 1;//2
                                        if(pointer < Telemedicine.Modules.AdmissionList.hlObj.length){
                                            Telemedicine.Modules.AdmissionList.tempinvPH++;
                                            Telemedicine.Modules.AdmissionList.sendSms(pointer);
                                        }
                                    break;
                                }
                            }
                            }
                        },"data="+encodeURIComponent(JSON.stringify(holdObj)));
            },
            viewAdmitDEedList:function(){
                if(_('get_D1DE_adList').value != ""){
                __I.H_ide('v_adDE_btn');
                __I.S_how('u_cogRsrDE_v');
                var holdObj = {};
                holdObj["v_list"] = __I.T_trim(_('get_D1DE_adList').value);
                var dptext = (_('get_D1DE_adList').options[_('get_D1DE_adList').selectedIndex].text).toUpperCase();
                var dptid = __I.T_trim(_('get_D1DE_adList').value);
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?pr_id=91&vddept_list='+dptid+'&holdSes='+Telemedicine.Stabilizer.holdStrSess+'&dptext='+dptext+'');
                __I.S_how('v_adDE_btn');
                __I.H_ide('u_cogRsrDE_v');
                }else{
                    __I.FormAlart.mainInit("Select department");return;
                }
            },
            viewAdmitedList:function(){
                if(_('get_D1_adList').value != ""){
                __I.H_ide('v_ad_btn');
                __I.S_how('u_cogRsr_v');
                var holdObj = {};
                holdObj["v_list"] = __I.T_trim(_('get_D1_adList').value);
                removeFadeOut(_('id_1_dpt_view'));
                var dptext = (_('get_D1_adList').options[_('get_D1_adList').selectedIndex].text).toUpperCase();
                var dptid = __I.T_trim(_('get_D1_adList').value);
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?pr_id=90&vddept_list='+dptid+'&holdSes='+Telemedicine.Stabilizer.holdStrSess+'&dptext='+dptext+'');
                __I.H_ide('u_cogRsr_v');
                __I.S_how('v_ad_btn');
                }else{
                    __I.FormAlart.mainInit("Select department");
                }
            },
            viewCandidateList:function(){
                if(_('get_D1_adList').value != ""){
                __I.H_ide('v_ad_btn');
                __I.S_how('u_cogRsr_v');
                var holdObj = {};
                holdObj["v_list"] = __I.T_trim(_('get_D1_adList').value);
                removeFadeOut(_('id_1_dpt_view'));
                var dptext = (_('get_D1_adList').options[_('get_D1_adList').selectedIndex].text).toUpperCase();
                var dptid = __I.T_trim(_('get_D1_adList').value);
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?pr_id=95&vddept_list='+dptid+'&holdSes='+Telemedicine.Stabilizer.holdStrSess+'&dptext='+dptext+'');
                __I.H_ide('u_cogRsr_v');
                __I.S_how('v_ad_btn');
                }else{
                    __I.FormAlart.mainInit("Select department");
                }
            },
            viewDeCandidateList:()=>{
                if(_('get_D1_adList').value != ""){
                __I.H_ide('v_ad_btn');
                __I.S_how('u_cogRsr_v');
                var holdObj = {};
                holdObj["v_list"] = __I.T_trim(_('get_D1_adList').value);
                removeFadeOut(_('id_1_dpt_view'));
                var dptext = (_('get_D1_adList').options[_('get_D1_adList').selectedIndex].text).toUpperCase();
                var dptid = __I.T_trim(_('get_D1_adList').value);
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?pr_id=98&vddept_list='+dptid+'&holdSes='+Telemedicine.Stabilizer.holdStrSess+'&dptext='+dptext+'');
                __I.H_ide('u_cogRsr_v');
                __I.S_how('v_ad_btn');
                }else{
                    __I.FormAlart.mainInit("Select department");
                }
            },
            viewCandidateListRegistered:function(){
                if(_('get_D1_adList').value != ""){
                __I.H_ide('v_ad_btn');
                __I.S_how('u_cogRsr_v');
                var holdObj = {};
                holdObj["v_list"] = __I.T_trim(_('get_D1_adList').value);
                removeFadeOut(_('id_1_dpt_view'));
                var dptext = (_('get_D1_adList').options[_('get_D1_adList').selectedIndex].text).toUpperCase();
                var dptid = __I.T_trim(_('get_D1_adList').value);
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?pr_id=96&vddept_list='+dptid+'&holdSes='+Telemedicine.Stabilizer.holdStrSess+'&dptext='+dptext+'');
                __I.H_ide('u_cogRsr_v');
                __I.S_how('v_ad_btn');
                }else{
                    __I.FormAlart.mainInit("Select department");
                }
            },
            viewCandidateListBreakdown:function(){
                if(_('get_D1_adList').value != ""){
                __I.H_ide('v_ad_btn');
                __I.S_how('u_cogRsr_v');
                var dptext = (_('get_D1_adList').options[_('get_D1_adList').selectedIndex].text).toUpperCase();
                var dptid = __I.T_trim(_('get_D1_adList').value);
                // window.location = 'script/printers/slip.php?pr_id=97&vddept_list='+dptid+'&holdSes='+Telemedicine.Stabilizer.holdStrSess+'&dptext='+dptext+'';return;
                Records.Printer.admitToday('idGet_ui','script/printers/slip.php?pr_id=97&vddept_list='+dptid+'&holdSes='+Telemedicine.Stabilizer.holdStrSess+'&dptext='+dptext+'');
                __I.H_ide('u_cogRsr_v');
                __I.S_how('v_ad_btn');
                }else{
                    __I.FormAlart.mainInit("Select department");
                }
            },
            contrAdAction:(reG)=>{
                var gtCl = document.getElementsByClassName('yrt-tyr');
                for(var i = 0; i < gtCl.length; i++){
                    gtCl[i].style.display = 'none';
                }
                __I.S_how('dr_'+reG);
            },
            admitC:function(r_gno,ad_can,ulbgr){
                r_gno9t = r_gno.split('_');
                r_gno9t = r_gno9t[1];
                let dpet = _(r_gno).getAttribute('data-dept');
                let depNm = dpet.split('_');
                var holdObj = {};
                holdObj["RegNum"] =  __I.T_trim(r_gno9t);
                holdObj["DEPT"] =  __I.T_trim(depNm[0]);
                //ther should be option for promt
                _(r_gno).classList.add('cor-prev-pt');
                _(ad_can).classList.remove('w3-green');
                _(ad_can).classList.add('w3-light-grey');
                ajaxPOST("script/admitupdatedeptexel.php",function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        console.log(responsses);
                        __I.audioPlayer();
                        _(ulbgr).classList.add('cor-ul-fix-bdy');
                        Telemedicine.Modules.AdmissionList.progStat();
                    }
                }
            },"data="+encodeURIComponent(JSON.stringify(holdObj)));
            },
            undo:function(r_gno,diAb,ulbgr,ad_can){
                r_gno9t = r_gno.split('_');
                r_gno9t = r_gno9t[1];
                var holdObj = {};
                holdObj["toregN"] =  __I.T_trim(r_gno9t);
                _(r_gno).classList.remove('cor-prev-pt');
                _(ad_can).classList.remove('w3-light-grey');
                _(ad_can).classList.add('w3-green');
                ajaxPOST("script/deleteCand.php",function(){
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        __I.audioPlayer();
                        _(ulbgr).classList.remove('cor-ul-fix-bdy');
                        Telemedicine.Modules.AdmissionList.progStat();
                    }
                }
            },"data="+encodeURIComponent(JSON.stringify(holdObj)));
            },
            searchByJmDEInput:function(){
                if(!_('getJReNDE_1').value == ""){
                var holdObj = {};
                holdObj["toAjxCntr"] =  __I.T_trim(_('getJReNDE_1').value);
                __I.S_how('adm_ed_cog_4');
               ajaxPOST("script/posibladmiteddecan.php",function(){
                   if (this.readyState == 4) {
                       if(this.status == 200){
                           __I.H_ide('adm_ed_cog_4');
                           var responsses = __I.T_trim(this.responseText);
                           _('dis_admited_5').innerHTML = responsses;
                           __I.S_how('dis_admited_5');
                       }
                   }
                },"data="+encodeURIComponent(JSON.stringify(holdObj)));
                }else{
                    __I.H_ide('dis_admited_5');
                }
           },
            searchByJmOnInput:function(){
                if(!_('getJReN_1').value == ""){
                var holdObj = {};
                holdObj["xxTy"] =  _('getJReN_1').value;
                __I.S_how('adm_ed_cog_2');
               ajaxPOST("script/posibladmitedcan.php",function(){
                   if (this.readyState == 4) {
                       if(this.status == 200){
                           __I.H_ide('adm_ed_cog_2');
                           var responsses = __I.T_trim(this.responseText);
                           _('dis_admited_4').innerHTML = responsses;
                           __I.S_how('dis_admited_4');
                       }
                   }
                },"data="+encodeURIComponent(JSON.stringify(holdObj)));
                }else{
                    __I.H_ide('dis_admited_4');
                }
           },
            dashboardFuc:(URL,rebody,Obj)=>{
                Telemedicine.Stabilizer.motorController(URL,rebody,Obj);
                Telemedicine.Modules.AdmissionList.progStat();
            },
            pointer:1,
            arrEl:null,
            excelForm:function(){
                var data = new FormData();
                data.append("file1", document.querySelector("#file_123_csv").files[0]);
                __I.H_ide('uplodcog');
                __I.S_how('hiCogJam');
                Telemedicine.Modules.AdmissionList.tempinvPH = 1;
                Telemedicine.Modules.AdmissionList.temp = 1;
                Telemedicine.Modules.AdmissionList.tempinvPHin = 1;
                ajaxPOSTFile('script/readadmisionldept.php',function(){//readAdmisionList.php
                    if (this.readyState == 4) {
                        if(this.status == 200){
                        __I.H_ide('hiCogJam');
                        __I.S_how('uplodcog');
                        var responsses = __I.T_trim(this.responseText);
                        if(responsses == "*79")return __I.FormAlart.mainInit("Upload admission list");
                        if(responsses != "@!*"){
                            if(responsses != "*78"){
                                Telemedicine.Modules.AdmissionList.arrEl = JSON.parse(responsses);
                                Telemedicine.Modules.AdmissionList.clAjF(Telemedicine.Modules.AdmissionList.pointer);
                            }else{__I.FormAlart.mainInit("Delete serial number column");return;}
                            
                        }else{__I.FormAlart.mainInit("CHOOSE CSV FILE");return;}
                        }
                    }
                },data);
                        
            },
            temp:1,
            tempinvPH:1,
            tempinvPHin:1,
            audio:true,
            audioPointer:null,
            clAjF:function(pointer){
                if(Telemedicine.Modules.AdmissionList.audio == false)return;
                var getRows = Telemedicine.Modules.AdmissionList.arrEl[pointer];
                Telemedicine.Modules.AdmissionList.audioPointer = pointer;//this will hold the current pointer on pause
                var holdObj = {};
                holdObj["RegNum"] =  getRows.REGNUM;
                holdObj["DEPT"] =  getRows.DEPT;
                    ajaxPOST("script/admitupdatedeptexel.php",function(){//08022269656admitCandFExel.php 
                        if (this.readyState == 4) {
                            if(this.status == 200){
                            var responsses = __I.T_trim(this.responseText);
                            switch(responsses){
    
                                case "~":
                                pointer =  pointer + 1;
                                __I.H_ide('msgBxProInvADMITTEDIN');
                                __I.H_ide('msgBxProInvADMITTED');
                                if(Telemedicine.Modules.AdmissionList.audio != true)return;
                                 _('getProgresADMITTED').innerHTML = (Telemedicine.Modules.AdmissionList.temp) +'/'+ Telemedicine.Modules.AdmissionList.arrEl.length;
                                 _('totalNumberOfCAd').innerHTML = parseInt(Telemedicine.Modules.AdmissionList.temp) +  parseInt(Telemedicine.Modules.AdmissionList.tempinvPH);
                                __I.S_how('msgBxProUpdatedADMITTED');
                                    if(pointer < Telemedicine.Modules.AdmissionList.arrEl.length){
                                        Telemedicine.Modules.AdmissionList.temp++;
                                        Telemedicine.Modules.AdmissionList.clAjF(pointer);
                                    }
                                    _('dertyrinadmi').innerText = ((Telemedicine.Modules.AdmissionList.temp - 1+Telemedicine.Modules.AdmissionList.tempinvPH+Telemedicine.Modules.AdmissionList.tempinvPHin)/Telemedicine.Modules.AdmissionList.arrEl.length)*100+'%';
                                    if(pointer == Telemedicine.Modules.AdmissionList.arrEl.length){
                                        _('dededeinsrtedin').innerText = (Telemedicine.Modules.AdmissionList.temp - 1);
                                        _('dededeupftdup').innerText = Telemedicine.Modules.AdmissionList.tempinvPH;
                                        _('dededeupftdinv').innerText = Telemedicine.Modules.AdmissionList.tempinvPHin;
                                        _('dedededetransactCto').innerText = Telemedicine.Modules.AdmissionList.arrEl.length;
                                        __I.S_how('displyAll');
                                        Telemedicine.Modules.AdmissionList.progStat();
                                    }
                                // GEN.Admin.rightNav.progStat();   
                                break;
                                
                                case "*||":
                                    pointer =  pointer + 1;//2
                                    __I.H_ide('msgBxProInvADMITTEDIN');
                                    __I.H_ide('msgBxProUpdatedADMITTED');//hide main prog upd REMOV IF ERROR EXPLODE
                                    if(Telemedicine.Modules.AdmissionList.audio != true)return;
                                    _('getInvADMITTED').innerHTML = ((Telemedicine.Modules.AdmissionList.tempinvPH) +1 ) +'/'+ Telemedicine.Modules.AdmissionList.arrEl.length;
                                    _('toNumberOfCAd').innerHTML = parseInt(Telemedicine.Modules.AdmissionList.temp) +  parseInt(Telemedicine.Modules.AdmissionList.tempinvPH);
                                    __I.S_how('msgBxProInvADMITTED');
                                    if(pointer < Telemedicine.Modules.AdmissionList.arrEl.length){
                                        Telemedicine.Modules.AdmissionList.tempinvPH++;
                                        Telemedicine.Modules.AdmissionList.clAjF(pointer);
                                    }
                                    _('dertyrinadmialready').innerText = ((Telemedicine.Modules.AdmissionList.temp+Telemedicine.Modules.AdmissionList.tempinvPH+Telemedicine.Modules.AdmissionList.tempinvPHin)/Telemedicine.Modules.AdmissionList.arrEl.length)*100+'%';
                                    if(pointer == Telemedicine.Modules.AdmissionList.arrEl.length){
                                        _('dededeinsrtedinal').innerText = Telemedicine.Modules.AdmissionList.temp;
                                        _('dededeupftdupal').innerText = Telemedicine.Modules.AdmissionList.tempinvPH;
                                        _('dededeupftdinval').innerText = Telemedicine.Modules.AdmissionList.tempinvPHin;
                                        _('dedededetransactCtoal').innerText = Telemedicine.Modules.AdmissionList.arrEl.length;
                                        __I.S_how('displyAllal');
                                        Telemedicine.Modules.AdmissionList.progStat();
                                    }
                                    // GEN.Admin.rightNav.progStat();
                                break;

                                case "@*|~":
                                        pointer =  pointer + 1;//2
                                        __I.H_ide('msgBxProInvADMITTED');
                                        __I.H_ide('msgBxProUpdatedADMITTED');//hide main prog upd REMOV IF ERROR EXPLODE
                                        if(Telemedicine.Modules.AdmissionList.audio != true)return;
                                        _('getInvADMITTEDiv').innerHTML = (Telemedicine.Modules.AdmissionList.tempinvPHin) +'/'+ Telemedicine.Modules.AdmissionList.arrEl.length;
                                        _('toNumberOfCAdiN').innerHTML = parseInt(Telemedicine.Modules.AdmissionList.temp) +  parseInt(Telemedicine.Modules.AdmissionList.tempinvPH) + parseInt(Telemedicine.Modules.AdmissionList.tempinvPHin);
                                        __I.S_how('msgBxProInvADMITTEDIN');
                                        if(pointer < Telemedicine.Modules.AdmissionList.arrEl.length){
                                            Telemedicine.Modules.AdmissionList.tempinvPHin++;
                                            Telemedicine.Modules.AdmissionList.clAjF(pointer);
                                        }
                                        // GEN.Admin.rightNav.progStat();
                                break;

                                default:
                                    __I.FormAlart.mainInit("Contact ICT");
                                break;
                            }
                        }
                        }
                    },"data="+encodeURIComponent(JSON.stringify(holdObj)));
            },
            progStat:()=>{
                ajaxPOST("script/progstat.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            var responsses = __I.T_trim(this.responseText);
                            // console.log(responsses);return;
                            if(responsses != "@!"){
                                var ps = JSON.parse(responsses);
                                //total candidate
                                _('getTotalC1').innerHTML = ""+ps.TC[1]+"%";
                                _('getIntWidth1').style.width = ""+ps.TC[1]+"%";
                                // console.log(ps.TC[0]);
                                _('getTextn1').innerText = ""+ps.TC[0]+"";
                                //total de candidate 
                                _('TNumber1').innerHTML = ""+ps.TDEC[1]+"%";;
                                _('getTDEC1').style.width = ""+ps.TDEC[1]+"%";
                                _('getdeTextn1').innerText = ps.TDEC[0];
                                //total admissble candidate
                                _('getAddTextn').innerText = ps.TADMC[0];
                                Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(ps.TADMC[1]),'shwReGPrinting12x1','counter123x1');
                                //total Candidate Not admissible
                                _('getNotaAddTextnx1').innerText = ps.TCNAMS[0];
                                Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(ps.TCNAMS[1]),'shwReGPrinting13x1','counter12345x1');
                                //admitted
                                _('getAddTextnR1').innerText = ps.TNADC[0];
                                Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(ps.TNADC[1]),'shwReGPrinting','counterx1');
                                /**/
                                _('getNotaAddTextnRx1').innerText = ps.ADMIC[0];
                                Telemedicine.Stabilizer.CanvasObj.canvas(Math.floor(ps.ADMIC[1]),'shwReGPrinting1x1','counter1x1');
                                /*admitted today*/
                                // _('adtodyTNumber').innerText = ps.AdmitedToday[0]+"%";
                                // _('getIntWidthToday').style.width = ""+ps.AdmitedToday[0]+"%";
                                // _('getdeTextnTody').innerText = ps.AdmitedToday[1];
                                /*notify*/
                                // _('adtodyTNumberNotify').innerText = ps.Notification[0]+"%";
                                // _('getIntWidthTodayNotify').style.width = ""+ps.Notification[0]+"%";
                                // _('getdeNotifyTody').innerText = ps.Notification[1];
                                /*admitted de*/
                                // _('admitedDE').innerText = ps.TotalAdmitedDe[0]+"%";
                                // _('getIntWidthAdmDE').style.width = ""+ps.TotalAdmitedDe[0]+"%";
                                // _('getdeAdDe').innerText = ps.TotalAdmitedDe[1];
                                /*not admitted de*/
                                // _('admitedNOTDE').innerText = ps.TotalDeNotAdmit[0]+"%";
                                // _('getIntWidthAdmDENOT').style.width = ""+ps.TotalDeNotAdmit[0]+"%";
                                // _('getdeAdNOTDe').innerText = ps.TotalDeNotAdmit[1];
                            }
                        }
                    }
                 },'');
            },
            updateAllF:function(){
                GEN.Admin.admisionCaps.admissions.admitedToday();
                GEN.Admin.admisionCaps.admissions.liveAdmitedcnt();
                GEN.Admin.admisionCaps.admissions.liveNotAdmitedcnt();
                GEN.Admin.admisionCaps.DirectEntry.admitedDEToday()
                GEN.Admin.admisionCaps.DirectEntry.liveNotDEAdmitedcnt()
            },
            audioMain:{
                play:function(showPause,hidePlay){
                    __I.H_ide(hidePlay);
                    __I.S_how(showPause);
                    Telemedicine.Modules.AdmissionList.audio = true;
                    Telemedicine.Modules.AdmissionList.clAjF((Telemedicine.Modules.AdmissionList.audioPointer) + 1);
                },
                pause:function(hidePlay,showPause){
                    __I.S_how(hidePlay);
                    __I.H_ide(showPause);
                    Telemedicine.Modules.AdmissionList.audio = false;
                },
                stop:function(msgBxProInvADMITTED){
                    Telemedicine.Modules.AdmissionList.audio = false; 
                    Telemedicine.Modules.AdmissionList.tempinvPH = 0;
                    Telemedicine.Modules.AdmissionList.temp = 0;
                    Telemedicine.Modules.AdmissionList.tempinvPHin = 0;
                    __I.H_ide(msgBxProInvADMITTED);
                    window.location = "index.php";
                },
            },
            displayInvCand:function(){
                __I.S_how('msgViewCantTxtINV');
                __I.S_howV('viewCogTxt1');
                __I.S_howV('plwit1');
                ajaxPOST("viewAdmINVACAN.php",function(){
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            __I.H_ideV('viewCogTxt1');
                            __I.H_ideV('plwit1');
                            _('gtView1').innerHTML = __I.T_trim(this.responseText);
                        }
                    }
                })
            },
            onchangeFileInput:function(){
                __I.S_how('excelInput');
            },
        },
        // Hospital manager modules
        JambPassport:{
            jambPassport:()=>{
                var data
                if(_('file_123_passport').value == "")return __I.FormAlart.mainInit("Choose File");
                data = new FormData();
                for(j = 0; j < _('file_123_passport').files.length; j++){
                    data.append("fileToUpload[]", document.querySelector("#file_123_passport").files[j]);
                }
                __I.H_ide('shoC_cog__');
                __I.S_how('shoC_cogjolps');
                ajaxPOSTFile('script/readjambpassport.php',function(){//readAdmisionList.php
                    if (this.readyState == 4) {
                        if(this.status == 200){
                        __I.H_ide('shoC_cogjolps');
                        __I.S_how('shoC_cog__');
                        var responsses = __I.T_trim(this.responseText);
                                    if(responsses != "*77"){
                                        if(__I.isJson(responsses) == true){
                                            let i,hohRegNo;
                                            var response = JSON.parse(responsses);
                                            hohRegNo = '';
                                            for(i = 0; i < response.InvalidRegNo.length; i++){
                                                hohRegNo+=response.InvalidRegNo[i]+'<br>'+',';
                                            }
                                            var newStr = hohRegNo==''?"NONE":hohRegNo.slice(0, -1);

                                            let tb = '<div class="w3-white" style="width:100%;height:100%;padding:5px;"><table class="w3-small w3-white" style="width:99%;margin: auto;"><tr><td>TOTAL PASSPORT SENT(s)</td><td>'+response.TotalPasportSent.length+'</td></tr><tr><td>TOTAL PASSPORT ALREADY UPDATED</td><td>'+response.JambNoNotUpdated.length+'</td></tr><tr><td>TOTAL INVALID REGISTRATION NOs.</td><td>'+response.InvalidRegNo.length+'</td></tr><tr><td>TOTAL PASSPORT INSERTED</td><td>'+response.NoOFPassportInserted.length+'</td></tr><tr><td>INVALID REGISTRATION NOs.</td><td>'+newStr+'</td></tr><tr><td>TOTAL INVALID PASSPORT EXTENSION</td><td>'+response.WrongExtensionjambNo.length+'</td></tr></table></div>';
                                            _('inerCntMot').innerHTML = tb;
                                            //_('getInnerL').innerHTML = Telemedicine.Stabilizer.backRowHTML();
                                           // __I.S_how('getRR');
                                        }else{return __I.FormAlart.mainInit("INVALID JSON PARAMETER SUPPLIED");}
                                    }else{
                                        {__I.FormAlart.mainInit("INVALID PARAMETER FROM JAMB");return;}
                                    }
                        }
                    }
                },data);
            },
        },
        JambOlevelResult:{
            jambOlvObj:'',
            pointer:0,
            jambOlevel:()=>{
                    var data = new FormData();
                    data.append("file1", document.querySelector("#file_12388").files[0]);
                    __I.H_ide('shuplodjol');
                    __I.S_how('shoC_cogjol');
                    ajaxPOSTFile('script/readjambolevel.php',function(){//readAdmisionList.php
                        if (this.readyState == 4) {
                            if(this.status == 200){
                            __I.H_ide('shoC_cogjol');
                            __I.S_how('shuplodjol');
                            var responsses = __I.T_trim(this.responseText);
                            // console.log(responsses);return;
                                if(responsses != "@!*"){
                                    if(responsses != "*78"){
                                        if(responsses != "*77"){
                                            if(__I.isJson(responsses) == true){
                                                Telemedicine.Modules.JambOlevelResult.jambOlvObj = JSON.parse(responsses);
                                                Telemedicine.Modules.JambOlevelResult.computeJambOlv(Telemedicine.Modules.JambOlevelResult.pointer);
                                                _('inerCntMot').innerHTML = '';
                                            }else{return __I.FormAlart.mainInit("INVALID PARAMETER SUPPLIED");}
                                        }else{
                                            {__I.FormAlart.mainInit("NO UPDATE MADE");return;}
                                        }
                                    }else{__I.FormAlart.mainInit("Contact ICT");return;}
                                }else{__I.FormAlart.mainInit("CHOOSE CSV FILE");return;}
                            }
                        }
                    },data);
            },
            contr:function(tdr){
                tdr.parentElement.classList.toggle('open');
           },
            tyty:'',
               enter:false,
                computeJambOlv:(pointer)=>{
                    if(Telemedicine.Modules.JambOlevelResult.jambOlvObj == ""){{__I.FormAlart.mainInit("No Object Found");return;}}
                    const jambOlvDetails = Telemedicine.Modules.JambOlevelResult.jambOlvObj[pointer];
                    clearTimeout(Telemedicine.Modules.JambOlevelResult.tyty);
                    // __I.S_how('mydiv');
                    if(Telemedicine.Modules.JambOlevelResult.enter == false){
                    //     _('processor').innerHTML = "<span id='counter1'>0</span>|<span id='counter2'>0</span> Processed Jamb O'Level Result";
                    // __I.S_how('processor');
                    Telemedicine.Modules.JambOlevelResult.enter = true;
                    }
                    ajaxPOST("script/getcandetails.php",function(){
                        if (this.readyState == 4) {
                            if(this.status == 200){
                                var responsses = __I.T_trim(this.responseText);
                                if(responsses != "*3"){
                                    let i,firtSit,holdDetails,holdDetails1,cnt,result,firstSecondS,firstSit,secondSit,firtSiting,SecSiting;
                                    if(jambOlvDetails[1].includes('###')){
                                        //compute second sittings
                                        firstSecondS = jambOlvDetails[1].split('###');
                                        firstSit = firstSecondS[0];
                                        secondSit = firstSecondS[1];
                                        firtSiting = firstSit.split(';');
                                        holdDetails1 = '<table class="w3-small" style="width:98%;margin: auto;"><tr><th>S/N</th><th>FIRST SITTING</th></tr>';
                                        for(i = 0; i < firtSiting.length; i++){
                                            cnt = i +1;
                                            result = firtSiting[i]
                                            result = result.replace("=", " : ");
                                            holdDetails1+='<tr><td>'+cnt+'</td><td>'+result+'</td></tr>';
                                        }
                                        holdDetails1+='</table>';
                                        // second sittings
                                        SecSiting = secondSit.split(';');
                                        holdDetails2 = '<table class="w3-small" style="width:98%;margin: auto;"><tr><th>S/N</th><th>SECOND SITTING</th></tr>';
                                        for(i = 0; i < SecSiting.length; i++){
                                            cnt = i +1;
                                            result = SecSiting[i]
                                            result = result.replace("=", " : ");
                                            holdDetails2+='<tr><td>'+cnt+'</td><td>'+result+'</td></tr>';
                                        }
                                        holdDetails2+='</table>';
                                        holdDetails = '<div class="w3-row"><div class="w3-col s6">'+holdDetails1+'</div><div class="w3-col s6">'+holdDetails2+'</div></div>';
                                    }else{
                                        firtSit = jambOlvDetails[1].split(';');
                                        holdDetails = '<table class="w3-small" style="width:70%;margin: auto;">';
                                        for(i = 0; i < firtSit.length; i++){
                                            cnt = i +1;
                                            result = firtSit[i]
                                            result = result.replace("=", ":");
                                            holdDetails+='<tr><td>'+cnt+'</td><td>'+result+'</td></tr>';
                                        }
                                        holdDetails+='</table>';
                                       
                                    }
                                    pointer = pointer + 1;
                                    var gtTabs = _('inerCntMot');
                                    gtTabs.insertAdjacentHTML('afterbegin','<div class="equ-togle-btn cor-border-bottom equ-tog-ch" style="margin-top: 2px;"><div onclick="Telemedicine.Modules.JambOlevelResult.contr(this)" class="equ-toggle-log w3-row cor-pointer w3-card-4 xxyy" style="padding: 6px;transition: background-color 0.6s ease;box-shadow: 0 14px 28px rgb(0 0 0 / 25%), 0 10px 10px rgb(0 0 0 / 22%); border: rgba(255,255,255,.05) thin solid;"><div class="w3-col s11 equ-bar-fontz">'+pointer+' | '+jambOlvDetails[0]+' | <span>'+responsses+'</span></div><div class="w3-col s1 equ-bar-fontz"><i class="fa fa-ellipsis-v w3-right" style="margin-top:3px;"></i></div></div><div id="" class=" equ-text-bo-hover-main w3-white equ-togl-cl-clo w3-row" style="width:100%;border-bottom-left-radius:5px;border-bottom-right-radius:5px;padding:0px;transition: 0.1s ease-in 0s;">'+holdDetails+'</div></div>');
                                    let cnta = pointer + 1;
                                    // _('counter1').innerText = cnta;
                                    // _('counter2').innerText = Object.keys(Telemedicine.Modules.JambOlevelResult.jambOlvObj).length - 1;
                                   
                                    if(pointer < Object.keys(Telemedicine.Modules.JambOlevelResult.jambOlvObj).length - 2){
                                        pointer =  pointer + 1;
                                        Telemedicine.Modules.JambOlevelResult.tyty = setTimeout(function(){Telemedicine.Modules.JambOlevelResult.computeJambOlv(pointer);},200);
                                    }
                                }else{
                                    if(pointer < Object.keys(Telemedicine.Modules.JambOlevelResult.jambOlvObj).length - 2){
                                        pointer =  pointer + 1;//2
                                        Telemedicine.Modules.JambOlevelResult.tyty = setTimeout(function(){Telemedicine.Modules.JambOlevelResult.computeJambOlv(pointer);},200);
                                    }
                                }
                            }
                        }
                    },'jambbite='+encodeURIComponent(jambOlvDetails[0]));
            },
        },
    },
    // gain access to system
    Login:{
        applePhoneUsers:()=>{
            __I.S_how('installContainerApple');
        },
        kUrN:'',
        passport:'',
        verifyUrN:()=>{
            if(_('getUserN').value == ""){__I.FormAlart.mainInit('Enter Username');return;}
            __I.H_ide('showHC');
            __I.S_how('hideCSpn');
            ajaxPOST('script/veriftEmail.php',function() {
                if (this.readyState == 4) {
                    if(this.status == 200){
                        __I.H_ide('hideCSpn');
                        __I.S_how('showHC');
                        var responsses = __I.T_trim(this.responseText);
                        // console.log(responsses);return;
                        if(responsses != "*3"){
                            Telemedicine.Login.kUrN = __I.T_trim(_('getUserN').value);
                            let resp = responsses.split('~');
                            _('getPaswrdVer').innerHTML = resp[2];
                            _('u_user_name').innerText = resp[0].toUpperCase();
                            _('getUserPast').style.backgroundRepeat = "no-repeat";
                            _('getUserPast').style.backgroundSize = "cover";
                            _('getUserPast').style.backgroundPosition = "center";
                            _('getUserPast').style.backgroundAttachment = "fixed";
                            _('rmovBgr').classList.remove('cor-text-col-bgr');
                            _('getUserPast').src = "assets/images/"+resp[1]+"";
                            // Telemedicine.Login.passport = "assets/images/"+resp[1]+"";
                            __I.S_how('getUserPast');
                        }else{
                            __I.FormAlart.mainInit('Wrong Username');
                        }
                    }
                }
            },'d_userD='+encodeURIComponent(__I.T_trim(_('getUserN').value)));
        },
        kpwAdId:'',
        holdRegno:'',
        holdStrSess:'',
        privilg:'',
        acescode:'',
        verifyPasswrd:()=>{
            if(_('getPawrd').value == ""){__I.FormAlart.mainInit('ENTER PASSWORD');return;}
            __I.H_ide('showHCP');
            __I.S_how('hideCSpnP');
            __I.NewLoginSystem.myuuu = null;
            ajaxPOST('script/verifyPassword.php',function() {
                if (this.readyState == 4) {
                    if(this.status == 200){
                        __I.H_ide('hideCSpnP');
                        __I.S_how('showHCP');
                        var responsses = __I.T_trim(this.responseText);
                        if(responsses != "*3"){
                            var slpi = responsses.split('~');
                            __I.Cooky.setCookie('getUserName',slpi[0],1000000);
                            __I.Cooky.setCookie('userImage',slpi[1],1000000);
                            __I.Cooky.setCookie('user__nextbtn',Telemedicine.Login.kUrN,1000000);
                            __I.Cooky.setCookie('user__previousbtn',__I.T_trim(_('getPawrd').value),1000000);
                            Telemedicine.Login.holdRegno = slpi[3];
                            // Telemedicine.Stabilizer.holdUserPrivileges = slpi[4];
                            // Telemedicine.Stabilizer.holdStrSess = slpi[5];
                            Telemedicine.Login.acescode = slpi[2];
                            ajaxPOST('controls.php',function() {
                                if (this.readyState == 4) {
                                    if(this.status == 200){
                                        var responsses = __I.T_trim(this.responseText);
                                        _('grtcntrProg').innerHTML = responsses;
                                        _('getUserphoto').src = "assets/images/"+slpi[1]+"";
                                        Telemedicine.Login.passport = "assets/images/"+slpi[1]+"";
                                        __I.LoginDoorOpen('doorleft','doorright','exitSubLogin__');
                                        __I.H_ide('logOutR');
                                    }
                                }
                            },'');
                            // _('getUserphoto').src = "assets/images/"+slpi[1]+"";
                            // Telemedicine.Login.passport = "assets/images/"+slpi[1]+"";
                            // __I.LoginDoorOpen('doorleft','doorright','exitSubLogin');
                            // clearTimeout(Telemedicine.ChatBox.updateChat);
                        }else{
                            __I.FormAlart.mainInit('Wrong Password And Username');
                        }
                    }
                }
            },'d_userD='+encodeURIComponent(__I.T_trim(Telemedicine.Login.kUrN))+'&pard='+encodeURIComponent(__I.T_trim(_('getPawrd').value)));
        },
        myuuu:null,
        retxxx:()=>{
            ajaxPOST('controls.php',function() {
                if (this.readyState == 4) {
                    if(this.status == 200){
                        var responsses = __I.T_trim(this.responseText);
                        _('progresxxxbars').innerHTML = responsses;
                        //NGMO.loadBusi();
                    }
                }
            },'');
        },
        startAppStabilizer:()=>{
            var userApp,userAppPrev;
            userApp = __I.Cooky.useCookie('user__nextbtn');
            userAppPrev = __I.Cooky.useCookie('user__previousbtn');
            if(userApp != undefined || userAppPrev != undefined){
                // maintain app session
                __I.notifyLoader.notify('Preparing Dashboard');
                ajaxPOST('script/verifyPassword.php',function() {
                    if (this.readyState == 4) {
                        if(this.status == 200){
                            __I.notifyLoader.exitNoyify();
                            var responsses = __I.T_trim(this.responseText);
                            __I.H_ide('logOutR');
                            // console.log(responsses);return;
                            if(responsses != "*3"){
                                var slpi = responsses.split('~');
                                __I.Cooky.setCookie('getUserName',slpi[0],1000000);
                                __I.Cooky.setCookie('userImage',slpi[1],1000000);
                                __I.Cooky.setCookie('user__nextbtn',userApp,1000000);
                                __I.Cooky.setCookie('user__previousbtn',userAppPrev,1000000);
                                Telemedicine.Login.holdRegno = slpi[3];
                                // Telemedicine.Stabilizer.holdUserPrivileges = slpi[4];
                                // Telemedicine.Stabilizer.holdStrSess = slpi[5];
                                Telemedicine.Login.acescode = slpi[2];
                                ajaxPOST('controls.php',function() {
                                    if (this.readyState == 4) {
                                        if(this.status == 200){
                                            var responsses = __I.T_trim(this.responseText);
                                            _('grtcntrProg').innerHTML = responsses;
                                            _('getUserphoto').src = "assets/images/"+slpi[1]+"";
                                            Telemedicine.Login.passport = "assets/images/"+slpi[1]+"";
                                            __I.LoginDoorOpen('doorleft','doorright','exitSubLogin__');
                                            
                                        }
                                    }
                                },'');
                                // Telemedicine.Login.passport = "assets/images/"+slpi[1]+"";
                                // _('getUserphoto').src = "assets/images/"+slpi[1]+"";
                                // clearTimeout(Telemedicine.ChatBox.updateChat);
                                // __I.LoginDoorOpen('doorleft','doorright','exitSubLogin');
                                
                            }else{
                                __I.FormAlart.mainInit('Wrong Password And Username');
                            }
                        }
                    }
                },'d_userD='+encodeURIComponent(userApp)+'&pard='+encodeURIComponent(userAppPrev));
            }
        },
    },
    // exit App
    exitApp:()=>{
        __I.notifyLoader.notify('Logging out...');
        setTimeout(()=>{
            __I.Cooky.deleteCookie('getUserName');
            __I.Cooky.deleteCookie('user__nextbtn');
            __I.Cooky.deleteCookie('user__previousbtn');
            window.location='index.php';
        },500);
    },
};
document.addEventListener("DOMContentLoaded",function(){
    // maintainUser
    Telemedicine.Login.startAppStabilizer();
});
//resgister the service worker
// if("serviceWorker" in navigator){
//     window.addEventListener("load",function(){
//         navigator.serviceWorker.register("serviceWorker.js").then(res=>{
//             console.log("service worker registered");
//             console.log(res);
//         }).catch(err=>console.log("servcice worker not registered",err))
//     });
// };
// const divInstall = document.getElementById('installContainer');
// const butInstall = document.getElementById('butInstall');
// let defferedPrompt;
// if(window.matchMedia("(display-mode:fullscreen)").matches){
//     divInstall.style.display = 'none';   
// }
// window.addEventListener('beforeinstallprompt', event => {
//     event.preventDefault();
//     defferedPrompt = event;
//     divInstall.style.display = 'block';
// });
// if(butInstall){
//     butInstall.addEventListener('click', async () => {
//         if (defferedPrompt !== null) {
//             defferedPrompt.prompt();
//             const { outcome } = await defferedPrompt.userChoice;
//             if (outcome === 'accepted') {
//                 defferedPrompt = null;
//                 divInstall.style.display = 'none';
//             }else{
//                 divInstall.style.display = 'none';
//             }
//         }
//     });
// }
// end resgister the service worker
function removeFadeOut(el){
    el.classList.remove('visible');
    el.classList.add('hidden');
}