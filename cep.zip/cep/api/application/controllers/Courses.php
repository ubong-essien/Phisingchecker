<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Courses extends CI_Controller {

	private function check_pay($payid,$regno){
        $this->load->model('portal_m');
        $portal_setup = $this->portal_m->get_portal_details();
        $pay = $this->register_m->check_payment($payid,$regno, $portal_setup['current_sem'], $portal_setup['current_ses']);
        if($pay > 0){
            return True;
        }else{
            return False;
        }
            return False;
    }


	public function load_courses(){
		// print_r($_POST);die;
		$candidate_data=$this->input->post('data',TRUE);
        $cand = json_decode($candidate_data);
		$regno = trim($cand->cep__jmbno__);

	$portal_setup = $this->portal_m->get_portal_details();
		$has_reg_course = $this->course_m->check_previous_coursereg($regno,$portal_setup['current_sem']);

		if(count($has_reg_course) > 0){
			die(json_encode(["ERROR" => ["Message" => "COURSE ALREADY REGISTERED. USE COURSE HISTORY TO EDIT YOUR COURSE FORM"]]));
		}
		//get the student details
	
		$is_student = $this->admission_m->get_adm_student_details($regno);
		if(count($is_student) > 0){
			$name = $is_student[0]['SurName'].", ".$is_student[0]['FirstName']." ".$is_student[0]['OtherNames'];
            $moe = $is_student[0]['ModeOfEntry'];
            $JambNo = $is_student[0]['JambNo'];
            $ProgName = $is_student[0]['ProgName'];
            $Gender = $is_student[0]['Gender'];
            $Reglvl = $is_student[0]['RegLevel'];
            $passport = $is_student[0]['Passport'];
            $StartSes = $is_student[0]['StartSes'];
            $ProgID = $is_student[0]['ProgID'];
			$pay_item = 0;
			//get the students level
			$lvl = ($portal_setup['current_ses'] - $is_student[0]['StartSes']) + 1;
			//check the previous semester course registration
			//decode previous semester
			$Prev_sems = 0;
			if($portal_setup['current_sem'] == 1){
				$Prev_sems = 2;
			}else if($portal_setup['current_sem'] == 2){
				$Prev_sems = 1;
			}
			if($moe==1){$pay_item = 5;}else{$pay_item = 6;}

			$has_paid = $this->payment_m->check_schfee_pay($pay_item,$JambNo,$portal_setup['current_sem'],$portal_setup['current_ses']);

			if(count($has_paid) > 0){
				if(($lvl == 1) && ($portal_setup['current_sem'] == 1)){
					//dont check previous
				
					//load courses based on semseter,level
					$courses = $this->course_m->load_courses($lvl,$ProgID,$portal_setup['current_sem'],$portal_setup['current_ses']);
					die(json_encode(["SUCCESS" => ["Message" => $courses]]));
				}else{
			
					//check previous
					$has_prev = $this->course_m->check_previous_coursereg($JambNo,$portal_setup['current_sem']);
					if(count($has_prev) == 0){

						die(json_encode(["ERROR" => ["Message" => "Previous Course Registration Not Found"]]));
					}else{
					$course = $this->course_m->load_courses($lvl,$ProgID,$portal_setup['current_sem'],$portal_setup['current_ses']);
					die(json_encode(["SUCCESS" => ["Message" => $course]]));
					}
				}

			}else{
				die(json_encode(["ERROR" => ["Message" => "NO Fee Payment,Please Make Your Payment to be able register "]]));
			}
		
		}else{
			die(json_encode(["ERROR" => ["Message" => "Invalid operation attempted "]]));
		}
	}

	public function register_courses(){

		$coursedata=$this->input->post('data',TRUE);
	$courses = json_decode($coursedata);
	$Regno = trim($courses->cep__jmbno__); 
	$Courses_data =$courses->holdCourses; 
	$Courses_data = json_encode($Courses_data);
	$totalCh = trim($courses->totalCh); 
	//check if course egistration has been done already
	// var_dump($Courses_data);die;
	$portal_setup = $this->portal_m->get_portal_details();
	$has_reg_course = $this->course_m->check_previous_coursereg($Regno,$portal_setup['current_sem']);
	
	if(count($has_reg_course) > 0){
		die(json_encode(["ERROR" => ["Message" => "COURSE ALREADY REGISTERED. USE COURSE HISTORY TO EDIT YOUR COURSE FORM"]]));
	}

	$is_student = $this->admission_m->get_adm_student_details($Regno);
	$moe = $is_student[0]['ModeOfEntry'];

	if((int)$moe == 1){$Payitem = 5;}else if((int)$moe == 2){$Payitem = 6;}
	$has_paid = $this->payment_m->check_schfee_pay($Payitem,$Regno,$portal_setup['current_sem'],$portal_setup['current_ses']);
	
				if(count($has_paid) > 0){
					// calculate his current level
					
					$lvl = ($portal_setup['current_ses'] - $is_student[0]['StartSes']) + 1;
	
					$reg_data = array(
						"RegNo"=>$Regno,
						"Lvl"=>$lvl,
						"CoursesID"=>$Courses_data,
						"SesID"=>$portal_setup['current_ses'],
						"Sem"=>$portal_setup['current_sem'],
						"TotCH"=>$totalCh,
						"Bulk"=>0,
						"CouresRegData"=>$Courses_data,
						"RegDate"=>date('Y-m-d')
					);
					$c_status = $this->course_m->register_course($reg_data);
					if($c_status > 0){
						die(json_encode(["SUCCESS" => ["Message" => "COURSE REGISTERED SUCCESSFLLY","CID"=> $c_status]]));
					}
	
				}else{
					die(json_encode(["ERROR" => ["Message" => "NO Fee Payment,Please Make Your Payment to be able register "]]));
				}
	
		}
	public function coursereg_history(){
	
		// die("rrrrrr");
		$history = array();
		$coursedata=$this->input->post('data',TRUE);
		$courses = json_decode($coursedata);
		$Jambno = trim($courses->cep__jmbno__); 
		$courseregs = $this->course_m->check_history_coursereg($Jambno);
		// print_r($pays);
			if(count($courseregs) > 0 ){
				
					foreach($courseregs as $coursereg){
						
						$sem = "";

									if($coursereg['Sem'] == 1){
										$sem = "FIRST SEMESTER";

									}else if($coursereg['Sem'] == 2){
										$sem = "SECOND SEMESTER";

									}
								
									$history[] = array(
										"CID"=>$coursereg['ID'],
										"Lvl"=>$coursereg['Lvl'],
										"Sem"=>$sem,
										"Ses"=>$coursereg['SesName'],
										"TotCH"=>$coursereg['TotCH'],
										"cdate"=>$coursereg['RegDate']
								);
					}
	//}
	die(json_encode(["SUCCESS" => ["Message" => $history]]));
}else{
	die(json_encode(["ERROR" => ["Message" => "No history found"]]));
}

}
}
