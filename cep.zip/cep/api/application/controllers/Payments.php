<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payments extends CI_Controller {

	private function errors($code)
	{
		$errorCode = [
			"D##" => "YOUR DEPARTMENT IS NOT ALLOWED FOR THIS EXAMS",
			"R###" => "YOU HAVE NOT REGISTERED FOR THIS EXAMS",
			"OK##" => "SUCCESS",
			"R01" => "TABLE NOT FOUND",
			"####" => "NO APPLICATIONS",
			"R03" => "Error...",
			"~#" => "UPDATED",
			"||" => "TRANSCRIPT NOT READY",
			"|" => "DISABLED",
			"|~" => "Application Restored",
			"|~~" => "Unknown Application",
			"|~~|" => "Contact ICT",
			"|~~|@" => "Student Not Found",
			"|@@" => "Invalid Reference Number",
			"R12" => "Wrong Transaction ID",
			"R13" => "Cyclic Redundant check failed",
			"R14" => "Order Number Failed",
			"R15" => "WRONG POST URL",
			"R16" => "NO SETUP FOR THE ITEM ID",
			"R17" => "No Course Setup",
			"R18" => "No Session Setup",
			"R19" => "No Result Yet",
			"R20" => "Selected Level Not Found",
			"R21" => "User Already Exist",
			"R22" => "Already Exist",
			"R23" => "Candidate Added"
		];
		return $errorCode[$code];
	}
	
	public function process_fee_payment(){
		$Jambno = "08155555555";
		$pitem=array();
        $candidate_data=$this->input->post('data',TRUE);
        // // print_r($candidate_data);die;
        $cand = json_decode($candidate_data);
        $Jambno = $cand->cep__jmbno__; 
       
        
        $portal_setup = $this->portal_m->get_portal_details();
		$is_in_studentinfo =  $this->admission_m->get_adm_student_details($Jambno);
		// print_r($is_in_studentinfo[0]);die;
		if(count($is_in_studentinfo[0]) > 0){
		// $next_pagess =$this->next_page(3);
 
		 $name = $is_in_studentinfo[0]['SurName'].", ".$is_in_studentinfo[0]['FirstName']." ".$is_in_studentinfo[0]['OtherNames'];
		 $moe = $is_in_studentinfo[0]['ModeOfEntry'];
		 $Jambno = $is_in_studentinfo[0]['JambNo'];
		 $ProgName = $is_in_studentinfo[0]['ProgName'];
		 $Phone = $is_in_studentinfo[0]['Phone'];
		 $StateId = $is_in_studentinfo[0]['StateId'];
		 $ProgID = $is_in_studentinfo[0]['ProgID'];
		
		 $StartSes = $is_in_studentinfo[0]['StartSes'];
	
		 $AMT =array();
		//$AMT = 0;
        //print_r($row);die;
		//use the mode of entry to detemine the item id in the itemid table
		$Payitem=0;
		$first_pay = 0;
		$full_pay = 0;
		$second_pay = 0;
		$pay_flag=0;
		$late_pay = 5000;
         $amt_to_pay = 0;
		if((int)$moe == 1){$Payitem = 5;}else if((int)$moe == 2){$Payitem = 6;}
			 //CHECK IF THE STUDNET HAS PAID ALREADY BEFORE PROCESSING

			$has_pay = $this->payment_m->check_schfee_pay($Payitem,$Jambno,$portal_setup['current_sem'],$portal_setup['current_ses']);
			if(!empty($has_pay) || count($has_pay) > 0){

				die(json_encode(["SUCCESS" => ["Message" => "Payment Already Made for the selected semester and Session."]]));

			}else{

				$pitem = $this->payment_m->get_Item_pay_details($Payitem);//{"Amt":15000,"TransactionCharge":700}
				//check if candidate is an indigene or NOT
				if($StateId == 3){$pay_flag = "IND";}else{$pay_flag = "NON-IND";}
				
				$brkdwn = json_decode($pitem[0]['PayBrkDn'],true);
				//set the semester payment flag
				$latep = 0;
				if($portal_setup['current_sem'] == 1){
					// $item_block = array($brkdwn[$pay_flag][1],$brkdwn[$pay_flag][3]);
					// add the first payment
					foreach($brkdwn[$pay_flag][1] as $key=> $val){
						
						$first_pay += $val;

					}
					
					$first_pay = $pitem[0]['Late_pay']== "TRUE"?$first_pay+$late_pay:$first_pay;

					$AMT[] = array("FIRST PAYMENT",$first_pay) ;
					/****************full pay**********************/
					foreach($brkdwn[$pay_flag][3] as $key=> $val){
						$full_pay += $val;
					}
					$full_pay = $pitem[0]['Late_pay']== "TRUE"?$full_pay+$late_pay:$full_pay;
					$AMT[] = array("FULL PAYMENT",$full_pay) ;
				}else{
					// add the second payment
					foreach($brkdwn[$pay_flag][2] as $key=> $val){
						$second_pay += $val;
					}
					$second_pay = $pitem[0]['Late_pay']== "TRUE"?$second_pay+$late_pay:$second_pay;

					$AMT[] = array("SECOND PAYMENT",$second_pay) ;
				}
				
				//print_r($AMT);die;
			
				die(json_encode(["SUCCESS" => ["Message" => $AMT,"Pay_Item" => $pitem[0]['ItemDescr']]]));
			

        
   	 		}
		
		}else{
			die(json_encode(["SUCCESS" => ["Message" => "No Biodata Rwegistration Found."]]));
		}
	}

	public function generate_fee_payment(){
		// print_r($_POST);die;
		// $Jambno = "08155555555";
		// $pay_tranch = "FIRST PAYMENT";
		$pitem=array();
        $candidate_data=$this->input->post('data',TRUE);
        // // print_r($candidate_data);die;
        $cand = json_decode($candidate_data);
        $Jambno = $cand->cep__jmbno__; 
		$pay_tranch =$cand->flag;
       
        
// receive the values for the payment half to pay weda hal,full or balance as a string
//check if the person has been admitted and is a full student i.e reglevel ==5
//check if a payment has been made aready
//else//genrate order


        $portal_setup = $this->portal_m->get_portal_details();
		$is_in_studentinfo =  $this->admission_m->get_adm_student_details($Jambno);
		// print_r($is_in_studentinfo[0]);die;
		if(count($is_in_studentinfo[0]) > 0){
		// $next_pagess =$this->next_page(3);
 
		 $name = $is_in_studentinfo[0]['SurName'].", ".$is_in_studentinfo[0]['FirstName']." ".$is_in_studentinfo[0]['OtherNames'];
		 $moe = $is_in_studentinfo[0]['ModeOfEntry'];
		 $Jambno = $is_in_studentinfo[0]['JambNo'];
		 $ProgName = $is_in_studentinfo[0]['ProgName'];
		 $Phone = $is_in_studentinfo[0]['Phone'];
		 $StateId = $is_in_studentinfo[0]['StateId'];
		 $ProgID = $is_in_studentinfo[0]['ProgID'];
		
		 $StartSes = $is_in_studentinfo[0]['StartSes'];
	
		 $AMT =array();
		//$AMT = 0;
        //print_r($row);die;
		//use the mode of entry to detemine the item id in the itemid table
		$Payitem=0;
		$first_pay = 0;
		$full_pay = 0;
		$second_pay = 0;
		$pay_flag=0;
		$late_pay = 5000;
         $amt_to_pay = 0;
		if((int)$moe == 1){$Payitem = 5;}else if((int)$moe == 2){$Payitem = 6;}
			 //CHECK IF THE STUDNET HAS PAID ALREADY BEFORE PROCESSING

			$has_pay = $this->payment_m->check_schfee_pay($Payitem,$Jambno,$portal_setup['current_sem'],$portal_setup['current_ses']);

			if(!empty($has_pay) || count($has_pay) > 0){

				die(json_encode(["ERROR" => ["Message" => "Payment Already Made for the selected semester and Session."]]));

			}else{
					$what_to_pay = array("FIRST PAYMENT"=>1,"SECOND PAYMENT"=>2,"FULL PAYMENT"=>3);
				//check if there is an unpaid order
				$pay = $this->payment_m->get_unpaid_order($Payitem,$Jambno,(int)trim($what_to_pay[$pay_tranch]),$portal_setup['current_ses']);

				$pitem = $this->payment_m->get_Item_pay_details($Payitem);//{"Amt":15000,"TransactionCharge":700}
				//check if candidate is an indigene or NOT
				if($StateId == 3){$pay_flag = "IND";}else{$pay_flag = "NON-IND";}
				
				$brkdwn = json_decode($pitem[0]['PayBrkDn'],true);
				//set the semester payment flag
				// print_r($brkdwn);die;
				if((int)trim($what_to_pay[$pay_tranch]) == 1){
					
					// add the first payment
					
					foreach($brkdwn[$pay_flag][1] as $key=> $val){
						$first_pay += $val;
					}
					$amt_to_pay = $pitem[0]['Late_pay']== "TRUE"?$first_pay+$late_pay:$first_pay;
				

				}else if((int)trim($what_to_pay[$pay_tranch]) == 3){
					
					/****************full pay**********************/
					foreach($brkdwn[$pay_flag][3] as $key=> $val){
						$full_pay += $val;
					}
					$amt_to_pay = $pitem[0]['Late_pay']== "TRUE"?$full_pay+$late_pay:$full_pay;
				
				}else if((int)trim($what_to_pay[$pay_tranch]) == 2){
					// add the second payment
					foreach($brkdwn[$pay_flag][2] as $key=> $val){
						$second_pay += $val;
					}
					$amt_to_pay = $pitem[0]['Late_pay']== "TRUE"?$second_pay+$late_pay:$second_pay;

				}
				$lvl = ($portal_setup['current_ses'] - $StartSes) + 1;
				$new_expired_ref='';
				$holdInfoArray = [
					"Name" => $name,        
					"RegNo" => $Jambno,
					"PhoneNo" => $Phone,
					"ProgID" => 0,
					"ProgName" => 'NULL',
					"DeptID" => 'NULL',
					"DeptName" => 'NULL',
					"FacID" => 'NULL',
					"FacName" =>'NULL',
					"StartSes" => $StartSes,
					"ModeOfEntry" => $moe,
					"PayName" => $pitem[0]['ItemName']
				];
				if(empty($pay) || count($pay) == 0){
           
					//CREATE ORDER ARRAY
					
				   $genTenNo =  random_string('nozero',10);
					$order_data = array(
						'ItemNo'=>random_string('nozero',22),
						'TransNum'=>$genTenNo,
						'ItemName'=>$pitem[0]['ItemName'],
						'ItemDescr'=>$pitem[0]['ItemDescr'],
						'Amt'=>$amt_to_pay,
						'RegNo'=>$Jambno,
						'Sem'=>(int)trim($what_to_pay[$pay_tranch]),
						'Ses'=>$portal_setup['current_ses'],
						'Lvl'=>$lvl,
						'ItemID'=>$Payitem,
						'Paid'=>0,
						'RegDate'=>date('Y-m-d'),
						'Ses'=>$portal_setup['current_ses'],
						'BrkDwn'=>json_encode($brkdwn[$pay_flag][$what_to_pay[$pay_tranch]]),
						'Info'=>json_encode($holdInfoArray)
						
					);
				   $r =  $this->payment_m->create_order($order_data);
				   if($r){
					die(json_encode(["SUCCESS" => ["Message" => $genTenNo,"Pay_Item" => $pitem[0]['ID'],"regLvl" => $is_in_studentinfo[0]['RegLevel'],"reportP" => [$genTenNo,number_format($amt_to_pay,2),"AKSU ".$pitem[0]['ItemName']." PAYMENT"]]]));
				   }
		
				}else{
						 // check if expired ref column is empty
						 if($pay[0]['ExpiredRef'] == ''){
							//current ref is expired
							$new_expired_ref.= $pay[0]['TransNum'];
						}else{
							$expr_array = explode("~",$pay[0]['ExpiredRef']);
							$expr_array[] = $pay[0]['TransNum'];
							$new_expired_ref  = implode("~",$expr_array);
						   
						}
						 // create a new transnum
						 $new_genTenNo =  random_string('nozero',10);
			
						 $updated_order_data = array(
							 'ItemNo'=>random_string('nozero',22),
							 'TransNum'=>$new_genTenNo,
							 'ItemName'=>$pitem[0]['ItemName'],
							 'ItemDescr'=>$pitem[0]['ItemDescr'],
							 'Amt'=>$amt_to_pay,
							 'RegNo'=>$Jambno,
							 'Sem'=>(int)trim($what_to_pay[$pay_tranch]),
							 'Ses'=>$portal_setup['current_ses'],
							 'Lvl'=>$lvl,
							 'ItemID'=>$Payitem,
							 'Paid'=>0,
							 'RegDate'=>date('Y-m-d'),
							 'BrkDwn'=>json_encode($brkdwn[$pay_flag][$what_to_pay[$pay_tranch]]),
							 'ExpiredRef'=>$new_expired_ref,
							 'Info'=>json_encode($holdInfoArray)
							 
						 );
						//  print_r($updated_order_data);
						 $p =  $this->payment_m->update_order($pay[0]['ID'], $updated_order_data);
						 if($p){
						  die(json_encode(["SUCCESS" => ["Message" => $new_genTenNo,"Pay_Item" => $pitem[0]['ID'],"RegLevel"=> $is_in_studentinfo[0]['RegLevel'],"reportP" => [$new_genTenNo,number_format($amt_to_pay,2),"AKSU ".$pitem[0]['ItemName']." PAYMENT"]]]));
						 }
				}

   	 		}
		
		}else{
			die(json_encode(["SUCCESS" => ["Message" => "No Biodata Rwegistration Found."]]));
		}
	}
	public function payment_history(){
		// die("rrrrrr");
		$history = array();
		$candidate_data=$this->input->post('data',TRUE);
        // // print_r($candidate_data);die;
        $cand = json_decode($candidate_data);
        $Jambno = $cand->cep__jmbno__; 
		$pays = $this->payment_m->get_payment_history($Jambno);
		// print_r($pays);
			if(count($pays) > 0 ){
				//while($pay = $this->payment_m->get_payment_history($Jambno)){
					foreach($pays as $pay){
						
						$sem = "";

									if($pay['Sem'] == 1){
										$sem = "FIRST";

									}else if($pay['Sem'] == 2){
										$sem = "SECOND";

									}else{
										$sem = "FULL";

									}
								
									$history[] = array(
										"Lvl"=>$pay['Lvl'],
										"TransNum"=>$pay['TransNum'],
										"Sem"=>$sem,
										"Ses"=>$pay['SesName'],
										"ItemName"=>$pay['ItemName'],
										"Pdate"=>$pay['PayDate'],
										"Amount"=>$pay['Amt']
								);
							

					}
				
	//}
	die(json_encode(["SUCCESS" => ["Message" => $history]]));
}else{
	die(json_encode(["ERROR" => ["Message" => "No history found"]]));
}

	}
}
