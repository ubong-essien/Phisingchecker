<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {
    // public function __construct()
    // {
    //    // $this->load->model('portal_m');
    //     $portal_setup = $this->portal_m->get_portal_details();
    //     $this->sem = $portal_setup->current_sem;
    //     $this->ses = $portal_setup->current_ses;
    // }
    //check all payment and return the number that exist
    // private function get_portal_details(){
    //     $portal_setup = $this->portal_m->get_portal_details();
    //     $this->sem = $portal_setup['current_sem'];
    //     $this->ses = $portal_setup['current_ses'];
        
    // }
    private function next_page($pid){

        $pages = [
            ["ui/ajax/cep/pages/verification.php","REGISTER NOW"],
            ["ui/ajax/cep/pages/basicdetails.php","BASIC DETAILS"],
            ["ui/ajax/cep/pages/paymentoption.php","Make Payment"],
            ["ui/ajax/cep/pages/contactinfo.php","CONTACT INFORMATION"],
            ["ui/ajax/cep/pages/academicdetails.php","ACADEMIC DETAILS"],
            ["ui/ajax/cep/pages/finish.php","Registration Completed"]
    ];
    return $pages[$pid];
    }
    private function check_pay($payid,$regno){
        $this->load->model('portal_m');
        $portal_setup = $this->portal_m->get_portal_details();
        $pay = $this->register_m->check_payment($payid,$regno, $portal_setup['current_sem'], $portal_setup['current_ses']);
        if($pay > 0){
            return True;
        }else{
            return False;
        }
            return False;
    }

	public function Verify_candidate()
	{   
        $candidate_data=$this->input->post('data',TRUE);
        $cand = json_decode($candidate_data);
        $phone = $cand->cep__phone__; 
        $mode = $cand->cep__ModeOfEntry ;
        $moe = explode('_',$mode);
        $row = $this->register_m->get_user_details($phone,$moe[1]);
        // die;
        // pages navigation
        $pages = [
            ["ui/ajax/cep/pages/verification.php","REGISTER NOW"],
            ["ui/ajax/cep/pages/basicdetails.php","BASIC DETAILS"],
            ["ui/ajax/cep/pages/paymentoption.php","Make Payment"],
            ["ui/ajax/cep/pages/contactinfo.php","CONTACT INFORMATION"],
            ["ui/ajax/cep/pages/academicdetails.php","ACADEMIC DETAILS"],
            ["ui/ajax/cep/pages/finish.php","Registration Completed"]
        ];
        // echo count($row);die;
        if(count($row) > 0){
            $item = $this->payment_m->get_Item_pay_details($moe[1]);//{"Amt":15000,"TransactionCharge":700}
            //print_r($item[0]);
            $amt_to_pay = 0;
            // var_dump($item[0]['Transaction_charges']);die;
            if($item[0]['Transaction_charges']== "TRUE"){
    
                $Item_D = json_decode($item[0]['PayBrkDn']);
                $Amt = $Item_D->Amt;
                $TransactionCharge = $Item_D->TransactionCharge;
                $amt_to_pay = ($Amt + $TransactionCharge);
    
            }else{
                $Item_D = json_decode($item[0]['PayBrkDn']);
                $Amt = $Item_D->Amt;
                $amt_to_pay = $Amt;
            }
            //if the candidate already exist,bring the entire  record of the candidate and check the reglevel to know where to send candidate to
            $NP = ($row[0]['RegLevel'] + 1);//NP here stands for next page
            $next_page = $pages[$NP];
            $cand_details = array(
                'JambNo'=>$row[0]['JambNo'],
                'RegLevel'=>$next_page,
                'SurName'=>$row[0]['SurName'],
                'OtherNames'=>$row[0]['OtherNames'],
                'FirstNames'=>$row[0]['FirstName'],
                'ModeOfEntry'=>$row[0]['ModeOfEntry'],
                'ID'=>$row[0]['id']
            );
            die(json_encode(["SUCCESS" => ["Message" => $next_page[0],"menuHeaderTitle" => $next_page[1],"amt" => number_format($amt_to_pay,2)]]));

        }else{
           //the candidate does not exist and should be given a form to register preliminary information before payment.
           $next_page = $pages[1];
           die(json_encode(["SUCCESS" => ["Message" => $next_page[0],"menuHeaderTitle" => $next_page[1],"amt" => 0]]));
        }
	
	}
   
    public function capture_candidate(){
        $candidate_data=$this->input->post('data',TRUE);
        $cand = json_decode($candidate_data);
        $phone = $cand->cep__phone__; 
        $Mode = $cand->cep__ModeOfEntry ;
        $Surname = $cand->cep__surnm; 
        $Fname = $cand->cep__firstnm ;
        $Oname = $cand->cep__othernm ;
        $gender = $cand->cep__gendr ;

        
        $portal_setup = $this->portal_m->get_portal_details();
        $moe = explode('_',$Mode);
        $user_data = array(
            'SurName' => $Surname,         
            'FirstName' => $Fname,         
            'OtherNames' => $Oname,        
            'JambNo' => $phone,
            'Phone' => $phone,
            'StartSes' => $portal_setup['current_ses'],
            'RegLevel' => 1,
            'admitted' => 0,
            'Gender' => $gender,
            'ModeOfEntry' => $moe[1]
        );
        $next_pagess =$this->next_page(2);
       $ins = $this->register_m->create_candidate($user_data);
       if($ins > 0 ){
        $item = $this->payment_m->get_Item_pay_details($moe[1]);//{"Amt":15000,"TransactionCharge":700}
        //print_r($item[0]);
        $amt_to_pay = 0;
        if($item[0]['Transaction_charges']== "TRUE"){

            $Item_D = json_decode($item[0]['PayBrkDn']);
            $Amt = $Item_D->Amt;
            $TransactionCharge = $Item_D->TransactionCharge;
            $amt_to_pay = ($Amt + $TransactionCharge);

        }else{
            $Item_D = json_decode($item[0]['PayBrkDn']);
            $Amt = $Item_D->Amt;
            $amt_to_pay = $Amt;
        }
        die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"amt" =>  number_format($amt_to_pay,2)]]));
       }else{
            die(json_encode(["ERROR" => ["Message" => 'Initial Registration NOT Successfull']]));
       }

    }
    public function process_contact_details(){

        $Surname = 'DOE';
        $Oname = 'John';
        $Fname ='Ben';
        $Mode = 1;
        $phone = '08155212097';
        $Email = 'ubonge80@gmail.com';
        $ProgID = 1;
        $portal_setup = $this->portal_m->get_portal_details();

        $user_data = array(
            'DOB' => $Surname,         
            'Nationality' => $Fname,         
            'Addrs' => $Oname,        
            'Gender' => $phone,
            'Phone' => $phone,
            'StartSes' => $portal_setup['current_ses'],
            'RegLevel' => 0,
            'admitted' => 0,
            'ProgID' => $ProgID,
            'ModeOfEntry' => $Mode,
            'Email' => $Email
            
        );
        
       $ins = $this->register_m->update_contact_info($user_data);
       if($ins){
            die(json_encode(["SUCCESS" => ["Message" => $ins]]));
       }else{
            die(json_encode(["ERROR" => ["Message" => '##NOO']]));
       }

    }
    // public function process_form_1(){
    //     $Surname = 'DOE';
    //     $Oname = 'John';
    //     $Fname ='Ben';
    //     $Mode = 1;
    //     $phone = '08155212097';
    //     $Email = 'ubonge80@gmail.com';

    //     //$pay_status = $this->check_pay(1,$regno);
    //     if($pay_status == True){
    //         echo "The specified payment has been made.";

    //     }else{
    //         echo "The specified payment has NOT been made.";
    //     }
     
    // }

}
