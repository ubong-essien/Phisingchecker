<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payments extends CI_Controller {

	private function errors($code)
	{
		$errorCode = [
			"D##" => "YOUR DEPARTMENT IS NOT ALLOWED FOR THIS EXAMS",
			"R###" => "YOU HAVE NOT REGISTERED FOR THIS EXAMS",
			"OK##" => "SUCCESS",
			"R01" => "TABLE NOT FOUND",
			"####" => "NO APPLICATIONS",
			"R03" => "Error...",
			"~#" => "UPDATED",
			"||" => "TRANSCRIPT NOT READY",
			"|" => "DISABLED",
			"|~" => "Application Restored",
			"|~~" => "Unknown Application",
			"|~~|" => "Contact ICT",
			"|~~|@" => "Student Not Found",
			"|@@" => "Invalid Reference Number",
			"R12" => "Wrong Transaction ID",
			"R13" => "Cyclic Redundant check failed",
			"R14" => "Order Number Failed",
			"R15" => "WRONG POST URL",
			"R16" => "NO SETUP FOR THE ITEM ID",
			"R17" => "No Course Setup",
			"R18" => "No Session Setup",
			"R19" => "No Result Yet",
			"R20" => "Selected Level Not Found",
			"R21" => "User Already Exist",
			"R22" => "Already Exist",
			"R23" => "Candidate Added"
		];
		return $errorCode[$code];
	}
	public function request_url(){

		
	}
	public function response_url()
	{
		$trans_status=$this->input->get('SUCCESS',TRUE);
		$DESCRIPTION=$this->input->get('DESCRIPTION',TRUE);
		$TRANSACTION_ID=$this->input->get('TRANSACTION_ID',TRUE);
		$CHECKSUM=$this->input->get('CHECKSUM',TRUE);
		$TRANS_NUM=$this->input->get('TRANS_NUM',TRUE);
		$CARD_NO=$this->input->get('CARD_NO',TRUE);
		$CARD_TYPE=$this->input->get('CARD_TYPE',TRUE);

		// $trans_status=$this->input->get('SUCCESS',TRUE);
		// $trans_status=$this->input->get('SUCCESS',TRUE);
		// $trans_status=$this->input->get('SUCCESS',TRUE);

		if($trans_status == "C"){
			// transac successful
				// select ref no details
				// Array ( [AMOUNT] => 35700.00 [DESCRIPTION] => AKSU TRANSCRIPT FEE [CHECKSUM] => 4bcfb038ab72d9440d2db264f22b0324 [EMAIL] => enefiokduke4info@gmail.com [SUCCESS] => C [MESSAGE] => Cancel [LOGO_URL] => http://localhost/records/assets/images/FB_1.jpeg [RESPONSE_URL] => http://localhost/records/script/responseurl.php [CURRENCY_CODE] => NGN [TERMINAL_ID] => 7007139840 [TRANSACTION_ID] => 3640891380 [MERCHANT_CODE] => 700602X3D6 [RESPONSE_CODE] => C [FINAL_CHECKSUM] => 2462FB6DBEB3C0A27CE38C7E01E210DD [STATUS_REASON] => Cancel [TRANS_NUM] => 01ESA20220122091718PLHBJE [CARD_NO] => null [CARD_TYPE] => null [TRANS_DATE] => null )
				 // new checksum
				$key = 'Antman123456789';
				$iv = '2348022269656080';
				// get descript param
				$getDescp = explode(";",$DESCRIPTION);
				// $newChecksum = str_replace(";", "", $getDescp[1]);
				// $newChecksum = openssl_decrypt($newChecksum, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
				$newChecksum = explode(':',$getDescp[1]);
				$ordID = $newChecksum[0];
				//GET THE value of local checksum computd and snt to the thirdparty ,use it o ensure that the values coming are authentic
				//and the valu of the transnum and id matches before update is done.
				
				//$rstSelctRef = $_->Select("order_tb","*","TransNum = ".trim($_->SqlSafe($_GET['TRANSACTION_ID']))." AND ID = ".$ordID."");
				
				$rstSelctRef = $this->payment_m->validate_local_checksum($TRANSACTION_ID,$ordID);
				if(count($rstSelctRef) > 0){

					$OtherInfo = json_decode($rstSelctRef->Info);
					// payment details
					
					$rstTerminalID = $this->payment_m->get_thirdpartysyn($rstSelctRef->ID);
					$terminalId = '';

					// $terminalId = '7007139840';
					$sk = '';
					// $sk = 'fxPP2Yf3XuhnrCGa';
					if(count($rstTerminalID) > 0){
						$terminalId = trim($rstTerminalID[0]['TerminalID']);
						$sk = trim($rstTerminalID[0]['SecurityKey']);

					}else{
					
						die($this->errors('R16'));
					}            
					// $terminalId = '7007139840';
					$responseurl = 'https://localhost/cep/api/payments/response_url';
					
					$AmtPaid = $rstSelctRef->Amt;
					
					$cheksum = md5($AmtPaid.$terminalId.$rstSelctRef->TransNum.$responseurl.$sk);
					if($CHECKSUM != $cheksum)die($this->errors('R13'));
					
					$rstCheck = $this->payment_m->check_stud_payment($rstSelctRef->RegNo,$rstSelctRef->TransNum,$rstSelctRef->ItemID);
					if(count($rstCheck) > 0){
						$localInit = '0';
					}else{
							// update order tb set paid to 1 AK15/AGR/CRS/015
							$order_update_data = array(
								'Paid'=> 1
							);
							//update order
							$this->payment_m->update_order_by_transnum($rstSelctRef->TransNum, $order_update_data);
							
							// insert into payhistory tb
							$aksl = $rstSelctRef->TransNum.$rstSelctRef->ItemNo;
							
							$pay_det = array(
								'RegNo'=>$rstSelctRef->RegNo,
								'Lvl'=>$rstSelctRef->Lvl,
								'Sem'=>$rstSelctRef->ItemNo,
								'SemPart'=>3,
								'Ses'=>$rstSelctRef->Ses,
								'Amt'=>$rstSelctRef->Amt,
								'TransID'=>$rstSelctRef->TransNum,
								'PayID'=>$rstSelctRef->ItemID,
								'PayBrkDn'=>$rstSelctRef->BrkDwn,
								'Bank'=>$CARD_TYPE,
								'BnkBranch'=>$CARD_NO,
								'itemNum'=>$rstSelctRef->ItemNo,
								'PayDate'=>date('Y-m-d'),
								'validationNo'=>$TRANS_NUM,
								'Info'=>$rstSelctRef->Info,
								'TransAmt'=>$rstSelctRef->Amt,
								'aksl'=>$aksl,
								
							);
				
							// insert into application tb
							$rstInsertPay = $this->payment_m->insert_payment($pay_det);

							if($rstInsertPay){
								// update regLevel for registration process
								//fetch studnets record so u cn get the reglevel for payements where the item id is less that 2 i.e 1=topup,2=part_time
								if($rstSelctRef->ItemID <= 2){
									$stud = $this->register_m->get_user($rstSelctRef->RegNo);
									if(count($stud) > 0){
										$nrl = $stud[0]['RegLevel'] + 1;
										$pst = array(
											'RegLevel'=> $nrl
										);

											$this->register_m->update_reglevel($rstSelctRef->RegNo, $pst);
										
									}
								}
								
								$localInit = '0';
								$trxMsgr = 'PAYMENT SUCCESSFUL';
								die(json_encode(["SUCCESS" => ["Message" => $trxMsgr,"regLvl" => $stud[0]['RegLevel']]]));
          
							}else{
								$localInit = '-1';
							}
					}
		
				}else{
					die($this->errors('R12'));
				}
			}else{
				//if transaction failed
				die(json_encode(["ERROR" => ["Message" => 'PAYMENT FAILED']]));
			}
	}
}
