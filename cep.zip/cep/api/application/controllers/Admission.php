<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admission extends CI_Controller {
    // public function __construct()
    // {
    //    // $this->load->model('portal_m');
    //     $portal_setup = $this->portal_m->get_portal_details();
    //     $this->sem = $portal_setup->current_sem;
    //     $this->ses = $portal_setup->current_ses;
    // }
    //check all payment and return the number that exist
    // private function get_portal_details(){
    //     $portal_setup = $this->portal_m->get_portal_details();
    //     $this->sem = $portal_setup['current_sem'];
    //     $this->ses = $portal_setup['current_ses'];
        
    // }
    private function next_page($pid){

        $pages = [
            ["ui/ajax/cep/pages/admissionmessage.php","CONGRATULATIONS"],
            ["ui/ajax/cep/pages/biodataform.php","BIODATA REGISTRATION"],
            ["ui/ajax/cep/pages/biodataregform.php","PRINT BIODTA"],
            ["ui/ajax/cep/pages/finishbiodata.php","BIODATA COMPLETED"]
        ];
    return $pages[$pid];
    }
    private function check_pay($payid,$regno){
        $this->load->model('portal_m');
        $portal_setup = $this->portal_m->get_portal_details();
        $pay = $this->register_m->check_payment($payid,$regno, $portal_setup['current_sem'], $portal_setup['current_ses']);
        if($pay > 0){
            return True;
        }else{
            return False;
        }
            return False;
    }

	public function Verify_admission()
	{   
         $candidate_data=$this->input->post('data',TRUE);
         $cand = json_decode($candidate_data);
         
         $phone = $cand->cep__phone__; 
        // $mode = $cand->cep__ModeOfEntry ;
        // $moe = explode('_',$mode);
       // $regno = 
       
           //check if user has already finshed biodata and redirect to the end
           $is_in_studentinfo =  $this->admission_m->get_adm_student_details($phone);

           if(count($is_in_studentinfo) > 0){
            $next_pagess =$this->next_page(3);
    
            $name = $is_in_studentinfo[0]['SurName'].", ".$is_in_studentinfo[0]['FirstName']." ".$is_in_studentinfo[0]['OtherNames'];
            $moe = $is_in_studentinfo[0]['ModeOfEntry'];
            $JambNo = $is_in_studentinfo[0]['JambNo'];
            $ProgName = $is_in_studentinfo[0]['ProgName'];
            $Gender = $is_in_studentinfo[0]['Gender'];
            $Reglvl = $is_in_studentinfo[0]['RegLevel'];
            $passport = $is_in_studentinfo[0]['Passport'];
    
            die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"passport"=>$passport,"moe" => $moe,"Programme" => $ProgName,"Gender" => $Gender,"Name" => $name,"Reglvl" => $Reglvl,"JambNo" => $JambNo]]));
        }else{


            //IF THE CANDIDATE HAVE BN ADMITTED AND YET TO COMPLETE BIODATA
        $row = $this->admission_m->get_adm_user($phone);
        
        if(count($row) > 0){
                  //  print_r($row);die;
                $moe = $row[0]['ModeOfEntry'];
                // echo count($row);die;
                // use the mode of entry to determine the acceptance fee item id in the db
                if($moe==1){$pay_item = 3;}else{$pay_item = 4;}
                $item = $this->payment_m->get_Item_pay_details($pay_item);//{"Amt":15000,"TransactionCharge":700}

                $has_paid = $this->payment_m->check_a_payment($pay_item,$phone);
                //check if payment is made already so we direct straight to biodata form
                if(count($has_paid) >0){
                    $next_pagess =$this->next_page(1);
                    die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"Reglvl" => $row[0]['RegLevel'],"Pay_Item" => $item[0]['ID']]]));
                }
            
        //end of check

             //if($row[0]['RegLevel'] == 4){
                 $next_pagess =$this->next_page(0);
                  $user = $this->admission_m->get_adm_user($row[0]['JambNo']);
                                //   echo "a here";die;
                                //   print_r($user);die;
                                   $name = $user[0]['SurName'].", ".$user[0]['FirstName']." ".$user[0]['OtherNames'];
                                   $moe = $user[0]['ModeOfEntry'];
                                   $JambNo = $row[0]['JambNo'];
                                   $ProgName = $user[0]['ProgName'];
                                   $Gender = $user[0]['Gender'];
                                   $Reglvl = $user[0]['RegLevel'];
                                   $passport = "api/uploads/passports/".$user[0]['Passport'];

                 die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"passport"=>$passport,"moe" => $moe,"Programme" => $ProgName,"Gender" => $Gender,"Name" => $name,"Reglvl" => $Reglvl,"JambNo" => $JambNo]]));
                               
           // }
            // $item='';
            // $pay_type = $moe == 1 ? 3 : 4;
            // $item = $this->payment_m->get_Item_pay_details($pay_type);//{"Amt":15000,"TransactionCharge":700}

            // //print_r($item[0]);
            // $amt_to_pay = 0;
            // // var_dump($item[0]['Transaction_charges']);die;
            // if($item[0]['Transaction_charges']== "TRUE"){
    
            //     $Item_D = json_decode($item[0]['PayBrkDn']);
            //     $Amt = $Item_D->Amt;
            //     $TransactionCharge = $Item_D->TransactionCharge;
            //     $amt_to_pay = ($Amt + $TransactionCharge);
    
            // }else{
            //     $Item_D = json_decode($item[0]['PayBrkDn']);
            //     $Amt = $Item_D->Amt;
            //     $amt_to_pay = $Amt;
            // }
            // //if the candidate already exist,bring the entire  record of the candidate and check the reglevel to know where to send candidate to
            // $NP = ($row[0]['RegLevel'] + 1);//NP here stands for next page
            // $next_page = $pages[$NP];
            // $cand_details = array(
            //     'JambNo'=>$row[0]['JambNo'],
            //     'RegLevel'=>$next_page,
            //     'SurName'=>$row[0]['SurName'],
            //     'OtherNames'=>$row[0]['OtherNames'],
            //     'FirstNames'=>$row[0]['FirstName'],
            //     'ModeOfEntry'=>$row[0]['ModeOfEntry'],
            //     'ID'=>$row[0]['id']
            // );
            // die(json_encode(["SUCCESS" => ["Message" => $next_page[0],"menuHeaderTitle" => $next_page[1],"amt" => number_format($amt_to_pay,2),"Reglvl" => $NP]]));

        }else{

           
           
           die(json_encode(["ERROR" => ["Message" => "Sorry,You have not been admitted yet."]]));
        }
    }//end of if the person had finised the biodata and is in the studnet info
	
	}
   
    public function capture_candidate(){
        $candidate_data=$this->input->post('data',TRUE);
       
        $cand = json_decode($candidate_data);
          //var_dump($cand);die;
        $jambno = $cand->cep__phone__; 
        $nok_name = $cand->cep__name__bioda; 
        $nok_phone = $cand->cep__phone__biodata ;
        $nok_addrs = $cand->cep__address__nok ;
       
        $portal_setup = $this->portal_m->get_portal_details();
       
        $user_data = array(
            'NName' => $nok_name,         
            'NAddrs' => $nok_addrs,         
            'Nphone' => $nok_phone,        
            'RegLevel' => 5        
        );
       
       $ins = $this->admission_m->update_info($jambno,$user_data);
       if($ins > 0 ){
        $next_pagess =$this->next_page(3);
        //check if student is in studentinfo
        $is_in_studentinfo =  $this->admission_m->get_adm_student_details($jambno);

           if(count($is_in_studentinfo) > 0){
            $next_pagess =$this->next_page(3);
    
            $name = $is_in_studentinfo[0]['SurName'].", ".$is_in_studentinfo[0]['FirstName']." ".$is_in_studentinfo[0]['OtherNames'];
            $moe = $is_in_studentinfo[0]['ModeOfEntry'];
            $JambNo = $is_in_studentinfo[0]['JambNo'];
            $ProgName = $is_in_studentinfo[0]['ProgName'];
            $Gender = $is_in_studentinfo[0]['Gender'];
            $Reglvl = $is_in_studentinfo[0]['RegLevel'];
            $passport = $is_in_studentinfo[0]['Passport'];
    
            die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"passport"=>$passport,"moe" => $moe,"Programme" => $ProgName,"Gender" => $Gender,"Name" => $name,"Reglvl" => $Reglvl,"JambNo" => $JambNo]]));
        }
        $user = $this->admission_m->get_adm_user($jambno);
        //print_r($user);die;
                //insert student into the student info table


        $adm_stud_data = array(
            "SurName"=>$user[0]['SurName'],
            "FirstName"=>$user[0]['FirstName'],
            "OtherNames"=>$user[0]['OtherNames'],
            "DOB"=>$user[0]['DOB'],
            "JambNo"=>$user[0]['JambNo'],
            "RegNo"=>$user[0]['JambNo'],
            "StateId"=>$user[0]['StateId'],
            "LGA"=>$user[0]['LGA'],
            "Passport"=>"api/uploads/passports/".$user[0]['Passport'],
            "Gender"=>$user[0]['Gender'],
            "Phone"=>$user[0]['Phone'],
            "Email"=>$user[0]['Email'],
            "Addrs"=>$user[0]['Addrs'],
            "StartSes"=>$user[0]['StartSes'],
            "ModeOfEntry"=>$user[0]['ModeOfEntry'],
            "RegDate"=>$user[0]['RegDate'],
            "JambAgg"=>$user[0]['JambAgg'],
            "OlevelRstDetails"=>$user[0]['OlevelRstDetails'],
            "OlevelRst"=>$user[0]['OlevelRst'],
            "RegLevel"=>$user[0]['RegLevel'],
            "ProgID"=>$user[0]['ProgID'],
            "StudyID"=>0,
            "RegID"=>1
        );
        $new_stud = $this->admission_m->create_new_student($adm_stud_data);

                //generate the access code
                if($new_stud > 0){

                    $access_data = array(
                        "JambNo"=>$user[0]['JambNo'],
                        "AccessCode"=>"myschool"
                    );
                   $acc =  $this->admission_m->create_access($access_data);

                    //delete the record from pstudentinfo
                    if($acc){
                        $this->admission_m->remove_candidate($user[0]['id']);

                    }

            // send the details to the user as sms or email


                }
            
                                        //   echo "a here";die;
                                        //   print_r($user);die;
                                        $name = $user[0]['SurName'].", ".$user[0]['FirstName']." ".$user[0]['OtherNames'];
                                        $moe = $user[0]['ModeOfEntry'];
                                        $JambNo = $user[0]['JambNo'];
                                        $ProgName = $user[0]['ProgName'];
                                        $Gender = $user[0]['Gender'];
                                        $Reglvl = $user[0]['RegLevel'];
                                        $passport = "api/uploads/passports/".$user[0]['Passport'];

                        die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"passport"=>$passport,"moe" => $moe,"Programme" => $ProgName,"Gender" => $Gender,"Name" => $name,"Reglvl" => $Reglvl,"JambNo" => $JambNo]]));
       }else{
            die(json_encode(["ERROR" => ["Message" => 'Initial Registration NOT Successfull']]));
       }

    }

    public function process_acceptance_payment(){
        //die("gdgdgdgdg");
        $candidate_data=$this->input->post('data',TRUE);
        $cand = json_decode($candidate_data);
        $phone = trim($cand->cep__phone__); 
        $moe = $cand->cep__ModeOfEntry ;
       // $moe = explode('_',$mode);
        // die($phone);
        $portal_setup = $this->portal_m->get_portal_details();
        $row = $this->register_m->get_user_details($phone,$moe);
        $pay_item =0;
        if($moe==1){$pay_item = 3;}else{$pay_item = 4;}
        $item = $this->payment_m->get_Item_pay_details($pay_item);//{"Amt":15000,"TransactionCharge":700}
        // check if the studen has made payment already and is returning for biodata
        $has_paid = $this->payment_m->check_a_payment($pay_item,$phone);

        if(count($has_paid) >0){
            $next_pagess =$this->next_page(1);
            die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"Reglvl" => $row[0]['RegLevel'],"Pay_Item" => $item[0]['ID']]]));
        }
        $pay = $this->payment_m->get_unpaid_order($pay_item,$phone,$portal_setup['current_sem'],$portal_setup['current_ses']);

        // print_r($row);
        //  print_r($pay);
        // print_r($item);
        // die();
        $holdInfoArray = [
            "Name" => $row[0]['SurName']." ".$row[0]['FirstName']." ".$row[0]['OtherNames'],        
            "RegNo" => $phone,
            "PhoneNo" => $phone,
            "ProgID" => 0,
            "ProgName" => 'NULL',
            "DeptID" => 'NULL',
            "DeptName" => 'NULL',
            "FacID" => 'NULL',
            "FacName" =>'NULL',
            "StartSes" => $portal_setup['current_ses'],
            "ModeOfEntry" => $moe,
            "PayName" => $item[0]['ItemName']
        ];
        //calculate level
       $lvl = ($portal_setup['current_ses'] - $row[0]['StartSes']) + 1;
        // generate order

         //print_r($item[0]);
         $amt_to_pay = 0;
         if($item[0]['Transaction_charges']== "TRUE"){
 
             $Item_D = json_decode($item[0]['PayBrkDn']);
             $Amt = $Item_D->Amt;
             $TransactionCharge = $Item_D->TransactionCharge;
             $amt_to_pay = ($Amt + $TransactionCharge);
 
         }else{
             $Item_D = json_decode($item[0]['PayBrkDn']);
             $Amt = $Item_D->Amt;
             $amt_to_pay = $Amt;
         }
         //newexpred ref
         
         $new_expired_ref = '';
         // print_r($pay);
        if(empty($pay) || count($pay) == 0){
           
            //CREATE ORDER ARRAY
            
           $genTenNo =  random_string('nozero',10);
            $order_data = array(
                'ItemNo'=>random_string('nozero',22),
                'TransNum'=>$genTenNo,
                'ItemName'=>$item[0]['ItemName'],
                'ItemDescr'=>$item[0]['ItemDescr'],
                'Amt'=>$amt_to_pay,
                'RegNo'=>$phone,
                'Sem'=>$portal_setup['current_sem'],
                'Ses'=>$portal_setup['current_ses'],
                'Lvl'=>$lvl,
                'ItemID'=>$pay_item,
                'Paid'=>0,
                'RegDate'=>date('Y-m-d'),
                'Ses'=>$portal_setup['current_ses'],
                'BrkDwn'=>$item[0]['PayBrkDn'],
                'Info'=>json_encode($holdInfoArray)
                
            );
           $r =  $this->payment_m->create_order($order_data);
           if($r){
            die(json_encode(["SUCCESS" => ["Message" => $genTenNo,"Pay_Item" => $item[0]['ID'],"regLvl" => $row[0]['RegLevel'],"reportP" => [$genTenNo,number_format($amt_to_pay,2),"AKSU ".$item[0]['ItemName']." PAYMENT"]]]));
           }

        }else{
            
            // check if expired ref column is empty
            if($pay[0]['ExpiredRef'] == ''){
                //current ref is expired
                $new_expired_ref.= $pay[0]['TransNum'];
            }else{
                $expr_array = explode("~",$pay[0]['ExpiredRef']);
                $expr_array[] = $pay[0]['TransNum'];
                $new_expired_ref  = implode("~",$expr_array);
               
            }
             // create a new transnum
             $new_genTenNo =  random_string('nozero',10);

             $updated_order_data = array(
                 'ItemNo'=>random_string('nozero',22),
                 'TransNum'=>$new_genTenNo,
                 'ItemName'=>$item[0]['ItemName'],
                 'ItemDescr'=>$item[0]['ItemDescr'],
                 'Amt'=>$amt_to_pay,
                 'RegNo'=>$phone,
                 'Sem'=>$portal_setup['current_sem'],
                 'Ses'=>$portal_setup['current_ses'],
                 'Lvl'=>$lvl,
                 'ItemID'=>$pay_item,
                 'Paid'=>0,
                 'RegDate'=>date('Y-m-d'),
                 'Ses'=>$portal_setup['current_ses'],
                 'BrkDwn'=>$item[0]['PayBrkDn'],
                 'ExpiredRef'=>$new_expired_ref,
                 'Info'=>json_encode($holdInfoArray)
                 
             );
            //  print_r($updated_order_data);
             $p =  $this->payment_m->update_order($pay[0]['ID'], $updated_order_data);
             if($p){
              die(json_encode(["SUCCESS" => ["Message" => $new_genTenNo,"Pay_Item" => $item[0]['ID'],"RegLevel"=> $row[0]['RegLevel'],"reportP" => [$new_genTenNo,number_format($amt_to_pay,2),"AKSU ".$item[0]['ItemName']." PAYMENT"]]]));
             }

        }
    }

}
