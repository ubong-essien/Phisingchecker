<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {
    // public function __construct()
    // {
    //    // $this->load->model('portal_m');
    //     $portal_setup = $this->portal_m->get_portal_details();
    //     $this->sem = $portal_setup->current_sem;
    //     $this->ses = $portal_setup->current_ses;
    // }
    //check all payment and return the number that exist
    // private function get_portal_details(){
    //     $portal_setup = $this->portal_m->get_portal_details();
    //     $this->sem = $portal_setup['current_sem'];
    //     $this->ses = $portal_setup['current_ses'];
        
    // }
    private function next_page($pid){

        $pages = [
            ["ui/ajax/cep/pages/verification.php","REGISTER NOW"],
            ["ui/ajax/cep/pages/basicdetails.php","BASIC DETAILS"],
            ["ui/ajax/cep/pages/paymentoption.php","Make Payment"],
            ["ui/ajax/cep/pages/contactinfo.php","CONTACT INFORMATION"],
            ["ui/ajax/cep/pages/academicdetails.php","ACADEMIC DETAILS"],
            ["ui/ajax/cep/pages/finish.php","Registration Completed"]
    ];
    return $pages[$pid];
    }
    private function check_pay($payid,$regno){
        $this->load->model('portal_m');
        $portal_setup = $this->portal_m->get_portal_details();
        $pay = $this->register_m->check_payment($payid,$regno, $portal_setup['current_sem'], $portal_setup['current_ses']);
        if($pay > 0){
            return True;
        }else{
            return False;
        }
            return False;
    }

	public function Verify_candidate()
	{   
        $candidate_data=$this->input->post('data',TRUE);
        $cand = json_decode($candidate_data);
        $phone = $cand->cep__phone__; 
        $mode = $cand->cep__ModeOfEntry ;
        $moe = explode('_',$mode);
        $row = $this->register_m->get_user_details($phone,$moe[1]);
        // die;
        // pages navigation
        $pages = [
            ["ui/ajax/cep/pages/verification.php","REGISTER NOW"],
            ["ui/ajax/cep/pages/basicdetails.php","BASIC DETAILS"],
            ["ui/ajax/cep/pages/paymentoption.php","Make Payment"],
            ["ui/ajax/cep/pages/contactinfo.php","CONTACT INFORMATION"],
            ["ui/ajax/cep/pages/academicdetails.php","ACADEMIC DETAILS"],
            ["ui/ajax/cep/pages/finish.php","Registration Completed"]
        ];
        // echo count($row);die;
        
       
        
        if(count($row) > 0){
            
             if($row[0]['RegLevel'] == 4){
                 $next_pagess =$this->next_page(5);
                  $user = $this->register_m->get_user($row[0]['JambNo']);
                                //   echo "a here";die;
                                //   print_r($user);die;
                                   $name = $user[0]['SurName'].", ".$user[0]['FirstName']." ".$user[0]['OtherNames'];
                                   $moe = $user[0]['ModeOfEntry'];
                                   $ProgName = $user[0]['ProgName'];
                                   $Gender = $user[0]['Gender'];
                                   $Reglvl = $user[0]['RegLevel'];
                                   $passport = "api/uploads/passports/".$user[0]['Passport'];
                 die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"passport"=>$passport,"moe" => $moe,"Programme" => $ProgName,"Gender" => $Gender,"Name" => $name,"Reglvl" => $Reglvl]]));
                               
            }
            $item = $this->payment_m->get_Item_pay_details($moe[1]);//{"Amt":15000,"TransactionCharge":700}
            //print_r($item[0]);
            $amt_to_pay = 0;
            // var_dump($item[0]['Transaction_charges']);die;
            if($item[0]['Transaction_charges']== "TRUE"){
    
                $Item_D = json_decode($item[0]['PayBrkDn']);
                $Amt = $Item_D->Amt;
                $TransactionCharge = $Item_D->TransactionCharge;
                $amt_to_pay = ($Amt + $TransactionCharge);
    
            }else{
                $Item_D = json_decode($item[0]['PayBrkDn']);
                $Amt = $Item_D->Amt;
                $amt_to_pay = $Amt;
            }
            //if the candidate already exist,bring the entire  record of the candidate and check the reglevel to know where to send candidate to
            $NP = ($row[0]['RegLevel'] + 1);//NP here stands for next page
            $next_page = $pages[$NP];
            $cand_details = array(
                'JambNo'=>$row[0]['JambNo'],
                'RegLevel'=>$next_page,
                'SurName'=>$row[0]['SurName'],
                'OtherNames'=>$row[0]['OtherNames'],
                'FirstNames'=>$row[0]['FirstName'],
                'ModeOfEntry'=>$row[0]['ModeOfEntry'],
                'ID'=>$row[0]['id']
            );
            die(json_encode(["SUCCESS" => ["Message" => $next_page[0],"menuHeaderTitle" => $next_page[1],"amt" => number_format($amt_to_pay,2),"Reglvl" => $NP]]));

        }else{
           //the candidate does not exist and should be given a form to register preliminary information before payment.
           $next_page = $pages[1];
           die(json_encode(["SUCCESS" => ["Message" => $next_page[0],"menuHeaderTitle" => $next_page[1],"amt" => 0,"Reglvl" => 0]]));
        }
	
	}
   
    public function capture_candidate(){
        $candidate_data=$this->input->post('data',TRUE);
       
        $cand = json_decode($candidate_data);
        //  var_dump($cand);die;
        $phone = $cand->cep__phone__; 
        $Mode = $cand->cep__ModeOfEntry ;
        $Surname = $cand->cep__surnm; 
        $Fname = $cand->cep__firstnm ;
        $Oname = $cand->cep__othernm ;
        $gender = $cand->cep__gendr ;

        
        $portal_setup = $this->portal_m->get_portal_details();
        $moe = explode('_',$Mode);
        $user_data = array(
            'SurName' => $Surname,         
            'FirstName' => $Fname,         
            'OtherNames' => $Oname,        
            'JambNo' => $phone,
            'Phone' => $phone,
            'StartSes' => $portal_setup['current_ses'],
            'RegLevel' => 1,
            'admitted' => 0,
            'Gender' => $gender,
            'ModeOfEntry' => $moe[1]
        );
        $next_pagess =$this->next_page(2);
       $ins = $this->register_m->create_candidate($user_data);
       if($ins > 0 ){
        $item = $this->payment_m->get_Item_pay_details($moe[1]);//{"Amt":15000,"TransactionCharge":700}
        //print_r($item[0]);
        $amt_to_pay = 0;
        if($item[0]['Transaction_charges']== "TRUE"){

            $Item_D = json_decode($item[0]['PayBrkDn']);
            $Amt = $Item_D->Amt;
            $TransactionCharge = $Item_D->TransactionCharge;
            $amt_to_pay = ($Amt + $TransactionCharge);

        }else{
            $Item_D = json_decode($item[0]['PayBrkDn']);
            $Amt = $Item_D->Amt;
            $amt_to_pay = $Amt;
        }
        die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"amt" =>  number_format($amt_to_pay,2)]]));
       }else{
            die(json_encode(["ERROR" => ["Message" => 'Initial Registration NOT Successfull']]));
       }

    }
    public function process_contact_details(){
// die('ywyuiwf');
       $contact_data=$this->input->post('getAllFromAjax',TRUE);
      
        $contact = json_decode($contact_data);
      //  print_r($contact);die;
        $portal_setup = $this->portal_m->get_portal_details();

     
        // print_r($user_data);die;
        // $config = array(
        //     'upload_path' => "./students_files/",
        //     'allowed_types' => "gif|jpg|png|jpeg",
        //     'overwrite' => TRUE,
        //     'max_size' => "250", // Can be set to particular file size , here it is 2 MB(2048 Kb)
        //     'max_height' => "300",
        //     'max_width' => "250",
        //      $config['file_name'] = $contact->cepphoneno.".jpg";
        //     );
            
            
      $config['upload_path'] = './uploads/passports/';
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      $config['max_size']     = '170';
    //   $config['max_width'] = '300';
    //   $config['max_height'] = '250';
      $config['file_name'] = $contact->cep__jambNo__.".jpg";
      
         $user_data = array(
            'DOB' => $contact->cep__dob,         
            'Nationality' => $contact->cep__nationality,         
            'Addrs' => $contact->cep__homeaddress,  
            'RegLevel' => 3,
            'MaritalStatus' => $contact->cep__maritsts__page3,
            'SponsorName' => $contact->cep__sponsorName,
            'SponsorAddrs' => $contact->cep__sponsorAddress,
            'SponsorPhone' => $contact->cep__sponsorphonumber,
            'Email ' => $contact->cep__email,
            'LGA' => $contact->cep__lga,
            'StateId' => $contact->cep__statID,
            'Passport' => $config['file_name'],
            'SpouseName' => $contact->cep__spouseName
            
            
        );   
       $this->load->library('upload', $config);
       
       if($this->upload->do_upload('file1')){
           
           $next_pagess =$this->next_page(4);
           $ins_upt = $this->register_m->update_contact_info($contact->cep__jambNo__,$user_data);
           if($ins_upt){
                  die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1]]]));
           }else{
                die(json_encode(["ERROR" => ["Message" => 'Contact Info was not saved']]));
           }
      }else{
           die(json_encode(["ERROR" => ["Message" => $this->upload->display_errors().' File upload failed and data not saved.']]));
      }

    }
    public function process_acad_details(){
        //print_r($_POST);

       $firstobj = $this->input->post('firstSitObj',TRUE);
      
      $secondobj = $this->input->post('SecondSitObj',TRUE);
      $jambno = $this->input->post('cep__jambNo__',TRUE);
      
      $cep__examType1 = $this->input->post('cep__examType1',TRUE);
      $cep__examsYear1 = $this->input->post('cep__examsYear1',TRUE);
      $cep__examsNumber1 = $this->input->post('cep__examsNumber',TRUE);
      $cep__exams_center1 = 'SCHOOL EXAMS';
     
      
      $cep__proposed__prog = $this->input->post('cep__proposed__prog',TRUE);
      $cep__examType2 = $this->input->post('cep__examType2',TRUE);
      $cep__examsYear2 = $this->input->post('cep__examsYear2',TRUE);
      $cep__examsNumber2 = $this->input->post('cep__examsNumber2',TRUE);
      $cep__exams_center2 = 'SCHOOL EXAMS';
      
      

      
           $config1['upload_path'] = './uploads/other_documents/';
           $config1['allowed_types'] = 'gif|jpg|png|jpeg';
           $config1['max_size']     = '200';
           $config1['file_name'] = $jambno.".jpg";
           
           /****************************************************/
            $config2['upload_path'] = './uploads/other_documents/';
            $config2['allowed_types'] = 'gif|jpg|png|jpeg';
            $config2['max_size']     = '200';
            $config2['file_name'] = $jambno."_1".".jpg";
      
  
      
     $first_string = '';
     $first_scr_string = '';
      $second_string = '';
     $second_scr_string = '';
     
      if(isset($secondobj) && !empty($secondobj)){
          
          
            
                      $first =  json_decode($firstobj);
                      // process first and second and first semester
                   //print_r($first);die;
                    foreach($first as $first_sitting_value){
                       //print_r($first_sitting_value);
                      // $first_sitting_val=  json_decode($first_sitting_value);
                      //string for biodata
                        $first_string .= $first_sitting_value[3]."=".$first_sitting_value[2].";";
                        //echo $first_string;
                      //string for srenning
                      $course = explode('_',$first_sitting_value[0]);
                      $grade = explode('_',$first_sitting_value[1]);
                       $first_scr_string .= $course[1]."=".$grade[1].";";
                    }
                //   echo $first_scr_string ;die;
                    /***************************second semester*************************/
                    $second =  json_decode($secondobj);
                      // process first and second and first semester
                   //print_r($second);die;
                    foreach($second as $key => $second_sitting_value){
                       
                      //string for biodata
                        $second_string .= $second_sitting_value[3]."=".$second_sitting_value[2].";";
                      //string for srenning
                      $course_2 = explode('_',$second_sitting_value[0]);
                      $grade_2 = explode('_',$second_sitting_value[1]);
                       $second_scr_string .= $course_2[1]."=".$grade_2[1].";";
                    }
                    
                    //add the full string
                    $full_string = $first_string."###".$second_string;
                    $full_scr_string = $first_scr_string."###".$second_scr_string;
                    //echo $full_string."</br>";
                   
                   //exams details SCHOOL EXAM`~2021`~2110035384GH`~3`~1
                   //first sitting exams details
                   
                   $first_exams_details = $cep__exams_center1."`~".$cep__examsYear1."`~".$cep__examsNumber1."`~".$cep__examType1;
                   //second sitting exams details
                   $second_exams_details = $cep__exams_center2."`~".$cep__examsYear2."`~".$cep__examsNumber2."`~".$cep__examType2;
                   
                   $full_exams_details_string = $first_exams_details."###".$second_exams_details;
                   
                   
                   
                   
                   
                //UPLOAD PHYSICAL COPY OF THE DOCUMENT 
                $file_upload1 = 0;
                $file_upload2 = 0;
                
                  $this->load->library('upload', $config1);
                   if($this->upload->do_upload('file1')){
                       $file_upload1 = 1;
                       // load libray for second upload
                       $this->load->library('upload', $config2);
                        if($this->upload->do_upload('file2')){
                             $file_upload2 = 1; 
                             
                             if(($file_upload1 == 1) && ($file_upload2 == 1)){
                                 //UPDATE THE DATABASE
                                 $acad_data = array(
                                    'OlevelRstDetails' => $full_exams_details_string,         
                                    'OlevelRst' => $full_string,         
                                    'OlevelRst2' => $full_scr_string,  
                                    'RegDate' => date('Y-m-d'), 
                                    'RegLevel' => 4,
                                    'ProgID' => $cep__proposed__prog
                                    
                                );
                            //     echo $jambno;die;
                            //   print_r($acad_data);die;
                               
                                $next_pagess =$this->next_page(5);
                               if($this->register_m->update_info($jambno, $acad_data)){
                                   $user = $this->register_m->get_user($jambno);
                                //   echo "a here";die;
                                //   print_r($user);die;
                                   $name = $user[0]['SurName'].", ".$user[0]['FirstName']." ".$user[0]['OtherNames'];
                                   $moe = $user[0]['ModeOfEntry'];
                                   $ProgName = $user[0]['ProgName'];
                                   $Gender = $user[0]['Gender'];
                                   $Reglvl = $user[0]['RegLevel'];
                                   $passport = "api/uploads/passports/".$user[0]['Passport'];
                                   
                                    die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"passport"=> $passport,"moe" => $moe,"Programme" => $ProgName,"Gender" => $Gender,"Name" => $name,"Reglvl" => $Reglvl]]));
                               } 
                                 
                             }else{
                                 die(json_encode(["ERROR" => ["Message" => $this->upload->display_errors().'Both File upload failed and data not saved.']]));
                             }
                            
                        }else{
                          die(json_encode(["ERROR" => ["Message" => $this->upload->display_errors().' Second sitting File upload failed and data not saved.']]));  
                        }
                       
                   }else{
                      die(json_encode(["ERROR" => ["Message" => $this->upload->display_errors().' First sitting File upload failed and data not saved.']])); 
                   }
                  
                  
                
      }else{
                //first sitting exams details
                $first_exams_details = $cep__exams_center1."`~".$cep__examsYear1."`~".$cep__examsNumber1."`~".$cep__examType1;

                 $one_sitting_upload = 0;
                  $first =  json_decode($firstobj);
                  // process first sittings
               
                foreach($first as $first_sitting_key => $first_sitting_value){
                   // print_r($first_sitting_value) ;
                  // $first_sitting_val=  json_decode($first_sitting_value);
                  //string for biodata
                    $first_string .= $first_sitting_value[3]."=".$first_sitting_value[2].";";
                  //string for srenning
                  $course = explode('_',$first_sitting_value[0]);
                  $grade = explode('_',$first_sitting_value[1]);
                   $first_scr_string .= $course[1]."=".$grade[1].";";
                }
                $full_string = $first_string;
                 $full_scr_string = $first_scr_string;
               
    
        $this->load->library('upload', $config1);
        if($this->upload->do_upload('file1')){
            $one_sitting_upload = 1; 
            
            if(($one_sitting_upload == 1)){
                //UPDATE THE DATABASE
                $acad_data = array(
                    'OlevelRstDetails' => $first_exams_details,         
                    'OlevelRst' => $full_string,         
                    'OlevelRst2' => $full_scr_string,  
                    'RegDate' => date('Y-m-d'), 
                    'RegLevel' => 4,
                    'ProgID' => $cep__proposed__prog
                    
                );
            //     echo $jambno;die;
            //   print_r($acad_data);die;
                
                $next_pagess =$this->next_page(5);
                if($this->register_m->update_info($jambno, $acad_data)){
                    $user = $this->register_m->get_user($jambno);
                //   echo "a here";die;
                //   print_r($user);die;
                    $name = $user[0]['SurName'].", ".$user[0]['FirstName']." ".$user[0]['OtherNames'];
                    $moe = $user[0]['ModeOfEntry'];
                    $ProgName = $user[0]['ProgName'];
                    $Gender = $user[0]['Gender'];
                    $Reglvl = $user[0]['RegLevel'];
                    $passport = "api/uploads/passports/".$user[0]['Passport'];
                    
                    die(json_encode(["SUCCESS" => ["Message" => $next_pagess[0],"menuHeaderTitle" => $next_pagess[1],"passport"=> $passport,"moe" => $moe,"Programme" => $ProgName,"Gender" => $Gender,"Name" => $name,"Reglvl" => $Reglvl]]));
                } 
                
                }else{
                    die(json_encode(["ERROR" => ["Message" => $this->upload->display_errors().'Both File upload failed and data not saved.']]));
                }
            
            }else{
                die(json_encode(["ERROR" => ["Message" => $this->upload->display_errors().' Second sitting File upload failed and data not saved.']]));  
            }
        }

    }
    public function process_payment(){
        //die("gdgdgdgdg");
        $candidate_data=$this->input->post('data',TRUE);
        // print_r($candidate_data);die;
        $cand = json_decode($candidate_data);
        $phone = $cand->cep__phone__; 
        $mode = $cand->cep__ModeOfEntry ;
        $moe = explode('_',$mode);
        
        $portal_setup = $this->portal_m->get_portal_details();
        $row = $this->register_m->get_user_details($phone,$moe[1]);
        //print_r($row);die;
        $item = $this->payment_m->get_Item_pay_details($moe[1]);//{"Amt":15000,"TransactionCharge":700}

        
        $pay = $this->payment_m->get_pay($moe[1],$phone,$portal_setup['current_sem'],$portal_setup['current_ses']);
        
        $holdInfoArray = [
            "Name" => $row[0]['SurName']." ".$row[0]['FirstName']." ".$row[0]['OtherNames'],        
            "RegNo" => $phone,
            "PhoneNo" => $phone,
            "ProgID" => 0,
            "ProgName" => 'NULL',
            "DeptID" => 'NULL',
            "DeptName" => 'NULL',
            "FacID" => 'NULL',
            "FacName" =>'NULL',
            "StartSes" => $portal_setup['current_ses'],
            "ModeOfEntry" => $moe[1],
            "PayName" => $item[0]['ItemName']
        ];
        //calculate level
       $lvl = ($portal_setup['current_ses'] - $row[0]['StartSes']) + 1;
        // generate order

       

        
         //print_r($item[0]);
         $amt_to_pay = 0;
         if($item[0]['Transaction_charges']== "TRUE"){
 
             $Item_D = json_decode($item[0]['PayBrkDn']);
             $Amt = $Item_D->Amt;
             $TransactionCharge = $Item_D->TransactionCharge;
             $amt_to_pay = ($Amt + $TransactionCharge);
 
         }else{
             $Item_D = json_decode($item[0]['PayBrkDn']);
             $Amt = $Item_D->Amt;
             $amt_to_pay = $Amt;
         }
         //newexpred ref
         
         $new_expired_ref = '';
        if(empty($pay) || count($pay) == 0){
            
            //CREATE ORDER ARRAY
            
           $genTenNo =  random_string('nozero',10);
            $order_data = array(
                'ItemNo'=>random_string('nozero',22),
                'TransNum'=>$genTenNo,
                'ItemName'=>$item[0]['ItemName'],
                'ItemDescr'=>$item[0]['ItemDescr'],
                'Amt'=>$amt_to_pay,
                'RegNo'=>$phone,
                'Sem'=>$portal_setup['current_sem'],
                'Ses'=>$portal_setup['current_ses'],
                'Lvl'=>$lvl,
                'ItemID'=>$moe[1],
                'Paid'=>0,
                'RegDate'=>date('Y-m-d'),
                'Ses'=>$portal_setup['current_ses'],
                'BrkDwn'=>$item[0]['PayBrkDn'],
                'Info'=>json_encode($holdInfoArray)
                
            );
           $r =  $this->payment_m->create_order($order_data);
           if($r){
            die(json_encode(["SUCCESS" => ["Message" => $genTenNo,"regLvl" => $row[0]['RegLevel'],"reportP" => [$genTenNo,number_format($amt_to_pay,2),"AKSU ".$item[0]['ItemName']." PAYMENT"]]]));
           }

        }else{
           // print_r($pay);
            // check if expired ref column is empty
            if($pay[0]['ExpiredRef'] == ''){
                //current ref is expired
                $new_expired_ref.= $pay[0]['TransNum'];
            }else{
                $expr_array = explode("~",$pay[0]['ExpiredRef']);
                $expr_array[] = $pay[0]['TransNum'];
                $new_expired_ref  = implode("~",$expr_array);
               
            }
             // create a new transnum
             $new_genTenNo =  random_string('nozero',10);

             $updated_order_data = array(
                 'ItemNo'=>random_string('nozero',22),
                 'TransNum'=>$new_genTenNo,
                 'ItemName'=>$item[0]['ItemName'],
                 'ItemDescr'=>$item[0]['ItemDescr'],
                 'Amt'=>$amt_to_pay,
                 'RegNo'=>$phone,
                 'Sem'=>$portal_setup['current_sem'],
                 'Ses'=>$portal_setup['current_ses'],
                 'Lvl'=>$lvl,
                 'ItemID'=>$moe[1],
                 'Paid'=>0,
                 'RegDate'=>date('Y-m-d'),
                 'Ses'=>$portal_setup['current_ses'],
                 'BrkDwn'=>$item[0]['PayBrkDn'],
                 'ExpiredRef'=>$new_expired_ref,
                 'Info'=>json_encode($holdInfoArray)
                 
             );
            // print_r($updated_order_data);
             $p =  $this->payment_m->update_order($pay[0]['ID'], $updated_order_data);
             if($p){
              die(json_encode(["SUCCESS" => ["Message" => $new_genTenNo,"reportP" => [$new_genTenNo,number_format($amt_to_pay,2),"AKSU ".$item[0]['ItemName']." PAYMENT"]]]));
             }

        }
    }

}
