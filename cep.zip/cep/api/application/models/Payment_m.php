<?php


class Payment_m extends CI_model{
// get the item amount to pay

    public function get_Item_pay_details($id){
        // print_r($login_details);
         $sql = "SELECT * FROM item_tb WHERE ID ='$id'";
        //echo $sql;
         $cont_query = $this->db->query($sql);
          //print_r($cont_query->row_array());
          return $cont_query->result_array();	
     }

     public function get_thirdpartysyn($id){
         $sql = "SELECT * FROM thirdpartysyn_tb WHERE ItemID ='$id'";
         $cont_query = $this->db->query($sql);
          return $cont_query->result_array();	
     }

        public function update_order($id, $insert_data) {
            $this->db->where('id', $id);
            return $this->db->update('order_tb', $insert_data);
            }

    public function create_order($data){
        if(is_array($data)){
            return  $this->db->insert('order_tb', $data);	
        }
    } 
public function check_stud_payment($regno,$transnum,$payid){
    $sql = "SELECT * FROM payhistory_tb WHERE RegNo ='$regno' AND TransID='$transnum' AND PayID = '$payid'";
    $cont_query = $this->db->query($sql);
    return $cont_query->result_array();
}
public function check_a_payment($payid,$regno){
    $sql = "SELECT * FROM payhistory_tb WHERE RegNo ='$regno' AND PayID = '$payid'";
    $cont_query = $this->db->query($sql);
    return $cont_query->result_array();
}
    public function get_pay($payid,$regno,$sem,$ses){
        $sql = "SELECT o.TransNum,o.Paid,o.Ses,o.RegNo,o.Amt,o.ItemName,o.Sem,o.ItemID,p.TransID,p.PayID,p.Bank,p.PayDate FROM payhistory_tb p ,order_tb o WHERE o.TransNum = p.TransID AND p.RegNo = '$regno' AND p.PayID = '$payid' AND  o.Ses = p.Ses  AND p.Ses = '$ses' AND p.Sem = '$sem'";
        $cont_query = $this->db->query($sql);
        return $cont_query->result_array();	
    }
    public function check_schfee_pay($payid,$regno,$sem,$ses){
        $sql = "SELECT o.TransNum,o.Paid,o.Ses,o.RegNo,o.Amt,o.ItemName,o.Sem,o.ItemID,p.TransID,p.PayID,p.Bank,p.PayDate FROM payhistory_tb p ,order_tb o WHERE o.TransNum = p.TransID AND p.RegNo = '$regno' AND p.PayID = '$payid' AND  o.Ses = p.Ses AND o.Sem = p.Sem  AND p.Ses = '$ses' AND (p.Sem = '$sem' OR p.Sem = '3')";
        // echo $sql;
        $cont_query = $this->db->query($sql);
        return $cont_query->result_array();	
    }

    public function get_unpaid_order($payid,$regno,$sem,$ses){
        // $sql = "SELECT TransNum,Paid,Ses,RegNo,Amt,ItemName,Sem,ItemID FROM order_tb WHERE Paid = 0 AND RegNo = '$regno' AND ItemID = '$payid'   AND Ses = '$ses' AND Sem = '$sem'";
        $sql = "SELECT * FROM order_tb WHERE Paid = 0 AND RegNo = '$regno' AND ItemID = '$payid'   AND Ses = '$ses' AND Sem = '$sem'";
        // echo $sql;
        $cont_query = $this->db->query($sql);
        return $cont_query->result_array();	
    }
    // public function check_order(){
    //     $sql = "SELECT order_tb,ID,ExpiredRef,TransNum FROM order_tb";
    // }

    public function check_payment($payid,$regno,$sem,$ses){
        if($sem = 1){
            $sql = "SELECT * FROM payhistory_tb WHERE RegNo = '$regno' AND PayID = '$payid' AND Ses = '$ses' AND Sem IN('1','3')";
        }else{
            $sql = "SELECT * FROM payhistory_tb WHERE RegNo = '$regno' AND PayID = '$payid' AND Ses = '$ses' AND Sem IN('2','3')";
        }
        //echo $sql;
        $cont_query = $this->db->query($sql);
        return $cont_query->num_rows();	
    }

  
    public function create_login($data){
        if(is_array($data)){
                return $this->db->insert('login_tb', $data);	
        }
    } 
    public function get_payment_history($regno){
        $sql = "SELECT p.Lvl,o.TransNum,o.Paid,o.Ses,o.RegNo,o.Amt,o.ItemName,o.Sem,o.ItemID,p.TransID,p.PayID,p.Bank,p.PayDate,ses.SesName FROM payhistory_tb p ,order_tb o,session_tb ses WHERE o.TransNum = p.TransID AND p.RegNo = '$regno' AND p.Ses = ses.SesID ORDER BY p.Lvl";
        $cont_query = $this->db->query($sql);
        return $cont_query->result_array();	
    }
    
    public function  validate_local_checksum($TransNum,$ID){
        $sql = "SELECT * FROM order_tb  WHERE TransNum ='$TransNum' and ID = '$ID' LIMIT 0,1";
        //echo $sql;
           $cont_query = $this->db->query($sql);
           return $cont_query->row_array();

            
    }

    public function  check_verify($user,$code){
        $sql = "SELECT * FROM login_tb  WHERE username='$user' and email_verification = '$code' and has_verified = 0  LIMIT 0,1";
        //echo $sql;
           $cont_query = $this->db->query($sql);
           return $cont_query->row_array();

            
    } 
    
    public function update_login($id, $insert_data) {
        $this->db->where('user_id', $id);
       return $this->db->update('login_tb', $insert_data);
      }	
    public function update_order_by_transnum($transnum, $insert_data) {
    $this->db->where('TransNum', $transnum);
    return $this->db->update('order_tb', $insert_data);
    }	

    public function insert_payment($insert_data) {
        return $this->db->insert('payhistory_tb', $insert_data);
        }
        
    public function update_user($transnum, $insert_data) {
        $this->db->where('id', $id);
        return $this->db->update('users_tb', $insert_data);
    }
    public function  decode_cloth($id){
        $sql = "SELECT cloth_type FROM cloth_amt_tb  WHERE id = $id  LIMIT 0,1";
           $cont_query = $this->db->query($sql);
           $arr =  $cont_query->row_array();
           return $arr['cloth_type'];
    } 
    // public function 
}
?>