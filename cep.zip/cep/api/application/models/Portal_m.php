<?php


class Portal_m extends CI_model{

    public function get_portal_details(){
         $sql = "SELECT * FROM portal_control_tb";
         $cont_query = $this->db->query($sql);
          return $cont_query->row_array();	
      
        }

}
?>