<?php


class Course_m extends CI_model{

    public function get_user_details($phone,$mode){
        // print_r($login_details);
         $sql = "SELECT * FROM pstudentinfo_tb WHERE Phone ='$phone' AND JambNo = '$phone' AND ModeOfEntry='$mode' ";
        //echo $sql;
         $cont_query = $this->db->query($sql);
          //print_r($cont_query->row_array());
          return $cont_query->row_array();	
      
        }
        public function  check_history_coursereg($jamb){
            $sql = "SELECT c.*,s.SesName  FROM coursereg_tb c,session_tb s  WHERE RegNo='$jamb' AND c.SesID = s.SesID  ORDER BY Lvl";
            //echo $sql;
               $cont_query = $this->db->query($sql);
               return $cont_query->result_array();
    
                
        }
    public function create_user($data){
            if(is_array($data)){
                $this->db->insert('users_tb', $data);	
                return $this->db->insert_id();	

            }
        } 
    public function create_login($data){
        if(is_array($data)){
                return $this->db->insert('login_tb', $data);	
        }
    } 

    public function create_order($data){
        if(is_array($data)){
                return $this->db->insert('order_tb', $data);	
        }
    } 
    public function  check_previous_coursereg($jamb,$sem){
        $sql = "SELECT * FROM coursereg_tb  WHERE RegNo='$jamb' and Sem = '$sem' LIMIT 0,1";
        //echo $sql;
           $cont_query = $this->db->query($sql);
           return $cont_query->result_array();

            
    } 

    public function register_course($data){
        if(is_array($data)){
                $this->db->insert('coursereg_tb', $data);	
                return $this->db->insert_id();		
        }
    }
    public function  load_courses($lvl,$progid,$sem,$ses){
        $sql = "SELECT * FROM course_tb  WHERE Lvl <= '$lvl' and Sem = '$sem' and DeptID = '$progid' ";
        //echo $sql;
           $cont_query = $this->db->query($sql);
           return $cont_query->result_array();

            
    } 
    public function update_login($id, $insert_data) {
        $this->db->where('user_id', $id);
       return $this->db->update('login_tb', $insert_data);
      }	
    public function update_user($id, $insert_data) {
    $this->db->where('id', $id);
    return $this->db->update('users_tb', $insert_data);
    }
    public function  decode_cloth($id){
        $sql = "SELECT cloth_type FROM cloth_amt_tb  WHERE id = $id  LIMIT 0,1";
           $cont_query = $this->db->query($sql);
           $arr =  $cont_query->row_array();
           return $arr['cloth_type'];
    } 
}
?>