<?php


class Admission_m extends CI_model{

    public function get_adm_user_details($phone){
        // print_r($login_details);
         $sql = "SELECT * FROM pstudentinfo_tb WHERE JambNo = '$phone' AND admitted = 1 ";
         $cont_query = $this->db->query($sql);
          //print_r($cont_query->row_array());
          return $cont_query->result_array();	
      
        }
        public function get_adm_student_details($Jamb){
            $sql = "SELECT p.FirstName,p.SurName,p.OtherNames,p.RegLevel,p.Gender,p.ProgID,p.ModeOfEntry,p.Passport,pr.ProgName,p.JambNo,p.StartSes,p.Email,p.Addrs,p.RegDate,p.JambAgg,p.OlevelRstDetails,p.OlevelRst,p.RegLevel,p.StateId,p.RegNo,p.DOB,p.Phone,p.LGA FROM studentinfo_tb p, programme_tb pr WHERE p.JambNo = '$Jamb' AND p.ProgID = pr.ProgID";
            $cont_query = $this->db->query($sql);
             //print_r($cont_query->row_array());
             return $cont_query->result_array();	
          
            }

         public function get_adm_user($Jamb){
        // print_r($login_details);
         $sql = "SELECT p.FirstName,p.SurName,p.OtherNames,p.RegLevel,p.Gender,p.ProgID,p.ModeOfEntry,p.Passport,pr.ProgName,p.JambNo,p.StartSes,p.Email,p.Addrs,p.RegDate,p.JambAgg,p.OlevelRstDetails,p.OlevelRst,p.RegLevel,p.StateId,p.RegNo,p.DOB,p.Phone,p.LGA FROM pstudentinfo_tb p, programme_tb pr WHERE p.JambNo = '$Jamb' AND p.ProgID = pr.ProgID AND admitted=1";
         $cont_query = $this->db->query($sql);
          //print_r($cont_query->row_array());
          return $cont_query->result_array();	
      
        }

        public function update_contact_info($id, $insert_data) {
            $this->db->where('JambNo', $id);
            return $this->db->update('pstudentinfo_tb', $insert_data);
            }
     public function update_info($id, $insert_data) {
                $this->db->where('JambNo', $id);
                return $this->db->update('pstudentinfo_tb', $insert_data);
                }
        public function get_pay($payid,$regno,$sem,$ses){
            $sql = "SELECT o.TransNum,o.Paid,o.Ses,o.RegNo,o,Amt,o.ItemName,o.Sem,o.ItemID,p.TransID,p.PayID,p.Bank,p.PayDate FROM payhistory_tb p ,order_tb o WHERE o.TransNum = p.TransID AND p.RegNo = '$regno' AND p.PayID = '$payid' AND  o.Ses = p.Ses AND p.Lvl = o.Lvl AND p.Ses = '$ses' ND p.Sem = '$sem'";
            $cont_query = $this->db->query($sql);
            return $cont_query->result_array();	
        }

        public function check_payment($payid,$regno,$sem,$ses){
            if($sem = 1){
                $sql = "SELECT * FROM payhistory_tb WHERE RegNo = '$regno' AND PayID = '$payid' AND Ses = '$ses' AND Sem IN('1','3')";
            }else{
                $sql = "SELECT * FROM payhistory_tb WHERE RegNo = '$regno' AND PayID = '$payid' AND Ses = '$ses' AND Sem IN('2','3')";
            }
            //echo $sql;
            $cont_query = $this->db->query($sql);
            return $cont_query->num_rows();	
        }

    public function create_candidate($data){
            if(is_array($data)){
                $this->db->insert('pstudentinfo_tb', $data);	
                return $this->db->insert_id();	

            }
        }
    public function create_new_student($data){
        if(is_array($data)){
            $this->db->insert('studentinfo_tb', $data);	
            return $this->db->insert_id();	

        }
    }
        
    public function remove_candidate($id){
        $this->db->where('id', $id);
        return $this->db->delete('pstudentinfo_tb');
        }	

    public function create_access($data){
    if(is_array($data)){
            return $this->db->insert('accesscode_tb', $data);	
    }
} 

    public function create_login($data){
        if(is_array($data)){
                return $this->db->insert('login_tb', $data);	
        }
    } 

    public function create_order($data){
        if(is_array($data)){
                return $this->db->insert('order_tb', $data);	
        }
    } 
    public function  check_verify($user,$code){
        $sql = "SELECT * FROM login_tb  WHERE username='$user' and email_verification = '$code' and has_verified = 0  LIMIT 0,1";
        //echo $sql;
           $cont_query = $this->db->query($sql);
           return $cont_query->row_array();

            
    } 
    
    public function update_login($id, $insert_data) {
        $this->db->where('user_id', $id);
       return $this->db->update('login_tb', $insert_data);
      }	
    public function update_user($id, $insert_data) {
    $this->db->where('id', $id);
    return $this->db->update('users_tb', $insert_data);
    }
    public function  decode_cloth($id){
        $sql = "SELECT cloth_type FROM cloth_amt_tb  WHERE id = $id  LIMIT 0,1";
           $cont_query = $this->db->query($sql);
           $arr =  $cont_query->row_array();
           return $arr['cloth_type'];
    } 
}


?>