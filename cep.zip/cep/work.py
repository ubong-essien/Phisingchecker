<!DOCTYPE html>
<html>
<head>
	<title>URL Legitimacy Checker</title>
</head>
<body>
	<h1>URL Legitimacy Checker</h1>
	<form action="/predict" method="POST">
		<label for="url">Enter URL:</label><br>
		<input type="text" id="url" name="url"><br><br>
		<input type="submit" value="Check">
	</form>
	{% if prediction %}
		<p>Prediction: {{ prediction }}</p>
	{% endif %}
</body>
</html>


from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import OneHotEncoder
import joblib
import re

app = Flask(__name__)

# Load the trained model
model_path = "models/random_forest_model.joblib"
clf = joblib.load(model_path)

# Load the encoder object
encoder_path = "models/encoder.joblib"
encoder = joblib.load(encoder_path)

@app.route("/")
def index():
	return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
	# Get the URL from the form
	url = request.form["url"]
	
	# Extract features from the URL
	features = extract_features(url)
	
	# Convert the features to a dataframe
	df = pd.DataFrame([features])
	
	# Encode categorical variables using the pre-trained encoder object
	encoded_features = encoder.transform(df)
	
	# Make a prediction using the pre-trained model
	prediction = clf.predict(encoded_features)[0]
	
	# Display the prediction on the results page
	return render_template("index.html", prediction=prediction)

def extract_features(url):
	"""
	Extract features from a URL.
	"""
	# Create a dictionary to hold the features
	features = {}
	
	# Check if the URL starts with "https"
	features["https"] = int(url.startswith("https"))
	
	# Check if the URL contains an IP address
	features["ip_address"] = int(bool(re.match(r"\d+\.\d+\.\d+\.\d+", url)))
	
	# Check if the URL contains a "@" symbol
	features["at_symbol"] = int("@" in url)
	
	# Check if the URL contains "https" or "http" in the domain name
	domain = re.findall(r"://([^/]+)/?", url)[0]
	features["https_in_domain"] = int("https" in domain or "http" in domain)
	
	# Return the features as a dictionary
	return features

if __name__ == "__main__":
	app.run(debug=True)





