<?php
require_once "../../engine/Robot.php";
require_once "../errormsg.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Payment</title>
    <link href="../../assets/css/main.css" rel="stylesheet" type="text/css" />
    <link href="../../../LIB/FA5/css/all.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div style="text-align: center;font-size:30px;font-weight:200!important;color:#e41e3f;margin-top:10px;">Connecting To Payment Platform</div>
    <div style="text-align: center;font-size:31px;font-weight:bold!important;color:#e41e3f;">Please Wait... </div>
    <div style="text-align: center;font-size:20px;font-weight:200!important;color:#e41e3f;"><i class="fas fa-cog fa-spin"></i></div>
<?php
// select ref no details
$rstSelctRef = $_->Select("order_tb","*","TransNum = ".trim($_->SqlSafe($_GET['r']))."");
if($rstSelctRef[1] > 0){
    $row = $rstSelctRef[0]->fetch_assoc();
    $breakDwn = explode('~',$row['BrkDwn']);
    $OtherInfo = json_decode($row['Info']);
    // get post url
    $rstPostUrl = $_->Select("thirdparty_tb","*","ID = 2");
    $posturl = '';
    if($rstPostUrl[1] > 0){
        $rowPostUrl = $rstPostUrl[0]->fetch_assoc();
        $posturl = trim($rowPostUrl['PARAM']);
    }else{die($errorCode['R15']);}
    // $posturl = 'https://www.etranzactng.net/webconnect/v3/caller.jsp';//LIVE
    $transId = trim($_GET['r']);
    // query paymnt details   
    $rstTerminalID = $_->Select("thirdpartysyn_tb","*","ItemID = ".$row['ItemID']."");
    $terminalId = '';
    // $terminalId = '7007139840';
    $sk = '';
    // $sk = 'fxPP2Yf3XuhnrCGa';
    if($rstTerminalID[1] > 0){
        $rowRstTerminalID = $rstTerminalID[0]->fetch_assoc();
        $terminalId = trim($rowRstTerminalID['TerminalID']);
        $sk = trim($rowRstTerminalID['SecurityKey']);
    }else{die($errorCode['R16']);}
    $AmtToPay = $row['Amt'];
    
    // $email = $OtherInfo->Email;
    $studentName = $OtherInfo->Name;
    $logo = 'http://localhost/cep/assets/images/FB_1.jpeg';
    // $logo = 'https://aksu.edu.ng/cep/assets/images/FB_1.jpeg';
    $phnoNo = $OtherInfo->PhoneNo;
    // AMOUNT+TEMINAL_ID+TRANSACTION_ID+RESPONSE_URL+SECRETKEY  
    // $responseurl = 'https://aksu.edu.ng/cep/script/payment/responseurl.php';
    $responseurl = 'http://localhost/cep/script/payment/responseurl.php';
    // new checksum
    $key = 'Antman123456789@#__..__..__..'.date('Y');
    $iv = '2348022269656080';
    $newChecksum = $row['ID'].':'.$transId;
    // $newChecksum = $encrypted_number = openssl_encrypt($newChecksum, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    // $newChecksum = str_replace(";", "", $newChecksum);
    $descr = $row['ItemDescr'].';'.$newChecksum;
    $cheksum = md5($AmtToPay.$terminalId.$transId.$responseurl.$sk);
    $form =  "<form method='POST' action='".$posturl."'>
                <input type='hidden' name='TERMINAL_ID' value='".$terminalId."'>
                <input type='hidden' name = 'TRANSACTION_ID' value='".$transId."'>
                <input type='hidden' name = 'AMOUNT' value='".$AmtToPay."'>
                <input type='hidden' name = 'DESCRIPTION' value='".$descr."'>
                <input type='hidden' name = 'CURRENCY_CODE' value='NGN'>
                <input type='hidden' name = 'RESPONSE_URL' value='".$responseurl."'>
                <input type='hidden' name = 'CHECKSUM' value='".$cheksum."'> 
                <input type='hidden' name = 'FULL_NAME' value=\"".$studentName."\">
                <input type='hidden' name = 'LOGO_URL' value='".$logo."'>
                <input type='hidden' name = 'PHONENO' value='".$phnoNo."'>
                </form>
                <script language='javascript'>
                var form = document.forms[0];
                form.submit();
                </script>";
     echo $form;           
}else{
    die($errorCode['|@@']);
}

// // Set the plain text to be encrypted
// $number = 12345;

// // Set the encryption key and initialization vector
// $key = 'MyEncryptionKey';
// $iv = '1234567890123456';

// // Encrypt the number using AES encryption algorithm
// $encrypted_number = openssl_encrypt($number, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);

// // Decrypt the encrypted number
// $decrypted_number = openssl_decrypt($encrypted_number, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);

// // Output the decrypted number
// echo $decrypted_number; // Output: 12345

?>
</body>
</html>
