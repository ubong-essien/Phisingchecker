// const staticDevCo = "AKSUeSenate-v1";
// const assets = [
//     "index.php",
//     "assets/css/main.css",
//     "../LIB/Engine/css/core.css",
//     "../LIB/FA5/css/all.min.css",
//     "../LIB/w3c.CSS",
//     "assets/js/main.js",
//     "../LIB/Engine/js/core.js",
//     "assets/images/icons/android-icon-192x192.png"
// ];
// //cache the assets
// self.addEventListener("install",installEvent=>{
//     installEvent.waitUntil(
//         caches.open(staticDevCo).then(caches=>{
//            return caches.addAll(assets);
//         })
//     );
// });
// //fetch the assets
// self.addEventListener("fetch",fetchEvent=>{
//     fetchEvent.respondWith(
//         caches.match(fetchEvent.request).then(
//             res=>{
//                 return res || fetch(fetchEvent.request);
//             }
//         )
//     );
// });