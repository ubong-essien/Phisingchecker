<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AKSU-Records MANAGEMENT SYSTEM</title>
<!-- <link rel="shortcut icon" href="Images/download.jpeg" /> -->
<!-- PWA ios support -->
<!-- <link rel="manifest" href="manifest.json">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="images/icons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="images/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="images/icons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="images/icons/favicon-16x16.png">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff"> -->
<!-- end PWA ios support -->
<link href="../assets/css/main.css" rel="stylesheet" type="text/css" />
<link href="../../LIB/fontawesome-free-5/css/all.min.css" rel="stylesheet" type="text/css" />
<link href="../../LIB/Engine/css/core.css" rel="stylesheet" type="text/css" />
<link href="../../LIB/w3c.CSS" rel="stylesheet" type="text/css" />
<!-- <link href='https://fonts.googleapis.com/css?family=Black Ops One' rel='stylesheet'> 
<link href="assets/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />-->
<!-- <link href="../../LIB/dhtmlxCalendar_v51_std/codebase/dhtmlxcalendar.css" rel="stylesheet" type="text/css" /> -->
<!-- <script src="../../LIB/dhtmlxCalendar_v51_std/codebase/dhtmlxcalendar.js" type="text/javascript"></script> -->
<!-- <link href='https://fonts.googleapis.com/css?family=Sofia' rel='stylesheet'> -->
<script src="../assets/js/main.js" type="text/javascript"></script>
<script src="../../LIB/Engine/js/core.js" type="text/javascript"></script>
<style>

</style>
</head>
<body class="adm-dontclose1">
    <div id="" class="aks-Records-cnt mva-zoom-bgimg0">
        <div class="aks-Records-all-width " style="padding:10px;background-color:var(--app-black-alpha-80);">
            <div class="aks-app-cnt-inner adm-dontclose1">
                <?php //require_once "../ui/admin/mainbody.php";?>
            </div>
        </div>
        <div id="exitPop"><?php //require_once "../ui/widget/pop.php";?></div>
        <!-- bottom left cnt -->
      <div id="" class="aks-vot-smr-alrt-box" style="position: absolute;left:0%;bottom:8%;padding: 0.5em;">
          <!-- display notify here afterbegin-->
          <div id="notifyID"></div>
      </div>
      <!-- printer -->
      <div><?php //require_once "../ui/printer/printerui.php";?></div>
    </div>
    <script>
//Make the DIV element draggagle:
dragElement(document.getElementById("mydiv"));

function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (document.getElementById(elmnt.id + "header")) {
    /* if present, the header is where you move the DIV from:*/
    document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
  } else {
    /* otherwise, move the DIV from anywhere inside the DIV:*/
    elmnt.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();
    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
  }
};
document.body.onclick = function(e){
	// console.log(e.target.classList);
	if(e.target.classList.contains("adm-dontclose1")){
    document.getElementById('getRty').style.display='none';
    }
}
</script>
</body>
</html>