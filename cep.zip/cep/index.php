<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AKSU-CEP</title>
<link rel="shortcut icon" href="assets/images/chlogo.png" />
<!-- PWA ios support -->
<link rel="apple-touch-icon" sizes="57x57" href="assets/images/icons/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="assets/images/icons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="assets/images/icons/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="assets/images/icons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="assets/images/icons/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="assets/images/icons/apple-icon-120x120.png">
<!-- <link rel="apple-touch-icon" sizes="144x144" href="assets/images/icons/apple-icon-144x144.png"> -->
<link rel="apple-touch-icon" sizes="152x152" href="assets/images/icons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/images/icons/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="assets/images/icons/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="assets/images/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="assets/images/icons/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="assets/images/icons/favicon-16x16.png">
<link rel="manifest" href="manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="assets/images/icons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<!-- end PWA ios support cep-gen.css-->
<link href="assets/css/main.css" rel="stylesheet" type="text/css" />
<link href="assets/css/cep-color.css" rel="stylesheet" type="text/css" />
<link href="assets/css/cep-gen.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="assets/css//magic.min.css">
<link href="assets/css/cep-font.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../LIB/mobiriseicons/16px/mobirise/style.css">
<link href="../LIB/fontawesome-free-5/css/all.min.css" rel="stylesheet" type="text/css" />
<link href="../LIB/Engine/css/core.css" rel="stylesheet" type="text/css" />
<link href="../LIB/w3c.CSS" rel="stylesheet" type="text/css" />
<!-- <link href="../LIB/dhtmlxCalendar_v51_std/codebase/dhtmlxcalendar.css" rel="stylesheet" type="text/css" />
<script src="../LIB/dhtmlxCalendar_v51_std/codebase/dhtmlxcalendar.js" type="text/javascript"></script> -->
<script src="../LIB/Engine/js/core.js" type="text/javascript"></script>
<script src="assets/js/cep.js" type="text/javascript"></script>
<style>
     .aks-Records-inpelem-cnt{
    height: 45px;
    background-color: var(--app-dark-mode-gray-90);
    box-shadow: var(--app-box-shadow-high);
    border-top-left-radius: var(--app-width-5);
    border-top-right-radius: var(--app-width-5);
    padding:var(--app-width-4);
}
.aks-Records-border-bottom{
  border-bottom: 2px solid var(--app-blue-40)!important;
}

</style>
<!-- chart -->
<!-- <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script>
google.charts.load('current', {'packages':['corechart']});
</script> -->
</head>
<body class="adm-dontclose1">
    <div id="grtcntrProg" class="aks-Records-cnt mva-zoom-bgimg">
        <!-- <div class="aks-Records-all-width " style="padding:50px;background-color:var(--app-black-alpha-80);">
            <div class="aks-app-cnt-inner adm-dontclose1">
                <?php //require_once "ui/body/mainbody.php";?>
            </div>
        </div>
        <div id="exitMenus" style="display: none;"><?php //require_once "ui/widget/menus.php";?></div> -->
    </div>
<!-- bottom left cnt -->
<div id="" class="aks-vot-smr-alrt-box" style="position: absolute;left:0%;bottom:8%;padding: 0.5em;overflow:hidden;z-index:200000000000000;">
    <!-- display notify here afterbegin-->
    <div id="notifyID"></div>
</div>
<!-- printer -->
<div><?php require_once "ui/printer/printerui.php";?></div>
    <!-- login -->
    <div id="exitLogin" class="" style="display:block;">
		<?php require_once "ui/views/login/loginPage.php";?>
	</div>
<div id="exitPop"><?php require_once "ui/widget/pop.php";?></div>
    <!-- installer -->
<div id="installContainer" class="spt-bigBox-cont-installer" style="display:none;">
    <div class="w3-display-container" style="width:100%;height:100%;">
        <div class="w3-display-middle w3-text-white w3-center w3-round" style="width:100%;max-width:300px;height:390px;background-color:#222;box-shadow: var(--app-box-shadow);position:relative;">
        <!-- close -->
			<div title="Close" class="adm-smr-bgr aks-smr-clo-btn-" onclick="Records.Engine.exitWindow('installContainer');" style="position:absolute;top:-14px;right:-11px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 0.3);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow);">
            <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                <i class="fas fa-times w3-small w3-display-middle"></i>
            </div>
            </div>
            <div class="w3-row-padding" style="width:100%;height:120px;padding:30px 10px;">
                <div class="w3-col s4 w3-display-container"><div class="cor-border" style="width:70px;margin:auto;height:70px;border-radius:50%;"><i class="fab fa-android w3-large w3-display-middle"></i></div></div>
                <div class="w3-col s4 w3-display-container"><div class="cor-border" style="width:70px;margin:auto;height:70px;border-radius:50%;"><i class="fab fa-apple w3-large w3-display-middle"></i></div></div>
                <div class="w3-col s4 w3-display-container"><div class="cor-border" style="width:70px;margin:auto;height:70px;border-radius:50%;"><i class="fab fa-windows w3-large w3-display-middle"></i></div></div>
                <!-- <i class="fa-brands fa-apple"></i> -->
            </div>
            <div class="w3-display-container aks-Records-module-font-light" style="width:100%;height:calc( 100% - 120px );">
                <div style="text-align:left;padding:20px;">
                    Welcome to AKSU Admission Installer<br>
                    Click the button below to Install this app on<br>
                    <div>> Android phone</div>
                    <div>> IOS phones</div>
                    <div>> Desktop or Laptop computer</div>
                </div>
                <div class="w3-margin-top">
                    <button id="butInstall" class="w3-pink w3-button w3-center w3-round" style="padding: 5px 50px;">Install</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
document.body.onclick = function(e){
	// console.log(e.target.classList);
	if(e.target.classList.contains("adm-dontclose1")){
    // Records.Engine.exitWindow('sideNav_id');
    CEP.Engine.exitOlvWindow('getTop');
    CEP.Engine.exitOlvWindow('getTop2');
    }
}
</script>
<script src="assets/js/main.js" type="text/javascript"></script>
</body>
</html>
<!-- Connection failed: Only one usage of each socket address (protocol/network address/port) is normally permitted. -->
<!-- background-color: #1c1a1a;  BG-->
<!-- background-color: #282828; box rectangle -->