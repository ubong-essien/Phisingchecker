<?php
{"Tuition":15000,"Medical":5000,"Games":1000,"Examination":5000,"Laboratory Fees":5000, "Utility":4000,"Library Fees":2000,"Student Union Dues":1000,"TransactionCharge":700}

$item = array(
    1 => array(
        "Tuition"=>15000,
        "Medical"=>5000,
        "Games"=>1000,
        "Examination"=>5000,
        "Laboratory Fees"=>5000,
        "Utility"=>4000,
        "Library Fees"=>2000,
        "Student Union Dues"=>1000,
        "TransactionCharge"=>700
    ),
    2 => array(
        "Tuition"=>15000,
        "TransactionCharge"=>700
    ),
    3 => array(
        "Tuition"=>30000,
        "Medical"=>5000,
        "Games"=>1000,
        "Examination"=>5000,
        "Laboratory Fees"=>5000,
        "Utility"=>4000,
        "Library Fees"=>2000,
        "Student Union Dues"=>1000,
        "TransactionCharge"=>700
    )

);
1 => array(
    "Tuition"=>15000,
    "Medical"=>5000,
    "Games"=>1000,
    "Examination"=>5000,
    "Laboratory Fees"=>5000,
    "Utility"=>4000,
    "Library Fees"=>2000,
    "Student Union Dues"=>1000,
    "TransactionCharge"=>700
),
2 => array(
    "Tuition"=>15000,
    "Medical"=>5000,
    "Games"=>1000,
    "Examination"=>5000,
    "Laboratory Fees"=>5000,
    "Utility"=>4000,
    "Library Fees"=>2000,
    "Student Union Dues"=>1000,
    "TransactionCharge"=>700
),
3 => array(
    "Tuition"=>15000,
    "Medical"=>5000,
    "Games"=>1000,
    "Examination"=>5000,
    "Laboratory Fees"=>5000,
    "Utility"=>4000,
    "Library Fees"=>2000,
    "Student Union Dues"=>1000,
    "TransactionCharge"=>700
)