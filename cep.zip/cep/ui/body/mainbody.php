<?php
    require_once "engine/Robot.php";  
    // setting up the system
    $rst = $_->Select("appsetting_tb","*","Active = 1");
    if($rst[1] > 0){
        $rowSetting = $rst[0]->fetch_assoc();
        $getDesc = explode("~",$rowSetting['AppDescription']);
        $_SESSION['appName'] = $rowSetting['AppName'];
        $_SESSION['appImage'] = $rowSetting['AppImage'];
        $_SESSION['LoginCompanyName'] = $rowSetting['LoginCompanyName'];
        $_SESSION['LoginAppImage'] = $rowSetting['LoginAppImage'];
    }else{die('No set up menu');}
    // display module
    $rstModules = $_->Select("appmodules_tb","*","Active = 1");
    if($rstModules[1] > 0){
        $arrayModules = [];
        $cnt = 1;
        while($rowModules = $rstModules[0]->fetch_assoc()){
            $arrayModules[$cnt] = [$rowModules['Name'],$rowModules['Description'],$rowModules['Icon'],$rowModules['LoadingIcon'],$rowModules['JsFunction'],$rowModules['URL'],$rowModules['ID'],$rowModules['Title'],$rowModules['JsFunctionParam'],$rowModules['SubURL'],$rowModules['JsDashboardFunction'],$rowModules['Total']];
            $cnt++;
        }
    }else{die('No set up menu');}
?>
<div class="aks-app-all-main-cnt cor-fadein-cnt adm-dontclose1">
    <!--left nav-->
    <div class=" aks-app-topnav-cnt w3-card-4">
        <?php require_once "topnav.php";?>
    </div>
    <!-- concept height 10px -->
    <div class=" aks-app-topnav-cnt-1 w3-hide-small w3-hide-medium"></div>
     <!-- main-body -->
    <div class=" aks-app-main-cnt aks-app-color">
        <div class="aks-Records-all-width cor-row">
            <div class="cor-column aks-app-cnt-smr" style="width:100%;height:100%;">
                <div id="hideThisL" class="adm-dontclose1 cor-fadein-cnt aks-Records-all-width stp-border aks-Records-pop-cnt-bgr " style="padding:0.125em;box-shadow:var(--app-box-shadow-low);">
                    <!-- description -->
                    <div class="" style="width:100%;height:90px;padding:8px;">
                        <div class="come-in-txt-right" style="font-size:20px;">
                            Get Started - <span style="font-size:16px;"><?=$getDesc[0]?></span>
                        </div>
                        <div class="come-in-left" style="font-size:16px;margin-top:20px;position:absolute;padding:0px;">
                        <?=$getDesc[1]?>
                        </div>
                    </div>
                    <div class="w3-row" style="width:100%;height:calc( 100% - 90px );position:relative;overflow:auto;">
                        
                        <!-- 1 row -->
                        <div class="w3-col l3 m6 s12 cell-color-white">
                            <div class="w3-row">
                                <div class="aks-sen-build-blocks">
                                        <div id="doctoraccess" onclick="<?=$arrayModules[1][4]?>('<?=$arrayModules[1][0]?>',<?=$arrayModules[1][6]?>,'cog<?=$arrayModules[1][6]?>','<?=$arrayModules[1][5]?>','<?=$arrayModules[1][8]?>','<?=$arrayModules[1][9]?>','<?=$arrayModules[1][10]?>');" class="tel-blocks w3-display-container   tel-blocks-td-bg-color" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.1s;animation-fill-mode: forwards;opacity:0;">   
                                            <div class="w3-display-topright w3-text-white"><i id="cog<?=$arrayModules[1][6]?>" class="<?=$arrayModules[1][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                            <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                    <i class="<?=$arrayModules[1][2]?> w3-xxlarge"></i>
                                                    <div class="cel-block-txt-size"><?=$arrayModules[1][0]?></div>
                                                    <div class="aks-Records-module-font-12"><?=$arrayModules[1][1]?></div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="w3-row">
                                <div class="aks-sen-build-blocks">
                                        <div id="accesspatient" onclick="<?=$arrayModules[2][4]?>('<?=$arrayModules[2][0]?>',<?=$arrayModules[2][6]?>,'cog<?=$arrayModules[2][6]?>','<?=$arrayModules[2][5]?>','<?=$arrayModules[2][8]?>','<?=$arrayModules[2][9]?>','<?=$arrayModules[2][10]?>');" class="tel-blocks w3-display-container  w3-text-white tel-cellgradient-orange" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.2s;animation-fill-mode: forwards;opacity:0;">
                                            <div class="w3-display-topright w3-text-white"><i id="cog<?=$arrayModules[2][6]?>" class="<?=$arrayModules[2][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                            <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                    <i class="<?=$arrayModules[2][2]?> w3-xxlarge"></i>
                                                    <div class="cel-block-txt-size"><?=$arrayModules[2][0]?></div>
                                                    <div class="aks-Records-module-font-12"><?=$arrayModules[2][1]?></div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="w3-row">
                                <div class="aks-sen-build-blocks">
                                        <div onclick="<?=$arrayModules[3][4]?>('<?=$arrayModules[3][0]?>',<?=$arrayModules[3][6]?>,'cog<?=$arrayModules[3][6]?>','<?=$arrayModules[3][5]?>','<?=$arrayModules[3][8]?>','<?=$arrayModules[3][9]?>','<?=$arrayModules[3][10]?>');" class="tel-blocks w3-display-container  tel-cell-block-gradient-red " style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.3s;animation-fill-mode: forwards;opacity:0;">
                                        <div class="w3-display-topright w3-text-white"><i id="cog<?=$arrayModules[2][6]?>" class="<?=$arrayModules[2][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                            <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                    <i class="<?=$arrayModules[3][2]?> w3-xxlarge"></i>
                                                    <div class="cel-block-txt-size"><?=$arrayModules[3][0]?></div>
                                                    <div class="aks-Records-module-font-12"><?=$arrayModules[3][1]?></div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <!-- 2 row -->
                        <div class="w3-col l3 m6 s12 ">
                            <div class="w3-row">
                                <div class="aks-sen-build-blocks">
                                    <div onclick="<?=$arrayModules[4][4]?>('<?=$arrayModules[4][0]?>',<?=$arrayModules[4][6]?>,'cog<?=$arrayModules[4][6]?>','<?=$arrayModules[4][5]?>','<?=$arrayModules[4][8]?>','<?=$arrayModules[4][9]?>','<?=$arrayModules[4][10]?>');" class="tel-blocks  w3-display-container tel-cell-blue-bg" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.4s;animation-fill-mode: forwards;opacity:0;">
                                    <div class="w3-display-topright w3-text-white"><i id="cog<?=$arrayModules[4][6]?>" class="<?=$arrayModules[4][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                        <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                <i class="<?=$arrayModules[4][2]?> w3-xxlarge"></i>
                                                <div class="cel-block-txt-size"><?=$arrayModules[4][0]?></div>
                                                <div class="aks-Records-module-font-12"><?=$arrayModules[4][1]?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-row aks-sen-build-blocks" style="padding:0px;">
                                        <div class="w3-col s6">
                                            <div class="tel-dashboard-td  w3-display-container " style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.5s;animation-fill-mode: forwards;opacity:0;">
                                                <div onclick="<?=$arrayModules[5][4]?>('<?=$arrayModules[5][0]?>',<?=$arrayModules[5][6]?>,'cog<?=$arrayModules[5][6]?>','<?=$arrayModules[5][5]?>','<?=$arrayModules[5][8]?>','<?=$arrayModules[5][9]?>','<?=$arrayModules[5][10]?>');"  class="tel-dashboard-td-inner w3-display-container tell-cell-teal-col w3-text-black">
                                                    <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                                <i class="<?=$arrayModules[5][2]?> w3-xxlarge"></i>
                                                                <div class="cel-block-txt-size"><?=$arrayModules[5][0]?></div>
                                                                <div class="aks-Records-module-font-12"><?=$arrayModules[5][1]?></div>
                                                        </div>
												</div>
                                            </div>
                                        </div>
                                        <div class="w3-col s6">
                                            <div class="tel-dashboard-td  w3-display-container w3-center">
												<div onclick="<?=$arrayModules[6][4]?>('<?=$arrayModules[6][0]?>',<?=$arrayModules[6][6]?>,'cog<?=$arrayModules[6][6]?>','<?=$arrayModules[6][5]?>','<?=$arrayModules[6][8]?>','<?=$arrayModules[6][9]?>','<?=$arrayModules[6][10]?>');" class="tel-dashboard-td-inner  w3-display-container w3-center tel-cell-purple-bg" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.6s;animation-fill-mode: forwards;opacity:0;">
                                                <div class="w3-display-topright "><i id="cog<?=$arrayModules[6][6]?>" class="<?=$arrayModules[6][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                                    <div class="w3-display-middle" style="min-width:100%;">
                                                            <div><i class="<?=$arrayModules[6][2]?>  w3-xxlarge"></i></div>
                                                            <div class="cel-block-txt-size"><?=$arrayModules[6][0]?></div>
                                                            <div class="aks-Records-module-font-12"><?=$arrayModules[6][1]?></div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                            </div>
                            <div class="w3-row " >
                                <div class="aks-sen-build-blocks">
                                    <div onclick="<?=$arrayModules[7][4]?>('<?=$arrayModules[7][0]?>',<?=$arrayModules[7][6]?>,'cog<?=$arrayModules[7][6]?>','<?=$arrayModules[7][5]?>','<?=$arrayModules[7][8]?>','<?=$arrayModules[7][9]?>','<?=$arrayModules[7][10]?>');" class="tel-blocks  w3-display-container tel-blocks-td-bg-color w3-text-black" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.7s;animation-fill-mode: forwards;opacity:0;">
                                    <div class="w3-display-topright "><i id="cog<?=$arrayModules[7][6]?>" class="<?=$arrayModules[7][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                        <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                <i class="<?=$arrayModules[7][2]?> w3-xxlarge"></i>
                                                <div class="cel-block-txt-size"><?=$arrayModules[7][0]?></div>
                                                <div class="aks-Records-module-font-12"><?=$arrayModules[7][1]?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- 3 row -->
                        <div class="w3-col l3 m6 s12 ">
                            <div class="w3-row">
                                <div class="w3-col s12">
                                    <div class="aks-sen-build-blocks">
                                        <div onclick="<?=$arrayModules[8][4]?>('<?=$arrayModules[8][0]?>',<?=$arrayModules[8][6]?>,'cog<?=$arrayModules[8][6]?>','<?=$arrayModules[8][5]?>','<?=$arrayModules[8][8]?>','<?=$arrayModules[8][9]?>','<?=$arrayModules[7][10]?>');" class="tel-blocks  w3-display-container tel-cell-purple-bg" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.8s;animation-fill-mode: forwards;opacity:0;">
                                        <div class="w3-display-topright "><i id="cog<?=$arrayModules[8][6]?>" class="<?=$arrayModules[8][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>    
                                        <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                                <i class="<?=$arrayModules[8][2]?> w3-xxlarge"></i>
                                                                <div class="cel-block-txt-size"><?=$arrayModules[8][0]?></div>
                                                                <div class="aks-Records-module-font-12"><?=$arrayModules[8][1]?></div>
                                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-row aks-sen-build-blocks" style="padding:0px;">
                                        <div class="w3-col s6">
                                            <div onclick="<?=$arrayModules[9][4]?>('<?=$arrayModules[9][0]?>',<?=$arrayModules[9][6]?>,'cog<?=$arrayModules[9][6]?>','<?=$arrayModules[9][5]?>','<?=$arrayModules[9][8]?>','<?=$arrayModules[9][9]?>','<?=$arrayModules[9][10]?>');" class="tel-dashboard-td  w3-display-container " id="yuuty" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.9s;animation-fill-mode: forwards;opacity:0;">
                                                <div class="tel-dashboard-td-inner w3-display-container tel-cell-block-gradient-red w3-text-black" >
                                                <div class="w3-display-topleft"><div class="w3-display-container w3-text-white" style="width:20px;height:20px;margin:auto;border-radius:50%;"><i class="w3-display-middle"><?=$arrayModules[9][11]?></i></div></div>
                                                <div class="w3-display-topright"><i id="cog<?=$arrayModules[9][6]?>" class="<?=$arrayModules[9][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                                    <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                                <i class="<?=$arrayModules[9][2]?> w3-xxlarge"></i>
                                                                <div class="cel-block-txt-size"><?=$arrayModules[9][0]?></div>
                                                                <div class="aks-Records-module-font-12"><?=$arrayModules[9][1]?></div>
                                                        </div>
												</div>
                                            </div>
                                        </div>
                                        <div class="w3-col s6">
                                            <div class="tel-dashboard-td  w3-display-container w3-center">
												<div onclick="<?=$arrayModules[10][4]?>('<?=$arrayModules[10][0]?>',<?=$arrayModules[10][6]?>,'cog<?=$arrayModules[10][6]?>','<?=$arrayModules[10][5]?>','<?=$arrayModules[10][8]?>','<?=$arrayModules[10][9]?>','<?=$arrayModules[10][10]?>');" class="tel-dashboard-td-inner  w3-display-container w3-center w3-text-white tel-cellgradient-orange" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 1.0s;animation-fill-mode: forwards;opacity:0;">
                                                    <div class="w3-display-middle" style="min-width:100%;">
                                                            <div><i class="<?=$arrayModules[10][2]?>  w3-xxlarge"></i></div>
                                                            <div class="cel-block-txt-size"><?=$arrayModules[10][0]?></div>
                                                            <div class="aks-Records-module-font-12"><?=$arrayModules[10][1]?></div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                            </div>
                            <div class="w3-row">
                                <div class="aks-sen-build-blocks">
                                    <div onclick="<?=$arrayModules[11][4]?>('<?=$arrayModules[11][0]?>',<?=$arrayModules[11][6]?>,'cog<?=$arrayModules[11][6]?>','<?=$arrayModules[11][5]?>','<?=$arrayModules[11][8]?>','<?=$arrayModules[11][9]?>','<?=$arrayModules[11][10]?>');" class="tel-blocks  w3-display-container tell-cell-teal-col w3-text-black" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 1.1s;animation-fill-mode: forwards;opacity:0;">
                                    <div class="w3-display-topright"><i id="cog<?=$arrayModules[11][6]?>" class="<?=$arrayModules[11][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                        <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                <i class="<?=$arrayModules[11][2]?> w3-xxlarge"></i>
                                                <div class="cel-block-txt-size"><?=$arrayModules[11][0]?></div>
                                                <div class="aks-Records-module-font-12"><?=$arrayModules[11][1]?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- 4 row -->
                        <div class="w3-col l3 m6 s12 ">
                            <div class="w3-row">
                                <div class="aks-sen-build-blocks-bigger">
                                    <div onclick="<?=$arrayModules[12][4]?>('<?=$arrayModules[12][0]?>',<?=$arrayModules[12][6]?>,'cog<?=$arrayModules[12][6]?>','<?=$arrayModules[12][5]?>','<?=$arrayModules[12][8]?>','<?=$arrayModules[12][9]?>','<?=$arrayModules[12][10]?>');" class="tel-blocks  w3-display-container tel-blocks-td-bg-color w3-text-black" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 1.2s;animation-fill-mode: forwards;opacity:0;">
                                    <div class="w3-display-topright w3-text-white"><i id="cog<?=$arrayModules[12][6]?>" class="<?=$arrayModules[12][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                        <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                <i class="<?=$arrayModules[12][2]?> w3-xxlarge"></i>
                                                <div class="cel-block-txt-size"><?=$arrayModules[12][0]?></div>
                                                <div class="aks-Records-module-font-12"><?=$arrayModules[12][1]?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-row aks-sen-build-blocks" style="padding:0px;">
                                        <div class="w3-col s6">
                                            <div onclick="<?=$arrayModules[13][4]?>('<?=$arrayModules[13][0]?>',<?=$arrayModules[13][6]?>,'cog<?=$arrayModules[13][6]?>','<?=$arrayModules[13][5]?>','<?=$arrayModules[13][8]?>','<?=$arrayModules[13][9]?>','<?=$arrayModules[9][10]?>');" class="tel-dashboard-td  w3-display-container " style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 1.3s;animation-fill-mode: forwards;opacity:0;">
                                                <div class="tel-dashboard-td-inner w3-display-container tel-cell-blue-bg">
                                                <div class="w3-display-topright w3-text-white"><i id="cog<?=$arrayModules[13][6]?>" class="<?=$arrayModules[13][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                                    <div class="w3-display-middle w3-center" style="min-width:100%;">
                                                                <i class="<?=$arrayModules[13][2]?> w3-xxlarge"></i>
                                                                <div class="cel-block-txt-size"><?=$arrayModules[13][0]?></div>
                                                                <div class="aks-Records-module-font-12"><?=$arrayModules[13][1]?></div>
                                                        </div>
												</div>
                                            </div>
                                        </div>
                                        <div class="w3-col s6">
                                            <div onclick="<?=$arrayModules[14][4]?>('<?=$arrayModules[14][0]?>',<?=$arrayModules[14][6]?>,'cog<?=$arrayModules[14][6]?>','<?=$arrayModules[14][5]?>','<?=$arrayModules[14][8]?>','<?=$arrayModules[14][9]?>','<?=$arrayModules[14][10]?>');" class="tel-dashboard-td  w3-display-container w3-center">
												<div class="tel-dashboard-td-inner  w3-display-container w3-center tel-cell-purple-bg" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 1.8s;animation-fill-mode: forwards;opacity:0;">
                                                <div class="w3-display-topright w3-text-white"><i id="cog<?=$arrayModules[14][6]?>" class="<?=$arrayModules[14][3]?> fa-spin" style="margin: 2px;display:none;"></i></div>
                                                    <div class="w3-display-middle" style="min-width:100%;">
                                                            <div><i class="<?=$arrayModules[14][2]?>  w3-xxlarge"></i></div>
                                                            <div class="cel-block-txt-size"><?=$arrayModules[14][0]?></div>
                                                            <div class="aks-Records-module-font-12"><?=$arrayModules[14][1]?></div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>