<?php
$appNma = explode('~', $_SESSION['appName']);
?>
<div class="come-in-lefttxt-topp aks-Records-all-width cor-border-bottom adm-dontclose1">
    <div class="w3-row" style="overflow:hidden;width:100%;height:100%;">
        <div class="w3-col s3">
            <div class="w3-row aks-pad-smr" style="padding:1px;">
                <div class="w3-col s12">
                    <img src="assets/images/<?=$_SESSION['appImage']?>" alt="photo" class="w3-hide-small w3-hide-medium" width="30" height="30" style="border-radius:0%;">
                    <span class="aks-Records-btn-inner-txt xxx aks-Records-module-font-12 w3-hide-small w3-hide-medium">
                        <span><?=$appNma[0]?></span>-<span style="font-size:11px;"><?=$appNma[1]?></span></span>
                    <span onclick="Records.APP.TopBar2.minimize()" class="fas fa-bars cor-fadein-cnt w3-large cor-text1-shaow w3-hide-large"></span>
                </div>
            </div>
        </div>
        <div class="w3-col s5" style="padding:1px;box-sizing:border-box;">
           
        </div>
        <div class="w3-col s4">
            <div class="w3-row">
                <div class="w3-col s3">
                    <div class=" w3-row" style="padding:0px;">
                        <div class="w3-col s12 w3-text-black cor-row">
                            <div class="cor-column" style="width:31.50px;height:31.50px;border-radius:50px;">
                                <img id="getUserphoto" src="" alt="photo" width="100%" height="100%" style="border-radius:50%;">
                            </div>
                            <div class=" cor-column">
                                <div id="getUsername__" style="margin-top:6px;z-index:10;color:black!important;"></div>
                            </div>
                        </div>
                        <!-- <div title="Contact Us" class="w3-col s4 cor-pointer"><i class="fas fa-phone adm-font-rot-97 "></i></div> -->
                        <!-- <div onclick="__I.toggleFullScreen();" title="Full Screen" class="w3-col s2 cor-pointer" style="padding:8px;"><i class="fas fa-arrows-alt-v aks-Records-heart-beat" style="transform: rotate(45deg)"></i></div> -->
                    </div>
                </div>
                <div class="w3-col s9">
                
                    <div title="Logout" onclick="Telemedicine.exitApp()" class="w3-right" style="padding:8px;"><i class="fas fa-power-off aks-Records-heart-beat cor-fadein-cnt cor-pointer"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- AK17/NAS/GEY/041 -->