<?php
    require_once "../engine/Robot.php";    
?>
<div class="adm-dontclose1 cor-fadein-cnt aks-Records-all-width aks-main-body-border-left aks-Records-color" style="background-color:var(--app-black-alpha-60)">
    <div id="removeLoginPage" class="aks-Records-all-width w3-display-container" style="padding:0px!important;">
        <i class="fas fa-cog fa-spin w3-large w3-display-middle"></i>
    </div>
</div>