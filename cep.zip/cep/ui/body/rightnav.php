<div class="adm-dontclose1 cor-fadein-cnt aks-Records-all-width cor-border-right cor-border-top cor-border-bottom" style="padding:0px;background-color:var(--app-black-alpha-60);">
   <div class="aks-record-righ-nv" style="padding:4px;box-shadow:0 3px 6px rgb(0 0 0 / 16%), 0 3px 6px rgb(0 0 0 / 23%);background-color: var(--app-black-alpha-50);">
       
   </div>
   <div class="aks-record-righ-nv-body">
      
   </div>
</div>