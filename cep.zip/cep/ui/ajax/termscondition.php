<div class="aks-Records-all-width aks-Records-color w3-text-black" style="padding:5px;">
    1. Payment of any type is done via Bank and Online
</div>
