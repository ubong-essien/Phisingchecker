<div class="aks-Records-all-width " style="padding: 12px 15px;background-color:var(--app-black-livscore);">
    <div style="position:absolute;left:50%;top:30%;transform:translate(-50%,-30%);width:100%;max-width:270px;height:270px;">
        <div class=" adm-uploader-cnt" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;padding:20px;">
            <div class=" adm-uploader-cnt" style="padding:25px;">
                <div class="equ-bgr-etrc adm-uploader-cnt" >
                    <div class="w3-display-container w3-center" style="height: 100%;">
                            <div title="CHOOSE FILE" class="w3-display-middle">
                                <input id="file_12388" onchange="Telemedicine.Modules.JambOlevelResult.jambOlevel()" type="file" class="w3-blue" style="width:100%;height:200px;opacity:0;position:relative;z-index:3;cursor:pointer!important;">
                                <i id="shuplodjol" class="fa fa-upload w3-jumbo w3-text-white" style="position: absolute;left:50%;top:50%;transform:translate(-50%,-50%);"></i>
                                <i id="shoC_cogjol" class="fa fa-cog fa-spin w3-jumbo w3-text-white" style="display:none;position: absolute;left:16%;top:40%;transform:translate(-16%,-40%);"></i>
                                <span class="aks-Records-module-font-12">CHOOSE FILE</span>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
