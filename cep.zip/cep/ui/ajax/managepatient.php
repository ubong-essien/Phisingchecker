<div class="aks-Records-all-width w3-row tel-Records-color1" style="padding:15px 70px;background-color:var(--app-black-livscore);">
   <div class="w3-col m4 inv-marg-top">
         <div onclick="Records.Engine.loadComputedLegger('ui/ajax/addpatient.php')" class="tel-racords-pay__ w3-round-large w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;">
                  <div class="w3-display-middle w3-center" style="min-width:100%;">
                  <i class="fas fa-user-plus w3-xlarge aks-app-color-2"></i>
                  </div>
               <div class="w3-display-bottommiddle w3-center">
                  <div class="aks-Records-module-font-12 aks-Records-btn-inner-txt ">ADD PATIENTS</div>
                  <div class="aks-Records-font-07 aks-Records-btn-inner-txt ">Add,Edit...</div>
               </div>
         </div>
                        
    </div>
    <div class="w3-col m4 inv-marg-top">
         <div onclick="//Records.Engine.loadComputedLegger('ui/ajax/addpatient.php')" class="tel-racords-pay__ w3-round-large w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;">
                  <div class="w3-display-middle w3-center" style="min-width:100%;">
                  <i class="fas fa-id-card-alt w3-xlarge aks-app-color-2"></i>
                  </div>
               <div class="w3-display-bottommiddle w3-center" style="min-width:100%;">
                  <div class="aks-Records-module-font-12 aks-Records-btn-inner-txt ">MANAGE CARD</div>
                  <div class="aks-Records-font-07 aks-Records-btn-inner-txt ">Cards...</div>
               </div>
         </div>
    </div>
    <div class="w3-col m4 inv-marg-top">
         <div onclick="//Records.Engine.loadComputedLegger('ui/ajax/addpatient.php')" class="tel-racords-pay__ w3-round-large w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;">
                  <div class="w3-display-middle w3-center" style="min-width:100%;">
                  <i class="fas fa-procedures w3-xlarge aks-app-color-2"></i>
                  </div>
               <div class="w3-display-bottommiddle w3-center" style="min-width:100%;">
                  <div class="aks-Records-module-font-12 aks-Records-btn-inner-txt ">MANAGE BED</div>
                  <div class="aks-Records-font-07 aks-Records-btn-inner-txt ">Beds...</div>
               </div>
         </div>
    </div>
</div>
