<?php
        require_once "../../engine/Robot.php";
        require_once "../../script/errormsg.php";
        $rst = $_->Select("state_tb",'*',"1 = 1");
        if($rst[1] > 0){
            $TB = '<table class="aks-Records-btn-inner-txt aks-Records-font-11" style="width:100%;">';
            while($row = $rst[0]->fetch_assoc()){
                $TB.='<tr onclick="Records.RightController.getTB(\'TB_'.$row['StateName'].'_'.$row['StateID'].'\',\''.$_POST['param'].'\')" class="cor-pointer"><td>'.$row['StateName'].'</td></tr>';
            }
            $TB.='</table>';
            die(json_encode(["SUCCESS" => ["Message" => $TB]]));
        }else{
            die(json_encode(["ERROR" => ["Message" => $errorCode['###']]]));
        }
        //getdestState_1
?>
