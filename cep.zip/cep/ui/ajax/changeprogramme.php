<?php
require_once "../../engine/Robot.php";
// subject
// lga
// $rstDeptLGA = $_->Select("lga_tb","*","1=1");
// if($rstDeptLGA[1] > 0) {
//     $TBDeptLGA ='<option value="" selected disabled>New LGA</option>';
//     while($rowDeptLGA = $rstDeptLGA[0]->fetch_assoc()){
//         $TBDeptLGA.='<option value="tr_'.$rowDeptLGA['LGAName'].'" >'.$rowDeptLGA['LGAName'].'</option>';
//     }
// }else{die("No set up");}
// dept
$rstDept = $_->Select("programme_tb","ProgID,ProgName","1=1");
if($rstDept[1] > 0) {
    $TBDept ='<option value="" selected disabled>New department</option>';
    while($rowDept = $rstDept[0]->fetch_assoc()){
        $TBDept.='<option value="tr_'.$rowDept['ProgID'].'" >'.$rowDept['ProgName'].'</option>';
    }
}else{die("No set up");}
?>
<div class="aks-Records-all-width " style="padding:10px 50px;overflow:auto;background-color:var(--app-black-livscore);">
    <div id="payInfo" class=" clxx aks-records-pding w3-animate-opacity w3-center" style="width:100%;height:100%;position:relative;">
                <form action="javascript:void(0)" onsubmit="Telemedicine.Modules.changeProgramme.newProgramme()" style="position:relative;">
                    <div style="position:absolute;top:4%;"><i id="rtt" class="fas fa-cog fa-spin w3-small" style="display:none;"></i></div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m12 adm-smr-margin-top">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.4s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Jamb Number" id="tel_jam_number_ch" required type="text" oninput="__I.onInputUppc('tel_jam_number_ch');Telemedicine.Modules.changeProgramme.changeProg();" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Search jamb number">
                              </div>
                          </div>
                    </div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m12 adm-smr-margin-top">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.4s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Jamb Number" id="tel_jam_caName" readonly type="text" oninput="//__I.onInputUppc('getJReN_1__');" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Candidate name">
                              </div>
                          </div>
                    </div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m12 adm-smr-margin-top">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.4s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Jamb Number" id="tel_jam_numberrr" readonly type="text" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Jamb number">
                              </div>
                          </div>
                    </div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m12 adm-smr-margin-top">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.4s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Jamb Number" id="tel_jam_dept" readonly type="text" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Previous department">
                              </div>
                          </div>
                    </div>
                    <!-- <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m12">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="getDpetLGA" title="LGA" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <?//$TBDeptLGA?>
                                    </select>
                              </div>
                          </div>
                    </div> -->
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m12">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="getDpet_rr" title="Department" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <?=$TBDept?>
                                    </select>
                              </div>
                          </div>
                    </div>
                        <!-- btn -->
                        <div class=" w3-center w3-margin-top">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-top w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat w3-pink aks-records-chos-bgr w3-circle w3-display-container" style="width:70px;margin:auto;height:70px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
    </div>
</div>
