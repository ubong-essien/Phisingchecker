<?php
require_once "../../engine/Robot.php";
require_once "../../script/errormsg.php";
$rst = $_->Select("trackaction_tb",'*',"Status = 1");
if($rst[1] > 0){
    $Tb = '<option value="" disabled selected>Choose Location</option>';
    while($row = $rst[0]->fetch_assoc()){
        $Tb.='<option value="'.$row['ID'].'">'.$row['Name'].'</option>';
    }
}
$TB = '
<div class="aks-Records-all-width aks-Records-color" style="padding:0px;">
    <div class="aks-transcript-cnt">
        <div class="aks-Records-all-width">
            <form action="javascript:void(0)">
                <div style="width:100%;height:calc( 100% );">
                    <!-- Contracking Content -->
                    <div class="aks-Records-pding" style="width:100%;height:100%;">
                        <div class="aks-Records-inpelem-cnt aks-Records-border-bottom cor-margin-top">
                            <select class="w3-selectq" id="cars__p" style="width:100%;height:100%;background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                '.$Tb.'
                            </select>
                        </div>
                        <!-- btn -->
                        <div class="cor-margin-top w3-center">
                            <button title="Previous" onclick="Records.APP.MainBody.submitAppliactionTracking()" class="w3-button  cor-fadein-cnt cor-play-heart-beat aks-Records-color aks-Records-chos-bgr w3-circle w3-display-container" style="width:70px;margin:auto;height:70px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn" title="Next" class="fas fa-long-arrow-alt-right w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </div>   
                </div>
            </form>
        </div>
    </div>
</div>
';
die(json_encode(["SUCCESS" => ["Message" => $TB]]));
?>
