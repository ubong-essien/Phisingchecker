<?php
error_reporting(0);
require_once "../../engine/Robot.php";
require_once "../../script/errormsg.php";
require_once "../../engine/sha3encryptdecriptold.php";
$getJall = json_decode($_POST['data']);
// print_r($getJall);
$chatTime = decryptSH3($getJall->patientSupliedTime);
$description = decryptSH3($getJall->describeIllnes);
$decryptPrescription = decryptSH3($getJall->doctPrescription);
$rstUpdate = $_->Update("patientappointment_db",["MsgRead" => 1],"ID = ".trim($getJall->userappID)."");
?>
<div class="gss-parElem-sinlings w3-text-white  w3-animate-opacity" style="width: 100%;height:100%;position:relative;display:block;padding:12px;overflow:auto;">
    <form action="javascript:void(0)" onsubmit="Telemedicine.Modules.Doctors.sendPrescription()">
    <input id="getPatientUserXXX" type="hidden" value="<?=$getJall->userappID?>">
    <div class="cor-border-bottom cor-border-top"  style="width:100%;height:310px;overflow:auto;">
        <div style="font-size:11.70px;"><span class="cor-border-bottom"><strong>DOCTORS DETAILS</strong></span></div>
            <div class="w3-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Doctor's Name:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->doctName?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                   Profession:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->profession?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Specialty:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->specialty?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Visit Reasons:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->visitedR?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Description:
                </div>
                <div class="w3-col s10">
                    <?=$description?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Schedule Name:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->scheduleName?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                   Chat Time(Schedule):
                </div>
                <div class="w3-col s10">
                    <?=$chatTime?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2 ">
                    Chat Approved?:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->chatApprovd?>
                </div>
            </div>
           
    </div>
    <div style="width:100%;height:calc( 100% - 310px );overflow:auto;">
        <div class="" style="font-size:11.70px;"><span class="cor-border-bottom"><strong>DOCTORS PRESCRIPTIONS</strong></span></div>
        <div class="w3-text-white w3-margin-top tel-box-shadow__ cor-border" style="box-shadow:var(--app-box-shadow);">
            <?=$decryptPrescription?>
        </div>
    </div>
    </form>
</div>
