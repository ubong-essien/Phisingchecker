<div class="aks-Records-all-width w3-row tel-Records-color1" style="padding:15px 70px;background-color:var(--app-black-livscore);">
   <div class="w3-col m4 inv-marg-top">
         <div onclick="Records.Engine.loadComputedLegger('ui/ajax/alldoctorappointment.php')" class="tel-racords-pay__ w3-round-large w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;">
                  <div class="w3-display-middle w3-center" style="min-width:100%;">
                  <i class="fas fa-stethoscope w3-xlarge aks-app-color-2"></i>
                  </div>
               <div class="w3-display-bottommiddle w3-center" style="min-width:100%;">
                  <div class="aks-Records-module-font-12 aks-Records-btn-inner-txt ">ALL APPOINTMENTS</div>
                  <div class="aks-Records-font-07 aks-Records-btn-inner-txt ">Meet Patients...</div>
               </div>
         </div>
                        
    </div>
    <div class="w3-col m4 inv-marg-top">
         <div onclick="//Records.Engine.loadComputedLegger('ui/ajax/addpatient.php')" class="tel-racords-pay__ w3-round-large w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;">
                  <div class="w3-display-middle w3-center" style="min-width:100%;">
                  <i class="fas fa-vials w3-xlarge aks-app-color-2"></i>
                  </div>
               <div class="w3-display-bottommiddle w3-center" style="min-width:100%;">
                  <div class="aks-Records-module-font-12 aks-Records-btn-inner-txt ">SCHEDULE</div>
                  <div class="aks-Records-font-07 aks-Records-btn-inner-txt ">Schedulling...</div>
               </div>
         </div>
    </div>
    <div class="w3-col m4 inv-marg-top">
         <div onclick="//Records.Engine.loadComputedLegger('ui/ajax/addpatient.php')" class="tel-racords-pay__ w3-round-large w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;">
                  <div class="w3-display-middle w3-center" style="min-width:100%;">
                  <i class="fas fa-clock w3-xlarge aks-app-color-2"></i>
                  </div>
               <div class="w3-display-bottommiddle w3-center" style="min-width:100%;">
                  <div class="aks-Records-module-font-12 aks-Records-btn-inner-txt ">TIME OFF</div>
                  <div class="aks-Records-font-07 aks-Records-btn-inner-txt ">Read Time...</div>
               </div>
         </div>
    </div>
</div>
