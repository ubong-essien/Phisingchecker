<?php
error_reporting(0);
require_once "../../engine/Robot.php";
require_once "../../script/errormsg.php";
require_once "../../engine/sha3encryptdecriptold.php";
$getJall = json_decode($_POST['data']);
$chatTime = decryptSH3($getJall->patientSupliedTime);
$description = decryptSH3($getJall->describeIllnes);
?>
<div class="gss-parElem-sinlings w3-text-white  w3-animate-opacity" style="width: 100%;height:100%;position:relative;display:block;padding:12px;overflow:auto;">
    <form action="javascript:void(0)" onsubmit="Telemedicine.Modules.Doctors.sendPrescription()">
    <input id="getPatientUserXXX" type="hidden" value="<?=$getJall->userappID?>">
    <div class="cor-border-bottom cor-border-top"  style="width:100%;height:310px;overflow:auto;">
        <div style="font-size:11.70px;"><span class="cor-border-bottom"><strong>PATIENT APPOINTMENT</strong></span></div>
            <div class="w3-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Patient Name:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->pName?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Visit Reasons:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->visitedR?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Description:
                </div>
                <div class="w3-col s10">
                    <?=$description?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Schedule Name:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->scheduleName?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                   Chat Time(Schedule):
                </div>
                <div class="w3-col s10">
                    <?=$chatTime?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                   Gender:
                </div>
                <div class="w3-col s10">
                    <?php
                        $rt = $getJall->gender=="F"?"Female":"Male";
                        echo $rt;
                    ?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2">
                    Birth Date:
                </div>
                <div class="w3-col s10">
                    <?=$getJall->patDOB?>
                </div>
            </div>
            <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2 cor-margin-top">
                    Chat Approved?:
                </div>
                <div class="w3-col s10">
                    <input title="Approve to Chat with Patient" id="getApproval" type="radio" class="w3-radio"> <span class="aks-Records-font-14">(Check this radio button if you want to chat Live with <?=$getJall->pName?>)</span>
                </div>
            </div>
            <!-- <div class="cor-margin-top w3-row aks-Records-font-11_60">
                <div class="w3-col s2 cor-margin-top">
                    Notify Pharmacist?:
                </div>
                <div class="w3-col s10">
                    <input title="Check this radio button if you wish to send prescription to Pharmacist first" id="notifyPat" type="radio" class="w3-radio"> <span class="aks-Records-font-14">(Check this radio button if you wish to send prescription to Pharmacist first</span>
                </div>
            </div> -->
    </div>
    <div style="width:100%;height:calc( 100% - 310px );overflow:auto;">
        <div class="" style="font-size:11.70px;"><span class="cor-border-bottom"><strong>DOCTORS PRESCRIPTIONS</strong></span></div>
        <div class="w3-white w3-margin-top">
            <textarea id="getPrescriDrugs" placeholder="Prescribe Drugs To <?=$getJall->pName?>"></textarea>
        </div>
        <!-- btn -->
        <div class=" w3-center cor-margin-top">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-top w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat w3-pink aks-records-chos-bgr w3-circle w3-display-container" style="width:65px;margin:auto;height:65px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
    </div>
    </form>
</div>
