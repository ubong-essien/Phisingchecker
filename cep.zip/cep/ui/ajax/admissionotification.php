<?php
require_once "../../engine/Robot.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$getR_r = $_->Select("admissionlog_tb a,pstudentinfo_tb p,programme_tb pr","a.JambNo,a.PhoneNo,p.SurName,p.FirstName,pr.ProgName,p.Email","a.JambNo = p.JambNo AND a.ProgID = pr.ProgID AND a.Sent = 0");
        $holdArr = [];
		if($getR_r[1] > 0){
			$cnt10 = 1;
			$cnt_1 = 0;
			$oupTB =<<<_E
			<ul class="w3-center"><li class="cor-border-bottom" style='animation:tablerow 0.5s ease-in-out '.$cnt_1.'s; opacity:0; animation-fill-mode:forwards'>
			<div class="w3-row aks-Records-module-font">
				<div class="w3-col s2 cor-text1-shaow spt-header-smr">REGISTRATION NO.</div>
				<div class="w3-col s4 cor-text1-shaow spt-header-smr">NAME</div>
				<div class="w3-col s3 cor-text1-shaow spt-header-smr">DEPARTMENT</div>
				<div class="w3-col s2 cor-text1-shaow spt-header-smr">PHONE</div>
			</div>
		</li>
_E;
			while($row = $getR_r[0]->fetch_assoc()){
				$Re_g = trim($row['JambNo']);
				$RegNo = trim($row['JambNo']);
				$ProgName = $row['ProgName'];//08066559566
				$phone = $row['PhoneNo'];//08066559566
				$progNamTr = $ProgName.'_'.$RegNo;
				$row['SurName'] = rtrim($row['SurName'],',');
				$row['FirstName'] = rtrim($row['FirstName'],',');
				$fulname = $row['SurName'].", ".$row['FirstName'];
                $holdArr[] = [trim($row['Email']),trim($phone),trim($ProgName),$RegNo];
                // $holdArr[] = [trim($phone),trim($row['Email']),trim($ProgName),trim($row['SurName']),trim($row['FirstName'])];
				$oupTB.=<<<_E
				<li id="li_id_Jamb$Re_g"  class="cor-border-bottom cor-ul-fix cor-pointer rep-bgr-hover  cor-fadein-cnt" style='animation:tablerow 0.5s ease-in-out '.$cnt_1.'s; opacity:0; animation-fill-mode:forwards'>
					<div class="w3-row">
						<div class="w3-col s2 cor-text1-shaow cor-header-smr spt-header-smr">$RegNo</div>
						<div class="w3-col s4 cor-text1-shaow cor-header-smr spt-header-smr">$fulname</div>
						<div class="w3-col s3 cor-text1-shaow cor-header-smr spt-header-smr">$ProgName</div>
						<div class="w3-col s2 cor-text1-shaow cor-header-smr spt-header-smr">$phone</div>
					</div>
				</li>
_E;

				
$cnt_1 += 0.4;
$cnt10++;
		}
		$oupTB.='</ul>';
	}else{
		$oupTB = 'No candidate yet';
		$cnt10 = 0;
	}
}
?>
<div class="w3-red-" style="width:100%;height:100%;">
    <div style="width:100%;height:calc( 100% - 80px );overflow:auto;padding:12px;">
        <?=$oupTB?>
    </div>
    <div id="sendObj" class="w3-center" data-stabilizer='{"holdPhoneEmail":<?=json_encode($holdArr)?>}' style="width:100%;height: 80px;position:relative;">
    <div style="position:absolute;left:1%;top:50%;">{<?=$cnt10?>}</div>
                            <button id="prevBtnSend" onclick="Telemedicine.Modules.AdmissionList.computePhoneObj('sendObj')" title="Previous" class="w3-button w3-margin-top w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat w3-pink aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                    <!-- <img id="NextBtn__" class=" w3-display-middle " src="assets/images/wicon.png" width="27" height="27" style="margin-left:2px;"> -->
                                            <div id="showProgress__" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
    </div>
</div>
