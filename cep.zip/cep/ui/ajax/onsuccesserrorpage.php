<?php
$jsObj = json_decode($_POST['data']);
?>
<div class="aks-Records-all-width aks-Records-color " style="padding:5px;">
    <div style="position:relative;width:100%;max-width:350px;margin:auto;margin-top:10px;background-color: var(--app-black-livscore);box-shadow: var(--app-box-shadow);border-radius:5px;padding:2px;">
    <!-- <div onclick="Records.Engine.MainUser.exitAppl()" style="position:absolute;top:-8px;right:-9px;width:25px;height:25px;padding:12px;border-radius:50%;    background-color: rgba(255, 255, 255, 0.3);z-index:2;cursor:pointer;">
        <div class="w3-display-container" style="position:relative;width:100%;height:100%;">
            <i class="fas fa-times w3-small w3-display-middle"></i>
        </div>
    </div> -->
        <?php
            if($jsObj->__Erorr == 0) {
                echo '<div class="w3-row w3-margin w3-center aks-Records-font-15 aks-Records-btn-inner-txt">PAYMENT SUCCESSFUL</div>
                <div class="w3-row w3-center aks-Records-project-up" style="width:100%;max-width:150px;margin:auto;height:150px;border-radius:50%;background-color:#ffff;box-shadow:var(--app-box-shadow);">
                    <div class="success-checkmark" style="padding:30px 0;margin-left:32px;">
                        <div class="check-icon">
                            <span class="icon-line line-tip"></span>
                            <span class="icon-line line-long"></span>
                            <div class="icon-circle"></div>
                            <div class="icon-fix"></div>
                        </div>
                    </div>
                </div>';
            }else{
                echo '<div class="w3-row w3-margin w3-center aks-Records-font-15 aks-Records-btn-inner-txt">PAYMENT FAILLED</div>
                <div class="w3-row w3-display-container w3-center aks-Records-project-up" style="width:100%;max-width:150px;margin:auto;height:150px;border-radius:50%;background-color:red;box-shadow:var(--app-box-shadow);">
                    <i class="fas fa-times w3-xxxlarge w3-display-middle"></i>
                </div>';
            }
        ?>
        <div style="width:100%;max-width:300px;margin:auto;margin-top:10px;">
            <div class="w3-row w3-round aks-app-color  aks-Records-res-cnt cor-fadein-cnt" style="opacity:0;position: relative;animation: goOutin 0.7s ease-in-out 0.1s forwards;background-color:rgba(255, 255, 255, 0.05);">
                    <div class="w3-col s1" style="padding:3px 6px;box-sizing:border-box;">
                        <i class="fas fa-bookmark w3-large"></i>
                    </div>
                    <div class="w3-col s8 aks-Records-btn-inner-txt aks-Records-module-font-12 ">
                        AMOUNT
                    </div>
                    <div class="w3-col s3">
                        <span class="aks-Records-module-font aks-Records-btn-inner-txt"><span class="aks-Records-font-8 w3-text-green">NGR </span><span id="transacID"><?=$jsObj->amt?></span></span>
                    </div>
            </div>
            <div class="w3-row w3-round aks-app-color  aks-Records-res-cnt cor-fadein-cnt" style="opacity:0;position: relative;animation: goOutin 0.7s ease-in-out 0.3s forwards;margin-top:5px;background-color:rgba(255, 255, 255, 0.05);">
                    <div class="w3-col s1" style="padding:3px 6px;box-sizing:border-box;">
                        <i class="fas fa-clipboard w3-large"></i>
                    </div>
                    <div class="w3-col s8 aks-Records-btn-inner-txt aks-Records-module-font-12 ">
                        TRANSACTION ID
                    </div>
                    <div class="w3-col s3">
                        <span id="transacID__paym__tID"><?=$jsObj->TransID?></span>
                    </div>
            </div>
            <!-- <div class="w3-row w3-round aks-app-color  aks-Records-res-cnt cor-fadein-cnt" style="opacity:0;position: relative;animation: goOutin 0.7s ease-in-out 0.6s forwards;margin-top:5px;background-color: var(--app-dark-mode-gray-100)!important;">
                    <div class="w3-col s1" style="padding:3px 6px;box-sizing:border-box;">
                        <i class="fas fa-file-alt w3-large"></i>
                    </div>
                    <div class="w3-col s6 aks-Records-btn-inner-txt aks-Records-module-font-12 ">
                        REGISTRATION N0
                    </div>
                    <div class="w3-col s5">
                        <span id="transacID__paym">AK18/ENG/AEE/005</span>
                    </div>
            </div> -->
            <div class="w3-row w3-round aks-app-color  aks-Records-res-cnt cor-fadein-cnt" style="opacity:0;position: relative;animation: goOutin 0.7s ease-in-out 0.9s forwards;margin-top:5px;background-color:rgba(255, 255, 255, 0.05);">
                    <div class="w3-col s1" style="padding:3px 6px;box-sizing:border-box;">
                        <i class="fas fa-file-alt w3-large"></i>
                    </div>
                    <div class="w3-col s11 aks-Records-btn-inner-txt aks-Records-module-font-12 ">
                        <?=$jsObj->itemPaid?>
                    </div>
            </div>
            <div class="cor-margin-top w3-center">
                            <button id="prevBtnSend" onclick="Records.Printer.printConfrimSlip();" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt come-slide-toup cor-play-heart-beat aks-Records-color aks-Records-chos-bgr w3-circle w3-display-container" style="width:70px;margin:auto;height:70px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="mbri-print w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
            </div>
        </div>
    </div>
</div>