<?php
require_once "../../engine/Robot.php";
$getJall = json_decode($_POST['data']);
$setup = $_->Select("fac_tb","*","1=1");
if($setup[1] > 0){
	$tr = '';
	$rstT = $_->Select("result_tb","ID","1=1");
	$rstProg = $_->Select("programme_tb","ProgID ","1=1");
	$arrIndx = [];
	while($row = $setup[0]->fetch_assoc()){
		// $rst = $_->Select("result_tb","ID","FacID = ".trim($row['FacID'])." AND Active = 1");
		// $totalBars = ($rst[1]/$rstT[1])*100;
		// $arrIndx[] = [trim($row['FacName']),$totalBars];
		$tr.='
			<div class="w3-margin-top">
				<div class="aks-Records-font-11" style="display:flex;">
					<div id="TNumberr" style="width:90%">'.strtoupper($row['FacName']).'</div>
					<div class="'.$row['DashboardTextColor'].'" style="width:10%">100%</div>
				</div>
				<div class="cv2-progres-bars-cnt">
					<div id="getTDECr" class="'.$row['DashboardColor'].' cv2-intrnal-border" style="width:100%;"></div>
				</div>
			</div>
		';
	}
}
// total number of participant
$setPart = $_->Select("appusers_tb","ID","1=1");
// total number of report
$setRep = $_->Select("report_tb","ID","1=1");
// total report
$setMinut = $_->Select("minute_tb","ID","1=1");
$arrIndx[] = ["Total Faculties",$setup[1]];
$arrIndx[] = ["Total Programmes",$rstProg[1]];
$arrIndx[] = ["Total Result",$rstT[1]];
$arrIndx[] = ["Total Minutes",$setMinut[1]];
$arrIndx[] = ["Total Reports",$setRep[1]];
$TB = '
<div id="btn5" class="gss-parElem-sinlings w3-text-white  w3-animate-opacity" style="width: 99.6%;margin:auto;height:100%;overflow:auto;position:relative;display:block;padding:12px;background-color:#1c1a1a;">
	<div class="w3-row">
		<div class="w3-col m8">
			<div class="w3-row">
                <div class="tel-dashboard-td  w3-display-container " style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.7s;animation-fill-mode: forwards;opacity:0;">
                    <div class="tel-dashboard-td-inner-da">
						<div class="w3-col s3 w3-center">
							<div class="w3-row">
								<div class=" w3-center" id="shwReGPrinting12F">
									<div class="couxnter123F" style="position: relative; width:100%;height:89px">
										<canvas id="counter123F" class="aks-smr-canvas" style="position: absolute;z-index:2" width = "100%" height = "89"></canvas>
										<canvas id="counter123_bgF" width = "100%" height = "89"></canvas>
									</div>
								</div>
							</div>
							<div class="w3-row aks-Records-font-11">Total Faculties(<span id="totFac"></span>)</div>
						</div>
						<div class="w3-col s3 w3-center">
							<div class="w3-row">
								<div class="" id="shwReGPrinting12prog">
									<div class="couxnter123prog" style="position: relative; width:100%;margin:auto;height:89px">
										<canvas id="counter123prog" class="aks-smr-canvas" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
										<canvas id="counter123_bgprog" width = "100" height = "89"></canvas>
									</div>
								</div>
							</div>
							<div class="w3-row aks-Records-font-11">Total Programmes(<span id="totProg"></span>)</div>
						</div>
						<div class="w3-col s3 w3-center">
							<div class="w3-row">
								<div class="" id="shwReGPrinting12R">
									<div class="couxnter123R" style="position: relative; width:100%;margin:auto;height:89px">
										<canvas id="counter123R" class="aks-smr-canvas" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
										<canvas id="counter123_bgR" width = "100" height = "89"></canvas>
									</div>
								</div>
							</div>
							<div class="w3-row aks-Records-font-11">Total Result(<span id="totRes"></span>)</div>
						</div>
						<div class="w3-col s3 w3-center">
							<div class="w3-row">
								<div class="" id="shwReGPrinting12Min">
									<div class="couxnter123Min" style="position: relative; width:100%;margin:auto;height:89px">
										<canvas id="counter123Min" class="aks-smr-canvas" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
										<canvas id="counter123_bgMin" width = "100" height = "89"></canvas>
									</div>
								</div>
							</div>
							<div class="w3-row aks-Records-font-11">Total Minutes(<span id="totMinu"></span>)</div>
						</div>
					</div>
                </div>
            </div>
		</div>
		<div class="w3-col m4">
			<div class="tel-dashboard-td  w3-display-container w3-center" style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.8s;animation-fill-mode: forwards;opacity:0;">
				<div class="tel-dashboard-td-inner-da ">
					<div class="w3-row">
						<div class="" id="shwReGPrinting12pat">
							<div class="couxnter123pat" style="position: relative; width:100px;margin:auto;height:89px">
								<canvas id="counter123pat" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
								<canvas id="counter123_bgpat" width = "100" height = "89"></canvas>
							</div>
						</div>
					</div>
					<div class="w3-row aks-Records-font-11">Total Reports(<span id="totRport"></span>)</div>
				</div>
            </div>
		</div>
	</div>
	<div class="w3-row cor-margin-top">
		<div class="w3-col m6">
			<div class="w3-row">
                <div class="tel-dashboard-td-bigger  w3-display-container " style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.7s;animation-fill-mode: forwards;opacity:0;">
                    <div class="tel-dashboard-td-inner-da ">
						<div class="cor-border-bottom w3-row aks-Records-btn-inner-txt cor-text1-shaow aks-Records-module-font-12">
						FACULTY STATISTICS
						</div>
						<div id="getFacStatistics" class="w3-row cor-margin-top">

						</div>
					</div>
                </div>
            </div>
		</div>
		<div class="w3-col m6">
			<div class="tel-dashboard-td-bigger  w3-display-container " style="animation-name: fadeUp__;animation-duration: 1s;animation-delay: 0.8s;animation-fill-mode: forwards;opacity:0;">
				<div class="tel-dashboard-td-inner-da ">
					<div class="cor-border-bottom w3-row aks-Records-btn-inner-txt cor-text1-shaow aks-Records-module-font-12">
					CHART STATISTICS
					</div>
					<div class="cor-margin-top w3-center" id="facChart" style="width:100%;height:calc( 100% - 30px );overflow:auto;bax-shadow:var(--app-box-shadow);">
						
					</div>
				</div>
            </div>
		</div>
	</div>
</div>
';
die(json_encode([$TB,[["getFacStatistics",$tr]],["totFac",$setup[1]],["totProg",$rstProg[1]],["totRes",$rstT[1]],["totRport",$setRep[1]],[$arrIndx],["totMinu",$setMinut[1]],["getTextn",$setPart[1],"getTotalC","100%","getIntWidth","getHder","TOTAL SENATE MEMBERS"],["getdeTextn",$setRep[1],"TNumber","100%","getRptext","TOTAL REPORT","getTDEC"],["getadtext","TOTAL FACULTIES","getAddTextnR",$setup[1]],["totalprog","TOTAL PROGRAMMES","getNotaAddTextnR",$rstProg[1]],["totlresult","TOTAL RESULT","getAddTextn",$rstT[1]],["totMinu__","TOTAL MINUTES","getNotaAddTextn",$setMinut[1]]]));
?>