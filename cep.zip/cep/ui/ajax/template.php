<?php
$jsObj = json_decode($_POST['getJsonAtr']);
?>
<div class="aks-Records-all-width aks-Records-color " style="padding:15px;">
    <!-- template body MoleID-->
        <div style="width:100%;height:calc( 100% - 150px )">
            <div class="aks-Records-all-width">
                <div class= "cor-text1-shaow aks-Records-module-font-12">
                    APPLICATION FOR <span style="color:red;"><?=$jsObj->ModuleNme?></span>
                </div>
                <div class="w3-row w3-margin-top">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        NAME:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span><?=$jsObj->Name?></span>
                    </div>
                </div>
                <div class="w3-row">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        REGISTRATION NUMBER:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span><?=$jsObj->rgNumno?></span>
                    </div>
                </div>
                <div class="w3-row">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        DEPARTMENT:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span><?=$jsObj->Depat?></span>
                    </div>
                </div>
                <div class="w3-row">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        PROGRESS STATUS:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span style="color:red;"><?=$jsObj->trackProgress?></span>
                    </div>
                </div>
                <div class="w3-row">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        PHONE NUMBER:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span><?=$jsObj->Phonum?></span>
                    </div>
                </div>
                <div class="w3-row">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        DESTINATION ADDRESS:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span><?=$jsObj->DestinAdres?></span>
                    </div>
                </div>
                <div class="w3-row">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        POSTAGE TYPE:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span><?=$jsObj->pottype?></span>
                    </div>
                </div>
                <div class="w3-row">
                    <div class="w3-col l3 s6 m4 aks-Records-module-font-12">
                        DESTINATION STATE:
                    </div>
                    <div class="w3-col l9 s6 m8 aks-Records-font-11">
                        <span><?=$jsObj->dstitate?></span>
                    </div>
                </div>
            </div>
        </div>
    <!-- template footer -->
        <div style="width:100%;height:150px;">
            <div class="aks-Records-all-width">
                <div class="w3-row-padding">
                    <div onclick="Records.Engine.processRequest('<?=$jsObj->MoleID?>','<?=$jsObj->rgNumno?>','<?=$jsObj->msgboxdescr?>')" class="w3-col s4 w3-center">
                        <div class="aks-Records-proce-appl aks-app-proce-appl w3-display-container">
                            <i class="fas fa-print w3-display-middle w3-large"></i>
                        </div>
                        <div class="aks-Records-btn-inner-txt cor-text1-shaow aks-Records-font-11">PROCESS <span><?=$jsObj->ModuleNme?></span></div>
                    </div>
                    <div onclick="Records.APP.MainBody.trackAppliaction('<?=$jsObj->MoleID?>','<?=$jsObj->rgNumno?>','<?=$jsObj->ModuleNme?>')" class="w3-col s4 w3-center">
                        <div class="aks-Records-proce-appl aks-app-proce-appl w3-display-container ">
                            <i class="fas fa-map w3-display-middle w3-large"></i>
                        </div>
                        <div class="aks-Records-btn-inner-txt cor-text1-shaow aks-Records-font-11">MANAGE TRACKING</div>
                    </div>
                    <div class="w3-col s4 w3-center">
                        <div class="aks-Records-proce-appl aks-app-proce-appl w3-display-container ">
                            <i class="fas fa-user w3-display-middle w3-large"></i>
                        </div>
                        <div class="aks-Records-btn-inner-txt cor-text1-shaow aks-Records-font-11">NOTIFY APPLICANT</div>
                    </div>
                </div>
            </div>
        </div>
</div>
