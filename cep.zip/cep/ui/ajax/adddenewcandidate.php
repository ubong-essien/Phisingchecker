<?php
require_once "../../engine/Robot.php";
$rst = $_->Select("state_tb","*","1=1");
if($rst[1] > 0) {
    $TB ='<option value="" selected disabled>State</option>';
    while($row = $rst[0]->fetch_assoc()){
        $TB.='<option value="tr_'.$row['StateID'].'" >'.$row['StateName'].'</option>';
    }
}else{die("No set up");}
// subject
$rstSub = $_->Select("olvlsubj_tb","*","1=1");
if($rstSub[1] > 0) {
    $TBSub ='';
    while($rowSub = $rstSub[0]->fetch_assoc()){
        $TBSub.='<option value="tr_'.$rowSub['SubId'].'" >'.$rowSub['SubName'].'</option>';
    }
}else{die("No set up");}
// dept
$rstDept = $_->Select("programme_tb","ProgID,ProgName","1=1");
if($rstDept[1] > 0) {
    $TBDept ='<option value="" selected disabled>Department</option>';
    while($rowDept = $rstDept[0]->fetch_assoc()){
        $TBDept.='<option value="tr_'.$rowDept['ProgID'].'" >'.$rowDept['ProgName'].'</option>';
    }
}else{die("No set up");}
?>
<div class="aks-Records-all-width " style="padding:50px 0;overflow:auto;background-color:var(--app-black-livscore);">
    <div id="payInfo" class=" clxx aks-records-pding w3-animate-opacity w3-center" style="width:100%;height:100%;">
                <form action="javascript:void(0)" onsubmit="Telemedicine.Modules.AddCandidate.addNewCandidateDE()">
                    <div class="w3-row-padding adm-smr-margin-top">
                          <div class="w3-col m6 ">
                              <div class="aks-records-inpelem-cnt aks-records-border-bottom" style="opacity:0;animation: slidToup1 1s ease-in-out 0.1s forwards;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Name" id="tel_sur_name" required type="text" oninput="//__I.onInputUppc('getJReN_1__');" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Surname">
                              </div>
                          </div>
                          <div class="w3-col m6 adm-smr-margin-top">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.2s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Name" id="tel_fn_name" required type="text" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Firstname">
                              </div>
                          </div>
                    </div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m6">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.2s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <input title="Othername" id="tel_othr_names" required type="text" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Othername">
                                </div>
                          </div>
                          <div class="w3-col m6 adm-smr-margin-top">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.4s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Jamb Number" id="tel_jam_number" required type="text" oninput="//__I.onInputUppc('getJReN_1__');" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Jamb Number">
                              </div>
                          </div>
                    </div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m6">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.5s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <select id="getstate" title="State" onchange="Telemedicine.Modules.AddCandidate.loadLGA('getstate')" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                 <?=$TB?>
                              </select>
                              </div>
                          </div>
                          <div class="w3-col m6 adm-smr-margin-top">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.5s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="getLGA" title="LGA" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <option value="" selected disabled>LGA</option>
                                    </select>
                                </div>
                          </div>
                    </div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m6">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="getDpet" title="Department" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <?=$TBDept?>
                                    </select>
                              </div>
                          </div>
                          <div class="w3-col m6 adm-smr-margin-top">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.65s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select title="Mode of entry" required id="tel_modentry" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                            <option value="" selected disabled>Mode of entry</option>
                                            <option value="2">ND</option>
                                            <option value="3">HND</option>
                                    </select>
                              </div>
                        </div>
                    </div>
                    <div class="w3-row-padding cor-margin-top">
                          <div class="w3-col m6">
                              <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="getNationality" title="Nationality" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <option value="" selected disabled>Nationality</option>
                                        <option value="Nigeria">Nigeria</option>
                                        <option value="Non-Nigeria">Non-Nigeria</option>
                                    </select>
                              </div>
                          </div>
                          <div class="w3-col m6 adm-smr-margin-top">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.65s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <input title="DOB" id="adm__DoB" required type="text" oninput="__I.dateFormat('adm__DoB');" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="DOB e.g YYYY-MM-DD">
                              </div>
                            </div>
                    </div>
                        <!-- btn -->
                        <div class=" w3-center w3-margin-top">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-top w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat w3-pink aks-records-chos-bgr w3-circle w3-display-container" style="width:70px;margin:auto;height:70px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
    </div>
</div>
