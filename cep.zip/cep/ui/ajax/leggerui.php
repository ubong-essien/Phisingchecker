<?php
// sleep(1);
?>
<div class="w3-row aks-Records-all-width aks-record-bg-rst" style="padding:0px;">
    <div id="reduceWidth" class="w3-col m3  cor-fadein-cnt" style="position:relative;height:100%;box-shadow:0 3px 6px rgb(0 0 0 / 16%), 0 3px 6px rgb(0 0 0 / 23%);background-color: rgb(196, 209, 218);padding:10px 4px;">
        <div class="w3-row hidememenu w3-white w3-round cor-pointer w3-card aks-racords-display-ques-hover cor-fadein-cnt" style="height:auto;padding:0px;">
            <input id="on__input__" oninput="__I.onInputUppc('on__input__');Records.APP.searchStudent();" title="Search Name or Registration Number" class="w3-input w3-round" type="text" placeholder="Registration Number" style="width:100%;">
        </div>
        <div id="hideMeMenu" class=" w3-display-container" style="margin-top:5px;width:100%;height:300px;">
            <i id="idcog__fom" class="fas fa-cog fa-spin w3-center w3-display-middle w3-text-black w3-small" style="display:none;"></i>
            <div id="getdisplyinfo" class="w3-text-black" style="width:100%;height:100%;"></div>
        </div>
        <div onclick="Records.APP.collapseSidePanel('reduceWidth','removCogRule','iconRotateL','iconRotateR')" style="position:absolute;bottom:8px;width:100%;max-width:45px;height:45px;border-radius:50%;">
            <div title="Hide Side Panel" class="w3-grey w3-circle aks-Records-heart-beat cor-pointer w3-diplay-container" style="width:100%;height:100%;">
                <i id="iconRotateL" class="fas fa-angle-left cor-fadein-cnt w3-large w3-display-middle"></i>
                <i id="iconRotateR" class="fas fa-angle-right cor-fadein-cnt w3-large w3-display-middle" style="display:none;"></i>
            </div>
        </div>
    </div>
    <div id="removCogRule" class="w3-col m9 cor-fadein-cnt w3-display-container w3-text-black" style="height:100%;">
        <img src="../assets/images/rstupload.png" width="200" height="200" class="w3-display-middle" alt="photo">
    </div>
</div>