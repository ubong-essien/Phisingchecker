<?php
// sleep(1);
?>
<div class="aks-Records-all-width aks-Records-project-up" style="padding:20px;">
    <div class="w3-card-4 w3-center cor-center-cont aks-app-dept-upload-result">
        <div class="aks-Records-font-07 w3-text-white w3-margin-top">UPLOAD RESULT</div>
         <div class="aks-Records-all-width w3-display-container aks-Records-heart-beat">
             <!-- upload icon -->
                 <input id="x__xR__e" onchange="Records.APP.MainBody.DataEntry.uploadResults()" type="file" class="w3-blue" style="width:100%;height:200px;opacity:0;position:relative;cursor:pointer!important;z-index:4;">
                <div id="z_zr__" class="w3-display-middle"><i class="fa fa-upload w3-jumbo  w3-text-white "></i></div>
				<div id="hiCogJam__z" class="w3-display-middle" style="display:none;"><i class="fa fa-cog fa-spin w3-jumbo w3-text-white"></i></div>
              <!-- discription -->
         </div>
    </div>
    <!-- <div  class="aks-Records-font-11 w3-pink aks-app-result-data" style="position:absolute;max-width:120px;width:100%;left:50%;bottom:32%;transform:translate(-50%,-32%);text-align:center;border-radius:30px;padding:6px;">UPLOAD RESULT</div> -->
</div>