<?php
require_once "../../engine/Robot.php";
require_once "../../script/errormsg.php";
$rst = $_->Select("doctor_tb","*","1=1");
$TB = "<option value='' selected disabled>Doctor's Name</option>";
$TBsp = "<option value='' selected disabled>Doctor's Specialties</option>";
if($rst[1] > 0){
    while($row = $rst[0]->fetch_assoc()){
        $TB.='<option value="'.$row['ID'].'">'.$row['Name'].'</option>';
        $TBsp.='<option value="'.$row['Specialty'].'">'.$row['Specialty'].'</option>';
    }
}
?>
<div class="aks-Records-all-width " style="padding: 12px 15px;background-color:var(--app-black-livscore);overflow:auto;">
<div id="payInfo" class=" clxx aks-records-pding w3-animate-opacity w3-center" style="width:80%;margin:auto;height:100%;">
                  <h6>Patient Appointment Form</h6>
                    <form action="javascript:void(0)" onsubmit="Telemedicine.Modules.Patients.bookAppointment()">
                        <div class="w3-row-padding">
                            <div class="w3-col m6">
                            <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="tel_docName" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                    <?=$TB?>
                                    </select>
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                        <select required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <?=$TBsp?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="w3-row-padding cor-margin-top">
                            <div class="w3-col m6">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select required id="tel_doc_visited" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <option value="" selected disabled>Have You Visited This Doctor Before?</option>
                                        <option value="I am a new Patient" >I am a new Patient</option>
                                    </select>
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="tel_doc_stafstudent" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <option value="" selected disabled>Are You A Student/Staff?</option>
                                        <option value="Student" >Student</option>
                                        <option value="Staff" >Staff</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="w3-row-padding cor-margin-top">
                            <div class="w3-col m6">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="tel_doc_reasons" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <option value="" selected disabled>Visit Reasons?</option>
                                        <option value="Illness" >Illness</option>
                                    </select>
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="tel_doc_appointmnt" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <option value="" selected disabled>Who Is This Appointment For?</option>
                                        <option value="Me" >Me</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="w3-row-padding cor-margin-top">
                            <div class="w3-col m6">
                                <div class="aks-records-inpelem-cnt  aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.3s both;height: 45px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <select id="tel_doc_schedulname" required class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;">
                                        <option value="" selected disabled>Schedule Name?</option>
                                        <option value="General Medical" >General Medical</option>
                                    </select>
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div id="emlae" class="w3-row aks-records-inpelem-cnt aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.8s both;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;height:44.60px!important;">
                                    <input title="Would You Like To Chat With Doctor? If Yes Enter Time Below(e.g 9:30)" id="tel_doc_timetomdoc" required type="text" class="w3-input aks-records-heart-beat det__nat__email adm-input-jm putme-card " style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="What Time Do You Wish To Chat With Doctor?">
                                </div>
                            </div>
                        </div>
                        <div class="w3-row-padding cor-margin-top">
                            <div class="w3-col m12">
                                <div id="emlae" class="w3-row aks-records-inpelem-cnt aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.8s both;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);border-top-left-radius: var(--app-width-5);border-top-right-radius: var(--app-width-5);padding:var(--app-width-4);border-bottom: 2px solid var(--app-blue-40)!important;">
                                    <input title="Description Your Illness" id="tel_doc_illness" required type="text" class="w3-input aks-records-heart-beat det__nat__email adm-input-jm putme-card " style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Description Your Illness">
                                </div>
                            </div>
                        </div>
                        <!-- btn -->
                        <div class=" w3-center w3-margin-top">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat w3-pink aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
                </div>
</div>
