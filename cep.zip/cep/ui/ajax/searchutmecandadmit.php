<?php //sleep(1);?>
<div id="btn2" class="gss-parElem-sinlings" style="width: 100%;height:100%;overflow:auto;position:relative;display:block;padding:2px;">
	<div class="w3-animate-opacity w3-display-container" style="width:100%;height:inherit;">
			<!--  #ece2e200!important; -->
			<div class="" style="height:100%;position:relative;">
				<div class="" style="width:100%;height:53px;">
					<div class="aks-records-inpelem-cnt aks-records-border-bottom-" style="opacity:0;animation: slidToup1 1s ease-in-out 0.1s forwards;height: inherit;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);padding:var(--app-width-8);border-bottom: 2px solid var(--app-blue-40)!important;">
                              <input title="Name" id="getJReN_1" required type="text" oninput="__I.onInputUppc('getJReN_1');Telemedicine.Modules.AdmissionList.searchByJmOnInput()" class="w3-input adm-input-jm putme-card aks-records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Search by Jamb Number">
                              </div>
				</div>
				
				<div id="dis_admited_4" class="putme-card" style="width:100%;position:relative;overflow:auto;z-index:3;display:none;margin-top:2px;border-top-left-radius:-20px;border-bottom-left-radius:2px;border-bottom-right-radius:2px;"></div>
				
			</div>
			<div id="adm_ed_cog_2" class="w3-display-middle" style="display:none;"><i class="fas fa-spinner fa-pulse w3-text-indigo w3-xxlarge"></i></div>
	</div>
</div>