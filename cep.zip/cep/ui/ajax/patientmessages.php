<div id="btn5" class="gss-parElem-sinlings w3-text-white  w3-animate-opacity" style="width: 100%;height:100%;overflow:auto;position:relative;display:block;padding:2px;">
<?php
error_reporting(0);
require_once "../../engine/Robot.php";
require_once "../../engine/sha3encryptdecriptold.php";
// Store the cipher method
$ciphering = "AES-128-CTR";
// Store the encryption key
$encryption_key = "Antman123456@#TELEMEDiCINE~@";
 $getR_r = $_->Select("patientappointment_db p,patient_tb pat,doctor_tb d", "p.*,pat.Name as Pname,pat.Gender as Gender,pat.DOB as DOB,d.Name as docName,d.Passport as pasport,d.Profession as profession,d.Specialty as specialty", "PatientID = ".trim($_->SqlSafe($_POST['param']))." AND p.PatientID = pat.ID AND p.Active = 1 AND p.DoctorID = d.ID");
 if ($getR_r[1] > 0) {
	 $cnt = 1;
	 $cnt_1 = 0;
	 $oupTB = <<<_E
			 <ul class="w3-center"><li class="cor-border-bottom">
			 <div class="w3-row w3-small">
				 <div class="w3-col s1 cor-text1-shaow spt-header-smr">S/N</div>
				 <div class="w3-col s2 cor-text1-shaow spt-header-smr">PATIENT NAME</div>
				 <div class="w3-col s3 cor-text1-shaow spt-header-smr">VISIT REASON</div>
				 <div class="w3-col s2 cor-text1-shaow spt-header-smr">DESCRIPTION</div>
				 <div class="w3-col s3 cor-text1-shaow spt-header-smr">CHAT TIME</div>
				 <div class="w3-col s1 cor-text1-shaow spt-header-smr">VIEW TREATMENTS</div>
			 </div>
		 </li>
_E;
	 while ($row = $getR_r[0]->fetch_assoc()) {
		 $pName = trim($row['Pname']);
		 $docName = trim($row['docName']);
		 $docPassport = trim($row['pasport']);
		 $docProfession = trim($row['profession']);
		 $docSpecialty = trim($row['specialty']);
		 $VisitReasons = trim(word_teaser($row['VisitReasons'],4));
		 $Description = $row['Description']; //08066559566
		 $DescriSend = trim($row['Description']); //08066559566
		 $chatTime = $row['AppointmentTime']; //Enefiok ucfirst()
		 $chatTime2 = $row['AppointmentTime']; //Enefiok ucfirst()
		 $scheduleName = trim( $row['ScheduleName']);
		 $gender = trim($row['Gender']);
       $chatTime = decryptSH3($chatTime);
       $Description = decryptSH3($Description);
		 $UserID = trim($row['PatientID']);
		 $userappID = trim($row['ID']);
		 $patDOB = trim($row['DOB']);
		 $docID = trim($row['DoctorID']);
		 $docPrescription = $row['DoctorsPrescription'];
		 $approved = trim($row['ApprovedChat'])==1?'APPROVED':'REJECTED';
		 $oupTB .= <<<_E
				 <li id="li_id_$UserID" onclick="Telemedicine.Modules.Patients.readPrescription('getEncrData_$UserID')"  class="cor-border-bottom come-slide-toup$cnt_1 cor-ul-fix cor-pointer rep-bgr-hover  cor-fadein-cnt" style="opacity:0;position:relative; padding:10px 0">
					 <div id="getEncrData_$UserID" class="w3-row" data-encripted='{"pName":"$pName","visitedR":"$VisitReasons","describeIllnes":"$DescriSend","scheduleName":"$scheduleName","patientSupliedTime":"$chatTime2","gender":"$gender","patDOB":"$patDOB","patientUserID":$UserID,"userappID":$userappID,"doctName":"$docName","docPasport":"$docPassport","profession":"$docProfession","specialty":"$docSpecialty","chatApprovd":"$approved","docID":$docID,"doctPrescription":"$docPrescription"}'>
						 <div class="w3-col s1 cor-text1-shaow cor-header-smr">$cnt</div>
						 <div class="w3-col s2 cor-text1-shaow cor-header-smr">$pName</div>
						 <div class="w3-col s3 cor-text1-shaow cor-header-smr">$VisitReasons</div>
						 <div class="w3-col s2 cor-text1-shaow cor-header-smr">$Description</div>
						 <div class="w3-col s3 cor-text1-shaow cor-header-smr">$chatTime</div>
						 <div class="w3-col s1 cor-text1-shaow cor-header-smr cor-pointer"><i title="" class="fas fa-ellipsis-h"></i></div>   
					 </div>
				 </li>
_E;

		 if ($cnt_1 == 6) {
			 $cnt_1 = 0;
		 }
		 $cnt++;
		 $cnt_1++;
	 }
	 $oupTB.='</ul>';
	 echo $oupTB;
 }
// return str
function word_teaser($string, $count){
    $original_string = $string;
    $words = explode(' ', $original_string);
   
    if (count($words) > $count){
     $words = array_slice($words, 0, $count);
     $string = implode(' ', $words);
    }
   
    return $string;
  }
?>
</div>