<div class="aks-Records-all-width aks-Records-color" style="padding:5px;">
    <div class="aks-transcript-cnt aks-Records-project-up">
        <div class="aks-Records-all-width">
            <div class="w3-row" style="width:100%;height:36px;border-bottom:solid thin var(--app-orange-livscore);position:relative;">
                <div class="w3-col s6 cor-pointer">
                    <div onclick="Records.Engine.rebootAction('payInfo','btnr_1')" style="padding:1px;">
                        <div class="w3-center aks-Records-btn-inner-txt aks-Records-hover-mudule-1 cor-fadein-cnt aks-Records-font-11" style="width:100%;height:32px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);padding:5px;">
                            PAMENT INFORMATION
                        </div>
                    </div>
                </div>
                <div class="w3-col s6 cor-pointer">
                    <div style="padding:1px;">
                        <div onclick="Records.Engine.rebootAction('alreadyPay','btnr_2')" class="w3-center aks-Records-hover-mudule-1 cor-fadein-cnt aks-Records-btn-inner-txt aks-Records-font-11" style="width:100%;height:32px;background-color: var(--app-dark-mode-gray-90);box-shadow: var(--app-box-shadow-high);;padding:5px;">
                            ALREADY PAID?
                        </div>
                    </div>
                </div>
                <div id="rootID" class="aks-Records-chos-bgr cor-fadein-cnt" style="position:absolute;bottom:1px;left:25%;width:6px;height:6px;border-radius:50%;"></div>
            </div>
            <div id="getAllBody" style="width:100%;height:calc( 100% - 36px );">
            <!-- make payment -->
                <div id="payInfo" class="aks-Records-all-width clxx aks-Records-pding w3-animate-opacity">
                    <form action="javascript:void(0)" onsubmit="Records.Engine.MainUser.maintainLead()">
                        <div class="aks-Records-inpelem-cnt aks-Records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.2s both;">
                            <input title="REGISTRATION NUMBER" id="getJReN_1__" required type="text" oninput="__I.onInputUppc('getJReN_1__');" class="w3-input adm-input-jm putme-card aks-Records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Registration Number">
                        </div>
                        <div id="destinaddress" class="aks-Records-inpelem-cnt aks-Records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.21s both;">
                            <input title="PHONE NUMBER" id="__phon__no" type="text" required class="w3-input  adm-input-jm putme-card aks-Records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Phone Number">
                        </div>
                        <div id="emlae" class="w3-row aks-Records-inpelem-cnt aks-Records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.24s both;">
                            <input title="EMAIL" id="personal__ema__" required type="email" class="w3-input aks-Records-heart-beat adm-input-jm putme-card " style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Personal Email">
                        </div>
                        <div class="w3-row aks-Records-inpelem-cnt aks-Records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;">
                            <input title="DESTINATION ADDRESS" id="d__adres__" required type="text" oninput="__I.onInputUppc('getJReN_1');" class="w3-input det__nat__adres aks-Records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Destination Address">
                        </div>
                        <div class="w3-row aks-Records-inpelem-cnt aks-Records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.23s both;">
                            <input title="POSTAGE TYPE" id="ps__post__" required type="text" class="w3-input det__nat__postadre adm-input-jm putme-card aks-Records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Postage Type">
                        </div>
                        <div id="emlae" class="w3-row aks-Records-inpelem-cnt aks-Records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.24s both;">
                            <input title="EMAIL" id="ps__ema__" required type="email" class="w3-input aks-Records-heart-beat det__nat__email adm-input-jm putme-card " style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Destination Email">
                        </div>
                        <div id="destin__state" class="w3-row aks-Records-inpelem-cnt  aks-Records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.25s both;">
                            <input title="DESTINATION STATE" readonly id="getdestState_1" type="text" onclick="Records.RightController.loadState('getdestState_1');" class="w3-input aks-Records-heart-beat det__nat__state adm-input-jm putme-card " style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Destination State" required>
                        </div>
                        <div id="__destinst__address" style="margin-top: 0px;"></div>
                        <div class="w3-row" style="margin-top:5px;">
                            <div class="w3-col s11">&nbsp;</div>
                            <div class="w3-col s1">
                                 <div onclick="__I.CloneElement.cloneAnElemnt('destinaddress','__destinst__address','Destination State',-1)" title="ADD ANOTHER DESTINATION ADDRESS" class="w3-circle w3-yellow inv-hover-addit ngo-bgr-col-items w3-card-4 aks-Records-heart-beat w3-display-container cor-fadein-cnt  ngo-bgr-col cor-pointer" style="padding:5px 11px;width:22px;margin:auto;height:22px;border-radius:50%;opacity:0;animation: slidToup1 1s ease-in-out 0.26s both;"><i class="fas fa-plus w3-small w3-display-middle"></i></div>
                            </div>
                        </div>
                        <!-- accept and continue -->
                        <div id="" class="w3-row cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.28s both;">
                            <div class="w3-col s1">
                                <input id="__rdbtn__chk" type="radio" class="w3-radio">
                            </div>
                            <div class="w3-col s11">
                                <div style="margin-top:7px;">
                                    <i>Click Here To Agree With Our <a title="Click To Read Terms And Conditions" class=" aks-Records-btn-inner-txt aks-Records-font-13 " href="javascript:Records.Engine.MainUser.termsCondition()" rel="noopener noreferrer">Transcript Policy</a></i>
                                </div>
                            </div>
                        </div>
                        <!-- btn -->
                        <div class="cor-margin-top w3-center">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-Records-color aks-Records-chos-bgr w3-circle w3-display-container" style="width:70px;margin:auto;height:70px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="fas fa-long-arrow-alt-right w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
                </div>
                <!-- already Paid -->
                <div id="alreadyPay" class="aks-Records-all-width clxx aks-Records-pding w3-animate-opacity" style="display:none">
                    <div class="aks-Records-inpelem-cnt aks-Records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.2s both;">
                        <input title="PAYMENT REFERENECE NUMBER" id="getJReN_1" type="text" oninput="__I.onInputUppc('getJReN_1');GEN.Admin.indexPage.searchByJmOnInput()" class="w3-input adm-input-jm putme-card aks-Records-heart-beat" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Payment Reference Number">
                    </div>
                    <!-- btn -->
					<div class="cor-margin-top w3-center">
                        <button id="prevBtnSend" title="Previous" onclick="" class="w3-button  cor-fadein-cnt cor-play-heart-beat aks-Records-color aks-Records-chos-bgr w3-circle w3-display-container" style="width:70px;margin:auto;height:70px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                            <i id="NextBtn" title="Next" class="fas fa-long-arrow-alt-right w3-large w3-display-middle" style="display:block;"></i>
                                        <div id="showProgress" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                            <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                            <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                            <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                            </div>
                                        </div>
                        </button>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>
