<div id="btn6" class="gss-parElem-sinlings" style="width: 100%;height:100%;overflow:auto;position:relative;display:block;">
<?php
	require_once "../../engine/Roboti.php";
	$getsubj = $_P->Select("programme_tb","ProgID,ProgName");
	$output = "";
	if($getsubj[1] > 0){
		$output.='<option value="" disabled selected>Select Department</option>';
		while($rowSubj = $getsubj[0]->fetch_assoc()){
		$output.="<option value='pID_".$rowSubj['ProgID']."'>".$rowSubj['ProgName']."</option>";
		}
	}
?>
<!-- background-color: rgb(236, 234, 234); -->
<div class="w3-animate-opacity" style="width:100%;padding:5px;">
	<div class="w3-row-padding">
		<div class="w3-col m3 ">
				<form action="javascript:void(0)" onsubmit="Telemedicine.Modules.AdmissionList.viewAdmitDEedList()">
						<div class="w3-row">
							<select title="SELECT DEPARTMENT" id="get_D1DE_adList" class="w3-select w3-border" style="cursor:pointer;background-color:rgba(255, 255, 255, 0.267)!important;border:none!important;outline:0!important;height:inherit;margin-top:1px;">
								<?= $output?>
							</select>
						</div>
						<div class="w3-row" style="margin-top:1px;">
							<button class="w3-transparent w3-button w3-border w3-hover-none" style="background-color:rgba(255, 255, 255, 0.267)!important;border:none!important;outline:0!important;">
								<div class="w3-display-container" style="width:45px;height:65px;margin-top:5px;cursor:pointer;"><span id="v_adDE_btn" class="w3-display-middle w3-text-black">SUBMIT</span><span id="u_cogRsrDE_v" class=" w3-display-middle" style="display:none;"><i class="fa fa-cog fa-spin w3-xxlarge w3-text-black"></i></span></div>
							</button>
						</div>
				</form>
		</div>
		<div class="w3-col m9">
			<div id="id_1_DEdpt_view">
				<div id='dp_DE12_view' class="w3-center w3-black w3-text-white" style="margin-top:1px;width:100%;padding:4px;display:none;border:solid thin #ddd;">
					<div class="adm-disp-inline "><strong>DEPARTMENT OF</strong></div> <strong class="adm-disp-inline" id="di_DEdpt_view"></strong>
				</div>
				<div id="di_DEview_list" style="width:100%;height:320px;overflow:auto;"></div>
				<div id="pr_DEbtn" class="w3-row" style="margin-top:1px;display:none;">
					<button id="getBtnCDe" title="PRINT ADMISSION LIST" class="w3-transparent w3-right w3-button w3-border w3-hover-none" style="background-color:white!important;">
						<div class="w3-display-container" style="width:45px;height:65px;cursor:pointer;"><span id="v_ad_btRRn" class="w3-display-middle w3-text-black">PRINT</span><span id="u_coDDgRsr_v" class=" w3-display-middle" style="display:none;"><i class="fa fa-cog fa-spin w3-xxlarge w3-text-black"></i></span></div>
					</button>
				</div>
			</div>
		</div>
	</div>
</div>
</div>