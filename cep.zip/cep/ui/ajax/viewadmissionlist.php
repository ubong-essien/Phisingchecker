<?php
require_once "../../engine/Roboti.php";
	$getsubj = $_P->Select("programme_tb","ProgID,ProgName");
	$output = "";
	if($getsubj[1] > 0){
		$output.='<option value="" disabled selected>Select Department</option>';
		while($rowSubj = $getsubj[0]->fetch_assoc()){
		$output.="<option value='pID_".$rowSubj['ProgID']."'>".$rowSubj['ProgName']."</option>";
		}
	}
?>
<div id="btn4" class="gss-parElem-sinlings w3-animate-opacity" style="width: 100%;height:100%;overflow:hidden;position:relative;display:block;padding:5px;">
<!-- background-color: rgb(236, 234, 234); -->
<div class="w3-animate-opacity" style="width:100%;height:100%;">
	<div class="w3-row">
		<div class="w3-col m3 aks-Records-module-font">
				<form action="javascript:void(0)" onsubmit="Telemedicine.Modules.AdmissionList.viewAdmitedList()">
						<div class="w3-row">
							<select title="SELECT DEPARTMENT" id="get_D1_adList" class="w3-select w3-border" style="cursor:pointer;background-color:rgba(255, 255, 255, 0.267)!important;border:none!important;outline:0!important;height:inherit;margin-top:1px;">
								<?= $output?>
							</select>
						</div>
						<div class="w3-row" style="margin-top:1px;">
							<button class="w3-transparent w3-button w3-border w3-hover-none" style="background-color:rgba(255, 255, 255, 0.267)!important;border:none!important;outline:0!important;">
								<div class="w3-display-container" style="width:45px;height:65px;margin-top:5px;cursor:pointer;"><span id="v_ad_btn" class="w3-display-middle w3-text-black">SUBMIT</span><span id="u_cogRsr_v" class=" w3-display-middle" style="display:none;"><i class="fa fa-cog fa-spin w3-xxlarge w3-text-black"></i></span></div>
							</button>
						</div>
				</form>
		</div>
		<div class="w3-col m9 app-smr-cnt w3-hide">
			<div title="Close" class="adm-smr-bgr w3-hide rr__rr w3-hide-large" onclick="document.getElementsByClassName('app-smr-cnt')[0].classList.add('w3-hide');document.getElementsByClassName('rr__rr')[0].classList.add('w3-hide');" style="position:absolute;top:5px;right:10px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 250);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow);z-index:10;">
                  <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                      <i class="fas fa-times w3-small w3-display-middle"></i>
                  </div>
            </div>
			<div id="id_1_dpt_view" style="width:100%;height:100%;padding: 0 2px;">
				
				<div id='dp_12_view' class="w3-center w3-black w3-text-white" style="margin-top:1px;width:100%;padding:4px;display:none;border:solid thin #ddd;">
					<div class="adm-disp-inline "><strong>DEPARTMENT OF</strong></div> <strong class="adm-disp-inline" id="di_dpt_view"></strong>
				</div>
				<div id="di_view_list" style="width:100%;height:500px;overflow:auto;"></div>
				<div id="pr_btn" class="w3-row" style="margin-top:1px;display:none;">
					<button id="getBtnC" onclick="" title="PRINT ADMISSION LIST" class="w3-transparent w3-right w3-button w3-border w3-hover-none" style="background-color:white!important;">
						<div class="w3-display-container" style="width:45px;height:65px;cursor:pointer;"><span id="v_ad_btn" class="w3-display-middle w3-text-black">PRINT</span><span id="u_cogRsr_v" class=" w3-display-middle" style="display:none;"><i class="fa fa-cog fa-spin w3-xxlarge w3-text-black"></i></span></div>
					</button>
				</div>
			</div>
		</div>
	</div>
</div>
</div>