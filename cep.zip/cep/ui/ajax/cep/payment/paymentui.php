<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
$cnt = 1;
$cnt1 = 0;
$TB = '<div class="cep__pageCount" data-titlename=\'{"titleName":"REGISTER NOW"}\'><div class="w3-row-padding aks-records-color">';
foreach($getJsonFile as $key => $val){
    $TB.='
    <div class="w3-col m6 w3-center">
        <div class="aks-racords-pay__pay cep-marg-top-smr cor-pointer aks-app-color w3-round w3-display-container" onclick="CEP.Modules.Payment.commitPay('.$val[1].',\''.$val[0].'\')" style="animation: projectUp 0.8s forwards ease-in-out 0.2s;background-color:#222!important;">
            <div class="w3-display-middle" style="min-width:100%;">
                <div style="font-size: 1.31em;color: #aaa;font-weight:300;">PAY</div>
                <div class="aks-Records-btn-inner-txt" style="font-size: 1.3em;"><span class="w3-small w3-text-green">NGR</span> '.number_format($val[1],2).'</div>
                <div id="getAmt__" class="w3-small" style="font-size: 1em;color: #aaa;font-weight:100;">'.$val[0].'</div>
            </div>
        </div>
    </div>';
    if($cnt == 2){
    	$TB.='</div>';
    	$cnt = 0;
    	$TB.= '<div class="w3-row aks-records-color">';
    }
    $cnt++;
    $cnt1++;
}
$TB.='</div></div>';
?>
<div id="getAllBody" class="cep__pageCount" data-titlename='{"titleName":"MAKE PAYMENT"}' style="width:100%;margin:auto;height:100%;padding:20px;overflow:auto;">
    <div style="width:300px;margin:auto;height:200px;padding:20px;">
        <img src="assets/images/p2.png" alt="photo" width="100%" height="100%">
    </div>
    <div id="" class="w3-animate-opacity" style="width:70%;margin:auto;height:calc( 100% - 220px );padding:5px;">
        <div id="" class="w3-center cep-font-1em w3-margin">Confirm payment</div>
        <?=$TB?>
    </div>
</div>