
<?php
	require_once "../../../engine/Robot.php";
    $getJsonFile = json_decode($_POST['data']);
	$rst = $_->Select("progmodules_tb",'*',"Active = 1");
	if($rst[1] > 0){
		$cnt = 1;
		$cnt1 = 0;
		$TB = '<div class="cep__pageCount" data-titlename=\'{"titleName":"REGISTER NOW"}\'><div class="w3-row aks-records-color">';
			while($row = $rst[0]->fetch_assoc()){
				$TB.='
				<div class="w3-col m4">
					<div title="'.$row['Title'].'" id="tr_'.$row['ID'].'" onclick="CEP.Modules.Stabilizer.startNow(\''.$row['Name'].'\',\'progID_'.$row['ID'].'\',\''.$row['Description'].'\',\''.$row['URL'].'\',\'fixClor_'.$row['ID'].'\')" class="w3-row cor-fadein-cnt aks-btn-width-height aks-records-hover-mudule aks-cl-comp cor-pointer aks-records-order-hover-cnt" style="padding:5px;">
						<div class="w3-col s2 m3">
							<div class="cep-records-ordering-cnt">
                                <div class="cep-icon-indic '.$row['ColorTxt'].' w3-display-container" style="animation: projectUp 1s forwards ease-in-out 0.'.$cnt1.'s;box-shadow:var(--app-box-shadow);">
                                <i class="'.$row['Icon'].' w3-display-middle  w3-xlarge"></i>
                                </div>
                            </div>
						</div>
						<div class="w3-col s10 m9">
							<div style="padding:10px;">
								<div class="xxx cep-font-em">'.$row['Name'].'</div>
								<div id="fixClor_'.$row['ID'].'" class="w3-small aks-records-color xxyy aks-font-hova cor-fadein-cnt">'.$row['Description'].'</div>
							</div>
						</div>
					</div>
				</div>';
				if($cnt == 3){
					$TB.='</div>';
					$cnt = 0;
					$TB.= '<div class="w3-row aks-records-color">';
				}
				$cnt++;
				$cnt1++;
			}
		$TB.='</div></div>';
		
	}else{
	  $TB = "error...";
	}
    die(json_encode(["SUCCESS" => ["Message" => $TB,"Namedescrip" => "Programmes"]]));
?>

 