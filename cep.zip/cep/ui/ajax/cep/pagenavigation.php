<?php
$pages = [
    "ui/ajax/cep/pages/verification.php",
    "ui/ajax/cep/pages/basicdetails.php",
    "ui/ajax/cep/pages/paymentoption.php",
    "ui/ajax/cep/pages/contactinfo.php",
    "ui/ajax/cep/pages/academicdetails.php",
    "ui/ajax/cep/pages/finish.php"
];
?>