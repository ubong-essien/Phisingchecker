<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data'],true);
// print_r($getJsonFile);die;
$TB = '<div class="">';
foreach($getJsonFile as $value){
    // print_r($value['Lvl']);die;
    // echo $value;
    $TB.='<div class="w3-row cep-parEl aks-records-inpelem-cnt aks-Records-module-font-light cor-pointer aks-records-border-bottom-" onclick="" style="padding:13px;animation:app__module 0.9s both ease-in-out 0.1s;box-shadow: var(--app-box-shadow);margin-top:2px;">
    <div class="w3-col s8">'.$value['Lvl'].'00~'.$value['Sem'].'~'.$value['Ses'].'</div>
    <div class="w3-col s2"><span class="w3-text-green" style="font-size:0.75em;"></span>'.$value['cdate'].'</div>
    <div title="Print Course" onclick="Records.Printer.admitToday(\'idGet_ui\',\'script/printers/slip.php?s_t=\'+'.$value['CID'].'+\'&separator=\'+10);" class="w3-col s1"><span class="fas fa-print w3-right" style="font-size:0.85em;padding:5px 0;"></span></div>
    <div title="Edit course" onclick="" class="w3-col s1"><span class="mbri-edit w3-right" style="font-size:0.85em;padding:5px 0;"></span></div>
</div>';
}
$TB.='</div>';
// die($TB);
?>
<div class="cep__pageCount" data-titlename='{"titleName":"REFERENCE"}' style="width:100%;max-width:600px;margin:auto;height:100%;padding:12px;">
                <div style="width:300px;margin:auto;height:200px;padding:5px;">
                    <img src="assets/images/finish.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Course history</div>
                    <?=$TB?>
                    <br>
                </div>
</div>