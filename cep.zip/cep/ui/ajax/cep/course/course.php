<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data'],true);
// print_r($getJsonFile);
// die;
$cnt = 1;
$TB = '<div class="cep__pageCount" data-titlename=\'{"titleName":"COURSE REGISTRATION"}\'><div class="cep-course-tb-color w3-row cep-parEl aks-Records-btn-inner-txt w3-small" style="width:100%;padding:4px;"><div class="w3-col s1">&nbsp;</div><div class="w3-col s3" style="padding:4px;">CODE</div><div class="w3-col s7" style="padding:4px;">TITLE</div><div class="w3-col s1" style="padding:4px;"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CH</span></div></div><table class="w3-white" style="width:100%;font-size: 0.9em!important;">';
foreach($getJsonFile as $key => $val){
    $TB.='<tr onclick="CEP.Modules.Course.computeCourseReg('.$val['CourseID'].','.$val['CH'].',\''.strtoupper($val['Title']).'\',\''.$val['CourseCode'].'\')" class="cor-pointer cep-tb-hover cor-fadein"><td><div style="padding:4px;">'.$cnt.'</div></td><td><div style="padding:4px;">'.$val['CourseCode'].'</div></td><td><div style="padding:4px;">'.strtoupper($val['Title']).'</div></td><td><div class=" cep-course-cnt w3-display-container" style="padding:4px;"><span id="courseCID_'.$val['CourseID'].'" class="w3-display-middle cep-txt-top">'.$val['CH'].'</span></div></td></tr>';
    $cnt++;
}
$TB.='</table><div class="cep-course-tb-color- w3-white cep-parEl" style="width:100%;padding:4px;"><span class="w3-center aks-Records-btn-inner-txt w3-small" style="text-transform: uppercase;">&nbsp;&nbsp;&nbsp;Selected: <span id="spnSel">0</span></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="w3-center aks-Records-btn-inner-txt w3-small" style="text-transform: uppercase;">Total CH: <span id="spnTch">0</span></span></div></div>';
?>
<div id="getAllBody" class="cep__pageCount" data-titlename='{"titleName":"MAKE PAYMENT"}' style="width:100%;margin:auto;height:100%;padding:20px;overflow:auto;">
    <div style="width:300px;margin:auto;height:170px;">
        <img src="assets/images/basic5.png" alt="photo" width="100%" height="100%">
    </div>
    <div id="" class="w3-animate-opacity" style="max-width:600px;margin:auto;height:calc( 100% - 170px );padding:5px;">
        <div id="" class="w3-center cep-font-1em w3-margin">Register courses</div>
        <form action="javascript:void(0)" onsubmit="CEP.Modules.Course.sendSelectedCourses()">
            <div><?=$TB?></div>
            <!-- btn -->
            <div class="w3-margin-top w3-center">
                                <button id="prevBtnSend" title="Previous" class="w3-button adm-dontclose1 w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                    <i id="NextBtn__pages__acad1" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                                <div id="showProgress__pages__acad1" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                    <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                    <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                    <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                    </div>
                                                </div>
                                </button>
            </div>
        </form>
    </div>
</div>