<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data'],true);
$TB = '<div class="">';
foreach($getJsonFile as $value){
    // print_r($value);die;
    // echo $value;
    $TB.='<div class="w3-row cep-parEl aks-records-inpelem-cnt aks-Records-module-font-light cor-pointer aks-records-border-bottom-" onclick="" style="padding:13px;animation:app__module 0.9s both ease-in-out 0.1s;box-shadow: var(--app-box-shadow);margin-top:2px;">
    <div class="w3-col s2">'.$value[1].'</div>
    <div class="w3-col s9">'.$value[2].'</div>
    <div class="w3-col s1">'.$value[3].'</div>
</div>';
}
$TB.='</div>';
// die($TB);
?>
<div class="cep__pageCount" data-titlename='{"titleName":"REFERENCE"}' style="width:100%;max-width:600px;margin:auto;height:100%;padding:12px;">
                <div style="width:300px;margin:auto;height:200px;padding:5px;">
                    <img src="assets/images/finish.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Registered courses</div>
                    <div><?=$TB?></div>
                    <!-- btn -->
                    <div class="w3-margin-top w3-center">
                                        <button id="prevBtnSend" title="Previous" onclick="Records.Printer.admitToday('idGet_ui','script/printers/slip.php?s_t='<?=$_->SqlSafe($_GET['rty'])?>'&separator='+12);" class="w3-button adm-dontclose1 w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                            <i id="NextBtn__pages__acad1" title="Next" class="mbri-print w3-large w3-display-middle" style="display:block;"></i>
                                                        <div id="showProgress__pages__acad1" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                            <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                            <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                            <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                            </div>
                                                        </div>
                                        </button>
                    </div>
                </div>
</div>