<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
?>
<div class="cep__pageCount" data-titlename='{"titleName":"REFERENCE"}' style="width:100%;max-width:400px;margin:auto;height:100%;padding:12px;">
                <div style="width:300px;margin:auto;height:200px;padding:5px;">
                    <img src="assets/images/finish.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Reference Numbers</div>
                    <form action="javascript:void(0)">
                        <div class="w3-row aks-records-inpelem-cnt aks-Records-module-font-light cor-pointer cor-margin-top aks-records-border-bottom-" onclick="CEP.Modules.verifyRef.verifyRefNumbers(9376456273,'17,300.00')" style="padding:13px;animation:app__module 0.9s both ease-in-out 0.1s;">
                            <div class="w3-col s6">9376456273~<span><?=date("d/m/Y");?></span></div>
                            <div class="w3-col s5"><span class="w3-text-green" style="font-size:0.75em;">NGR </span>17,300.00</div>
                            <div class="w3-col s1"><span class="w3-text-green fas fa-angle-right w3-right" style="font-size:0.75em;padding:5px 0;"></span></div>
                        </div>
                        <div class="w3-row aks-records-inpelem-cnt aks-Records-module-font-light cor-pointer cor-margin-top aks-records-border-bottom-" style="padding:13px;animation:app__module 0.9s both ease-in-out 0.1s;">
                            <div class="w3-col s6">9376456273~<span><?=date("d/m/Y");?></span></div>
                            <div class="w3-col s5"><span class="w3-text-green" style="font-size:0.75em;">NGR </span>17,300.00</div>
                            <div class="w3-col s1"><span class="w3-text-green fas fa-angle-right w3-right" style="font-size:0.75em;padding:5px 0;"></span></div>
                        </div>
                        <div class="w3-row aks-records-inpelem-cnt aks-Records-module-font-light cor-pointer cor-margin-top aks-records-border-bottom-" style="padding:13px;animation:app__module 0.9s both ease-in-out 0.1s;">
                            <div class="w3-col s6">9376456273~<span><?=date("d/m/Y");?></span></div>
                            <div class="w3-col s5"><span class="w3-text-green" style="font-size:0.75em;">NGR </span>17,300.00</div>
                            <div class="w3-col s1"><span class="w3-text-green fas fa-angle-right w3-right" style="font-size:0.75em;padding:5px 0;"></span></div>
                        </div>
                    </form><br>
                </div>
</div>