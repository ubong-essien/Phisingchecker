<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
// exam type
$rst = $_->Select("olevelexamtype_tb","*","1=1");
$xamType = '<option value="" disabled selected>Exam Type</option>';
if($rst[1] > 0){
    while($row = $rst[0]->fetch_assoc()){
        $xamType.='<option value="'.$row["ID"].'">'.strtoupper($row["Name"]).'</option>';
    }
}
// proposed program
$rstProg = $_->Select("programme_tb","*","1=1");
$proposedProg = '<option value="" disabled selected>Proposed Programme</option>';
if($rstProg[1] > 0){
    while($rowProg = $rstProg[0]->fetch_assoc()){
        $proposedProg.='<option value="'.$rowProg["ProgID"].'">'.strtoupper($rowProg["ProgName"]).'</option>';
    }
}
// olv subj
$rstOlv = $_->Select("olvlsubj_tb","*","1=1");
$olvelDetails = '<div><div class="w3-row w3-center cor-fadein-cnt cor-border-bottom cep-font-em cor-pointer" style="padding:6px;">
<div class="w3-col s12 aks-Records-btn-inner-txt cor-text1-shaow">OLEVEL SUBJECT</div>
</div>';
if($rstOlv[1] > 0){
    while($rowOlv = $rstOlv[0]->fetch_assoc()){
        $olvelDetails.='<div title="'.$rowOlv['SubName'].'" onclick="CEP.Modules.RegisterNow.computeOlvResult(\'first_'.$rowOlv['SubId'].'\',\'first_gradeHolder_'.$rowOlv['SubId'].'\',\''.$rowOlv['SubName'].'\')" id="first_'.$rowOlv['SubId'].'" class="w3-row adm-dontclose1 cor-fadein-cnt cep-hover-olv cor-border-bottom cor-pointer" style="padding:6px;font-size: 0.88em;">
            <div class="w3-col s10 " style="padding:3px 0;">'.$rowOlv['SubName'].'</div>
            <div class="w3-col s2"><div id="first_gradeHolder_'.$rowOlv['SubId'].'" class="cep-grdholder-cnt w3-center"></div></div>
        </div>';
    }
}
$olvelDetails.='</div>';
// olv subj2
$rstOlv2 = $_->Select("olvlsubj_tb","*","1=1");
$olvelDetails2 = '<div><div class="w3-row w3-center cor-fadein-cnt cor-border-bottom cep-font-em cor-pointer" style="padding:6px;">
<div class="w3-col s12 aks-Records-btn-inner-txt cor-text1-shaow">OLEVEL SUBJECT{<span class="w3-small">SECOND SITTING</span>}</div>
</div>';
if($rstOlv2[1] > 0){
    while($rowOlv2 = $rstOlv2[0]->fetch_assoc()){
        $olvelDetails2.='<div title="'.$rowOlv2['SubName'].'" id="seconSit_'.$rowOlv2['SubId'].'" onclick="CEP.Modules.RegisterNow.computeOlvResult2(\'seconSit_'.$rowOlv2['SubId'].'\',\'seconSit_gradeHolder_'.$rowOlv2['SubId'].'\',\''.$rowOlv2['SubName'].'\')" class="w3-row adm-dontclose1 cor-fadein-cnt cep-hover-olv cor-border-bottom cor-pointer" style="padding:6px;font-size: 0.88em;">
            <div class="w3-col s10" style="padding:3px 0;">'.$rowOlv2['SubName'].'</div>
            <div class="w3-col s2"><div id="seconSit_gradeHolder_'.$rowOlv2['SubId'].'" class="cep-grdholder-cnt w3-center"></div></div>
        </div>';
    }
}
$olvelDetails2.='</div>';
// olv grade
$rstOlvGrade = $_->Select("olvlgrade_tb","*","1=1");
$outP = '<div><div class=" w3-center cor-fadein-cnt cep-font-em" style="padding:6px;">
<div class=" cor-border-bottom aks-Records-btn-inner-txt cep-font-em cor-text1-shaow" >OLEVEL GRADE</div>
</div>';
$outP.='<div class="w3-row-padding aks-records-color">';
if($rstOlvGrade[1] > 0){
    $cnt = 1;
    while($rowGrade = $rstOlvGrade[0]->fetch_assoc()){
        $outP.='<div id="grd_'.$rowGrade['ID'].'" class="w3-col s4"><div title="'.$rowGrade['Grade'].'" onclick="CEP.Modules.RegisterNow.computeGrade(\'grd_'.$rowGrade['ID'].'\',\''.$rowGrade['Grade'].'\')" class="w3-teal cor-pointer w3-display-container" style="width:25px;height:25px;margin:auto;border-radius:50%;padding:2px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);"><span class="w3-display-middle w3-small ">'.$rowGrade['Grade'].'</span></div></div>';
        if($cnt == 3){
            $outP.='</div>';
            $cnt = 0;
            $outP.= '<div class="w3-row-padding cor-margin-top aks-records-color">';
        }
        $cnt++;
    }
} 
$outP.='</div></div>';
// olv grade 2
$rstOlvGrade2 = $_->Select("olvlgrade_tb","*","1=1");
$outP2 = '<div><div class=" w3-center cor-fadein-cnt cep-font-em" style="padding:6px;">
<div class=" cor-border-bottom aks-Records-btn-inner-txt cep-font-em cor-text1-shaow" >OLEVEL GRADE</div>
</div>';
$outP2.='<div class="w3-row-padding aks-records-color">';
if($rstOlvGrade2[1] > 0){
    $cnt2 = 1;
    while($rowGrade2 = $rstOlvGrade2[0]->fetch_assoc()){
        $outP2.='<div id="grd2_'.$rowGrade2['ID'].'" class="w3-col s4"><div title="'.$rowGrade2['Grade'].'" onclick="CEP.Modules.RegisterNow.computeGrade2(\'grd2_'.$rowGrade2['ID'].'\',\''.$rowGrade2['Grade'].'\')" class="w3-teal cor-pointer w3-display-container" style="width:25px;height:25px;margin:auto;border-radius:50%;padding:2px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);"><span class="w3-display-middle w3-small ">'.$rowGrade2['Grade'].'</span></div></div>';
        if($cnt2 == 3){
            $outP2.='</div>';
            $cnt2 = 0;
            $outP2.= '<div class="w3-row-padding cor-margin-top aks-records-color">';
        }
        $cnt2++;
    }
} 
$outP2.='</div></div>';
?>
<div class="cep__pageCount" data-titlename='{"titleName":"ACADEMIC DETAILS"}' style="width:100%;max-width:550px;margin:auto;height:100%;padding:12px;position:relative;">
                <div style="width:300px;margin:auto;height:200px;padding:20px;">
                    <img src="assets/images/result.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Academic details</div>
                    <form action="javascript:void(0)" onsubmit="CEP.Modules.RegisterNow.basicAcademicDetails('Working','processacademic')">
                        <div class="w3-row-padding">
                            <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;width:calc( 100% - 15px )!important;margin:auto;">
                                    <select required id="cep__proposed__prog" class="cep-font-1em adm-dontclose1 cep-hover-olv" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <?=$proposedProg?>
                                    </select>
                                </div>
                        </div>
                        <div class="w3-row-padding">
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select required class="adm-dontclose1" id="cep__examType1" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <?=$xamType?>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select required class="adm-dontclose1" id="cep__examsYear1" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <option value="" disabled selected>Exam Year</option>
                                        <?=$_->selectYear();?>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Othernames" id="cep__examsNumber" required type="text" class="w3-input adm-dontclose1 det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#eee!important;" placeholder="Exam Number">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:0px;min-height:200px;overflow:auto;color:#aaa;">
                                    <?=$olvelDetails?>
                                </div>
                                <div class="w3-row w3-center cep-hover-olv cor-pointer cor-fadein-cnt aks-records-inpelem-cnt cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:10px 3px;color:#aaa;position:relative;height:120px;">
                                    <input type="file" required id="file_firstsitting" title="CHOOSE COVER IMAGE" onchange="__I.P_review_imageMainFUNCT('pas_port_pre_acad',event)" accept="image/png, image/gif, image/jpeg" class="" style="position: absolute;opacity:0;z-index:3;cursor:pointer!important;left:0;top:0;width:100%;height:100%;">
                                    <div class="w3-col s10 w3-small adm-dontclose1 aks-Records-btn-inner-txt">UPLOAD SCANNED RESULT</div>
                                    <div class="w3-col s2"><span title="Attach" class="mbri-paperclip w3-large"></span></div>
                                    <div style="max-height:80px;margin-top:25px;">
                                    <img id="pas_port_pre_acad" class="w3-round" width="100%" style="max-height:80px;">
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select id="cep__examType2" class="adm-dontclose1" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <?=$xamType?>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select class="adm-dontclose1" id="cep__examsYear2" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <option value="" disabled selected>Exam Year{Second Sitting}</option>
                                        <?=$_->selectYear();?>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Othernames" id="cep__examsNumber2" type="text" class="w3-input adm-dontclose1 det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#eee!important;" placeholder="Exams Number{Second Sittings}">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:0px;min-height:200px;overflow:auto;color:#aaa;">
                                    <?=$olvelDetails2?>
                                </div>
                                <div class="w3-row w3-center cep-hover-olv cor-pointer cor-fadein-cnt aks-records-inpelem-cnt cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:10px 3px;color:#aaa;position:relative;height:120px;">
                                    <input type="file" id="file_secondsitting" title="CHOOSE COVER IMAGE" onchange="__I.P_review_imageMainFUNCT('pas_port_pre_acad__',event)" accept="image/png, image/gif, image/jpeg" class="" style="position: absolute;opacity:0;z-index:3;cursor:pointer!important;left:0;top:0;width:100%;height:100%;">
                                    <div class="w3-col s10 w3-small adm-dontclose1 aks-Records-btn-inner-txt">UPLOAD SCANNED RESULT</div>
                                    <div class="w3-col s2"><span title="Attach" class="mbri-paperclip w3-large"></span></div>
                                    <div style="max-height:80px;margin-top:25px;">
                                    <img id="pas_port_pre_acad__" width="100%" class="w3-round" style="max-height:80px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- btn -->
                        <div class="w3-margin-top w3-center">
                            <button id="prevBtnSend" title="Previous" class="w3-button adm-dontclose1 w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__pages__acad" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__pages__acad" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
                </div>

<!-- olevel popup -->
<div id="getTop" style="position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:20;display:none;">
        <div class="w3-row aks-records-inpelem-cnt cep-grad-smal-cnt cor-border-left cor-border-top cor-border-right aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;max-width:150px;height:180px;">
            <div title="Close" class="adm-smr-bgr" onclick="CEP.Engine.exitOlvWindow('getTop');" style="position:absolute;top:-6px;right:-12px;width:18px;height:18px;padding:12px;border-radius:50%;background-color: black;z-index:2;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow7);">
                <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#FFF;z-index:20;">
                    <i class="fas fa-times w3-small w3-display-middle"></i>
                </div>
            </div>
            <div>
                <?=$outP?>
            </div>
        </div>
</div>
<!-- olevel 2nd sititng popup -->
<div id="getTop2" style="position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:20;display:none;">
        <div class="w3-row aks-records-inpelem-cnt cep-grad-smal-cnt cor-border-left cor-border-top cor-border-right aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;max-width:150px;height:180px;">
            <div title="Close" class="adm-smr-bgr" onclick="CEP.Engine.exitOlvWindow('getTop2');" style="position:absolute;top:-6px;right:-12px;width:18px;height:18px;padding:12px;border-radius:50%;background-color: black;z-index:2;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow7);">
                <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#FFF;z-index:20;">
                    <i class="fas fa-times w3-small w3-display-middle"></i>
                </div>
            </div>
            <div>
                <?=$outP2?>
            </div>
        </div>
</div>
</div>