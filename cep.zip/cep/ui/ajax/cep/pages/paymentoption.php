<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
$mofEntry = explode("_",$getJsonFile->cep__ModeOfEntry);
$mofEntry = $mofEntry[1]==1?"TOP-UP":"PART-TIME";
?>
<div id="getAllBody" class="cep__pageCount" data-titlename='{"titleName":"MAKE PAYMENT"}' style="width:100%;margin:auto;height:100%;padding:20px;overflow:auto;">
    <div style="width:300px;margin:auto;height:220px;padding:20px;">
        <img src="assets/images/p2.png" alt="photo" width="100%" height="100%">
    </div>
    <div id="payInfo" class="w3-animate-opacity" style="width:70%;margin:auto;height:calc( 100% - 220px );padding:5px;">
        <div id="getheaderDesc" class="w3-center cep-font-1em">Confirm payment(<?=$mofEntry?>)</div>
        <div class="w3-row">
            <div id="getClickEvt" onclick="CEP.Modules.RegisterNow.processPayment('Submiting','processpay')"  class="w3-row w3-margin cor-pointer aks-app-color w3-center">
                        <div class="aks-racords-pay__pay w3-round w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.2s;">
                            <div class="w3-display-middle" style="min-width:100%;">
                                <div style="font-size: 1.31em;color: #aaa;font-weight:100;">PAY</div>
                                <div class="aks-Records-btn-inner-txt" style="font-size: 1.3em;"><span class="w3-small w3-text-green">NGR</span> <?=$getJsonFile->otherParam?></div>
                            </div>
                        </div>
            </div>
        </div>
    </div>
</div>
