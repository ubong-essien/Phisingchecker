<div class="cep__pageCount" data-titlename='{"titleName":"BASIC DETAILS"}' style="width:100%;max-width:500px;margin:auto;height:100%;padding:12px;">
                <div style="width:300px;margin:auto;height:200px;padding:20px;">
                    <img src="assets/images/basic5.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Basic details</div>
                    <form action="javascript:void(0)" onsubmit="CEP.Modules.RegisterNow.basicDetails('Submiting','processpayment')">
                        <div class="w3-row-padding">
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Surname" id="cep__surnm" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Surname">
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter First Name" id="cep__firstnm" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Firstname">
                                </div>
                            </div>
                        </div>
                        <div class="w3-row-padding">
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Othernames" id="cep__othernm" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Othernames">
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select required id="cep__gendr" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <option value="" disabled selected>Gender</option>
                                        <option value="M">Male</option>
                                        <option value="F">Female</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <!-- btn -->
                        <div class="w3-margin-top w3-center">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__pages__2" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__pages__2" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
                </div>
</div>