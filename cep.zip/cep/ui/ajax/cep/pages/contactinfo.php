<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
$rst = $_->Select("state_tb","*","1=1");
$TB = '<option value="" disabled selected>State</option>';
if($rst[1] > 0){
    while($row = $rst[0]->fetch_assoc()){
        $TB.='<option value="'.$row["StateID"].'">'.$row["StateName"].'</option>';
    }
}
?>
<div class="cep__pageCount" data-titlename='{"titleName":"CONTACT INFORMATION"}' style="width:100%;max-width:800px;margin:auto;height:100%;padding:12px;">
                <div style="width:300px;margin:auto;height:200px;padding:5px;">
                    <img src="assets/images/contactinfo.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Contact Information</div>
                    <form action="javascript:void(0)" onsubmit="CEP.Modules.RegisterNow.contactInformation('Submiting...','procescontactinof')">
                        <div class="w3-row-padding">
                            <div class="w3-col m4">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:1;animation: slidToup17 1s ease-in-out 0.224s both;padding:3px 0;height:315px!important;padding:12px;position:relative;">
                                    <div class="aks-records-inpelem-cnt-  w3-round" style="opacity:1;animation: slidToup11 1s ease-in-out 0.65s both;width:100%;height:100%;">
                                            <div class="cor-csvs-circle " style="width:100%!important;height:100%!important;">
                                                <img id="pas_port_pre" src="assets/images/chatbox.jpg" alt="" width="100%" height="100%">
                                                <input type="file" required id="file_15" title="CHOOSE COVER IMAGE" onchange="__I.P_review_imageMainFUNCT('pas_port_pre',event)" accept="image/png, image/gif, image/jpeg" class="" style="position: absolute;opacity:0;z-index:3;cursor:pointer!important;left:0;top:0;width:100%;height:100%;">
                                                <div class="w3-display-middle w3-center">
                                                    <div><i class="fas fa-camera w3-text-red w3-xxlarge cor-pointer"></i></div>
                                                    <strong class="cor-text1-shaow"><small>Chose Passport</small></strong>
                                                </div>
                                            </div>
                                            <strong class="cor-text1-shaow">&nbsp;</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col m4">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter DOB" id="cep__dob" required type="date" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;" placeholder="DOB">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Permanent Home Address" id="cep__homeaddress" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Permanent Home Address">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select required id="cep__maritsts__page3" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <option value="" disabled selected>Marital Status</option>
                                        <option value="Single">Single</option>
                                        <option value="Married">Married</option>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Spouse Name" id="cep__spouseName" type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Spouse Name">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Sponsor's Phone number" id="cep__phoneno" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Phone number">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Email" id="cep__email" required type="email" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Email">
                                </div>
                            </div>
                            <div class="w3-col m4">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select required id="cep__nationality" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <option value="" disabled selected>Nationality</option>
                                        <option value="M">Nigeria</option>
                                        <option value="F">Non-Nigeria</option>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select required onchange="CEP.Modules.RegisterNow.loadLGA()" id="cep__statID" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <?=$TB?>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <select required id="cep__lga" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#aaa!important;width:100%;height:100%;">
                                        <option value="" disabled selected>LGA</option>
                                    </select>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Sponsor's Name" id="cep__sponsorName" type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Sponsor's Name">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Sponsor's Address" id="cep__sponsorAddress" type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Sponsor's Address">
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;padding:3px 0;">
                                    <input title="Enter Sponsor's Phone number" id="cep__sponsorphonumber" type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Sponsor's Phone number">
                                </div>
                            </div>
                        </div>
                        <!-- btn -->
                        <div class="w3-margin-top w3-center">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__pages__3" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__pages__3" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
                </div>
</div>