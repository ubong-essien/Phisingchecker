<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
$moe = $getJsonFile->jsonParam->moe==1?"TOP-UP":"PART-TIME";
$gender = $getJsonFile->jsonParam->Gender=="M"?"MALE":"FEMALE";
?>
<div class="cep__pageCount" data-titlename='{"titleName":"REGISTRATION COMPLETED"}' style="width:100%;max-width:550px;margin:auto;height:100%;padding:12px;">
                <div style="width:300px;margin:auto;height:200px;padding:5px;">
                    <img src="assets/images/finish.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Registration Completed</div>
                    <form action="javascript:void(0)" onsubmit="CEP.Modules.RegisterNow.genRegSlip('<?=$getJsonFile->cep__phone__?>')">
                        <div class="w3-row-padding">
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:1;animation: slidToup17 1s ease-in-out 0.224s both;padding:3px 0;height:207px!important;padding:12px;position:relative;">
                                    <div class="aks-records-inpelem-cnt-  w3-round" style="opacity:1;animation: slidToup11 1s ease-in-out 0.65s both;width:100%;height:100%;">
                                            <div class="cor-csvs-circle " style="width:100%!important;height:100%!important;">
                                                <img id="pas_port_pre_" src="<?=$getJsonFile->jsonParam->passport?>" alt="" width="100%" height="100%">
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12" id="cep__getFulName"><?=$getJsonFile->jsonParam->Name?></div>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12" id="cep__moe"><?=$moe?></div>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12" id="cep__proposedProg"><?=$getJsonFile->jsonParam->Programme?></div>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12" id="cep__gender"><?=$gender?></div>
                                </div>
                            </div>
                        </div>
                        <!-- btn -->
                        <div class="w3-margin-top w3-center">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__pages__3" title="Next" class="mbri-print w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__pages__3" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
                </div>
</div>
