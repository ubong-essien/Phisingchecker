<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
?>
<div class="cep__pageCount" data-titlename='{"titleName":"BIODATA FORM"}' style="width:100%;max-width:450px;margin:auto;height:100%;padding:12px;">
                <div style="width:300px;margin:auto;height:200px;padding:5px;">
                    <img src="assets/images/bioreg.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 200px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">Biodata Registration</div>
                    <form action="javascript:void(0)" onsubmit="CEP.Modules.RegisterNow.biodataFormReg('Biodata')">
                        <div class="w3-row-padding">
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;">
            
                                        <input title="Enter Next of kin name" id="cep__name__bioda" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Next of kin name">
                                    
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;">
            
                                        <input title="Enter Next of kin phone number" id="cep__phone__biodata" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Next of kin phone no">
                                    
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;">
            
                                        <input title="Enter Next of kin phone number" id="cep__address__nok" required type="text" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Next of kin address">
                                    
                                </div>
                        </div>
                        <!-- btn -->
                        <div class="w3-margin-top w3-center">
                            <button id="prevBtnSend" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__pages__formbio" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__pages__formbio" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
                    </form>
                </div>
</div>
