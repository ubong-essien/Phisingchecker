<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
try {
    $TB ='<div class="cep__pageCount" data-titlename=\'{"titleName":"'.$getJsonFile->menuHeaderTitle.'"}\' style="width:100%;margin:auto;height:100%;overflow:auto;">';
    $TB.='<div style="max-width:300px;margin:auto;height:200px;padding:20px;">
        <img src="assets/images/verifyp.png" alt="photo" width="100%" height="100%">
    </div>';
        $cnt = 1;
        $TB.='<div id="payInfo" class="w3-animate-opacity" style="width:100%;max-width:400px;margin:auto;height:calc( 100% - 200px );"><div id="getheaderDesc" class="w3-center cep-font-1em">'.$getJsonFile->subDescr.'</div><div style="padding:5px;">';
        $TB.='
        <form action="javascript:void(0)" onsubmit="CEP.Modules.verifyRef.verifyNumbers(\'Submitting\',\'processor\')">
        <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom " style="opacity:0;animation: slidToup1 1s ease-in-out 0.224s both;">
            
                <input title="Phone Number" id="cep__phone__ref" required type="text" oninput="__I.onInputUppc(\'cep__phone__ref\');" class="w3-input det__nat__adres aks-records-heart-beat adm-input-jm putme-card" autofocus value style oninput min max step style="background-color:var(--app-dark-mode-gray-90)!important;border:none!important;outline:0!important;color:#FFF!important;" placeholder="Enter reg number or payment ref">
            
        </div>
        <div class="w3-margin-top w3-center">
                            <button id="prevBtnSend__ref" title="Previous" class="w3-button w3-margin-bottom  cor-fadein-cnt cor-play-heart-beat aks-records-color aks-records-chos-bgr w3-circle w3-display-container" style="width:60px;margin:auto;height:60px;box-shadow: 0 1px 4px rgb(0 0 0 / 60%);">
                                <i id="NextBtn__" title="Next" class="fas fa-check w3-large w3-display-middle" style="display:block;"></i>
                                            <div id="showProgress__ref" class="cor-row w3-display-middle" style="display:none;min-width:35px;">
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anione"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anitwo"></div></div>
                                                <div class="cor-column" style="width:33.33333%"><div class="aks-cbt-progres aks-cbt-progres-anithree"></div> 
                                                </div>
                                            </div>
                            </button>
                        </div>
        </form>
    ';
        $TB.='</div></div>';
    $TB.='</div>';
    die(json_encode(["SUCCESS" => ["Message" => $TB]]));
}catch(Exception $e) {
    json_encode(["ERROR" => ["Message" => "S01"]]);
}
?>