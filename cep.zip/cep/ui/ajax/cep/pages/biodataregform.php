<?php
require_once "../../../../engine/Robot.php";
$getJsonFile = json_decode($_POST['data']);
$moe = $getJsonFile->jsonParam->moe==1?"TOP-UP":"PART-TIME";
$gender = $getJsonFile->jsonParam->Gender=="M"?"MALE":"FEMALE";
?>
<div class="cep__pageCount" data-titlename='{"titleName":"PRINT BIODATA"}' style="width:100%;max-width:550px;margin:auto;height:100%;padding:12px;">
                <div style="width:250px;margin:auto;height:120px;padding:5px;">
                    <img src="assets/images/congr.png" alt="photo" width="100%" height="100%">
                </div>
                <div id="payInfo" class="w3-animate-opacity" style="width:100%;height:calc( 100% - 120px );">
                    <div id="getheaderDesc" class="w3-center cep-font-1em">PRINT BIODAT FORM</div>
                    <form action="javascript:void(0)">
                        <div class="w3-row-padding">
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt aks-records-border-bottom cor-margin-top" style="opacity:1;animation: slidToup17 1s ease-in-out 0.224s both;padding:3px 0;height:261px!important;padding:12px;position:relative;">
                                    <div class="aks-records-inpelem-cnt-  w3-round" style="opacity:1;animation: slidToup11 1s ease-in-out 0.65s both;width:100%;height:100%;">
                                            <div class="cor-csvs-circle " style="width:100%!important;height:100%!important;">
                                                <img id="pas_port_pre_" src="<?=$getJsonFile->jsonParam->passport?>" alt="" width="100%" height="100%">
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w3-col m6">
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12 w3-center">CONGRATULATIONS</div>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12"><?=$getJsonFile->jsonParam->Name?></div>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12"><?=$moe?></div>
                                </div>
                                <div class="w3-row aks-records-inpelem-cnt cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12"><?=$getJsonFile->jsonParam->Programme?></div>
                                </div>
                                <div onclick="//CEP.Modules.RegisterNow.processBiodataPayment('Submitting',<?=$getJsonFile->jsonParam->moe?>)" class="w3-row aks-records-chos-bgr w3-margin-bottom aks-records-inpelem-cnt cor-pointer w3-center cor-margin-top w3-small aks-records-border-bottom-" style="padding:12px;animation:app__module 0.9s both ease-in-out 0.1s;">
                                    <div class="w3-col s12 aks-Records-btn-inner-txt" title="Pay your acceptance fee">PRINT BIODATA FORM</div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
</div>
