<?php
 require_once "engine/Robot.php";  
 // setting up the system
 $rst = $_->Select("appsetting_tb","*","Active = 1");
 if($rst[1] > 0){
	 $rowSetting = $rst[0]->fetch_assoc();
	 $_SESSION['LoginCompanyName'] = $rowSetting['LoginCompanyName'];
	 $_SESSION['LoginAppImage'] = $rowSetting['LoginAppImage'];
 }else{die('No set up menu');}
?>
<div id="logOutR" class=" putme-loginPage-cont-log">
	<div class="cep-login" style="background-color: rgb(0, 0, 0);background-color: rgba(0, 0, 0,0.8);width:100%;height:100%;overflow:hidden;position:relative;">
		<!-- logo -->
		<div class="cep-login-minlogo-center w3-center w3-text-white">
			<div class="w3-row" style="position:relative;width:100%;">
					<div style="width: 118px;height: 118px;margin:auto;">
					 	<img class="w3-center" src="assets/images/chlogo.png" alt="" width="100%" height="100%">
					</div>
					<div class="cep-logo-smr-ind" style="font-size: 2em;font-weight: bold;">AKSU-CONTINUING EDUCATION PORTAL</div>
					<div class="aks-Records-font aks-Records-btn-inner-txt cep-logo-smr-ind-sm">AKWA IBOM STATE UNIVERSITY</div>
					<!-- <div class="aks-Records-font-14">CONTINUEING EDUCATION PROGRAMME</div> -->
			</div>
		</div>
		<!-- middle -->
		<div></div>
 		<!-- bottom left -->
		 <div class="cep-login-bottom-cnt cep-smr-manip-">
			<div class="cep-login-minlogo w3-blue- cor-border">
				<div class="w3-row">
					<div class="w3-col s6">
						<div class="w3-row" onclick='CEP.Modules.Stabilizer.controller({"menuHeaderTitle":"Register Now","url":"loadregistration"})'>
							<div class="w3-col s3">
								<div class="cep-inner-pad cor-pointer-">
									<div class="cep-icon-indic tel-blocks-td-bg-color w3-display-container">
										<!-- <i class="fas fa-user w3-display-middle "></i> -->
										<span class="mbri-users w3-xlarge w3-display-middle"></span>
									</div>
								</div>
							</div>
							<div class="w3-col s9">
								<div class="cep-reg-now">
									<div class=" aks-Records-module-font cep-outer-padding" style="padding: 12px 0;"><span class="cep-reg-now-iner cep-inner-padding cor-border cor-pointer cep-inner-font-size" style="padding:12px;font-size: 1.3em;font-weight: bold;">REGISTER NOW</span></div>
								</div>
							</div>
						</div>
					</div>
					<div class="w3-col s6">
						<div class="w3-row" onclick="CEP.Modules.LoginHere.accessPoint();">
							<div class="w3-col s3">
								<div class="cep-inner-pad cor-pointer-">
									<div class="cep-icon-indic tel-cell-block-gradient-red w3-display-container">
										<i class="mbri-lock w3-xlarge w3-display-middle "></i>
									</div>
								</div>
							</div>
							<div class="w3-col s9">
								<div class="cep-reg-now">
									<div class=" aks-Records-module-font cep-outer-padding" style="padding: 12px 0;"><span class="cep-reg-now-iner cep-inner-padding cor-border cor-pointer cep-inner-font-size" style="padding:12px;font-size: 1.3em;font-weight: bold;">LOGIN HERE</span></div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		 </div>
		 <!-- bottom right info -->
		 <div class="cep-login-info-not">
		 	<div class="cep-log-info-inner cor-border">
			 	<i class=" w3-display-middle w3-text-white" style="font-weight:900;">i</i>
			</div>
		 </div>
	</div>
</div>
<script>
	 if(__I.Cooky.useCookie('getUserName__') != undefined && __I.Cooky.useCookie('getUserName__') != "</br>"){
		_('u_user_name').innerText = __I.Cooky.useCookie('getUserName__').toUpperCase() == "ARRAY"?"":__I.Cooky.useCookie('getUserName__').toUpperCase();
	 }
</script>