<?php
    require_once "engine/Robot.php";    
?>
<div class="adm-dontclose1 cor-fadein-cnt aks-Records-all-width aks-main-body-border-left aks-Records-color" style="background-color:rgba(0,0,0,0.1)">
    <div id="removeLoginPage" class="aks-Records-all-width w3-display-container" style="padding:0px!important;overflow:auto;">
        <i class="fas fa-cog fa-spin w3-large w3-display-middle" style="display:block;"></i>
    </div>
</div>