<?php
$appNma = explode('~', $_SESSION['appName']);
?>
<div class="come-in-lefttxt-topp aks-Records-all-width cor-border-bottom adm-dontclose1">
    <div class="w3-row" style="overflow:hidden;width:100%;height:100%;">
        <div class="w3-col s3">
            <div class="w3-row aks-pad-smr" style="padding:1px;">
                <div class="w3-col s12">
                    <img src="assets/images/<?=$_SESSION['appImage']?>" alt="photo" class="w3-hide-small w3-hide-medium" width="30" height="30" style="border-radius:0%;">
                    <span class="aks-Records-btn-inner-txt xxx aks-Records-module-font-12 w3-hide-small w3-hide-medium"><?=$appNma[0]?>-<span id="getModuleNam" style="font-size:11px;"></span></span>
                    <span onclick="Records.APP.TopBar2.minimize()" class="fas fa-bars cor-fadein-cnt w3-large cor-text1-shaow w3-hide-large"></span>
                </div>
            </div>
        </div>
        <div class="w3-col s5" style="padding:1px;box-sizing:border-box;">
           <!-- search -->
        </div>
        <div class="w3-col s4">
            <div class="w3-row">
                <div class="w3-col s3">
                    <div class="w3-hide-small w3-hide-medium w3-row" style="padding:8px;">
                        <div onclick="Telemedicine.exitApp()" title="Logout" class="w3-col s4 cor-pointer"><i class="fas fa-home aks-Records-heart-beat"></i></div>
                        <!-- <div title="Contact Us" class="w3-col s4 cor-pointer"><i class="fas fa-phone adm-font-rot-97 "></i></div> -->
                        <div onclick="__I.toggleFullScreen();" title="Full Screen" class="w3-col s4 cor-pointer"><i class="fas fa-arrows-alt-v aks-Records-heart-beat" style="transform: rotate(45deg)"></i></div>
                    </div>
                </div>
                <div class="w3-col s9"> 
                    <span class="w3-text-red"></span>
                    <div title="Logout" onclick="Telemedicine.exitApp()" class="w3-right" style="padding:8px;"><i class="fas fa-power-off aks-Records-heart-beat cor-fadein-cnt cor-pointer"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- AK17/NAS/GEY/041 -->