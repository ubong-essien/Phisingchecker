<?php
    require_once "engine/Robot.php";    
?>
<div class="adm-dontclose1 come-in-txt-right cor-fadein-cnt aks-Records-all-width cor-border-right cor-border-top cor-border-bottom" style="padding:0px;background-color:var(--app-black-alpha-60);">
   <div class="aks-record-righ-nv" style="padding:4px;box-shadow:0 3px 6px rgb(0 0 0 / 16%), 0 3px 6px rgb(0 0 0 / 23%);background-color: var(--app-black-alpha-50);">
       <div style="width:100%;height:calc( 100% - 5px );">
            <div class="w3-row ">
				<div class="w3-col s3">
					<div title="Back To Inbox" onclick="Records.APP.RightBar.remoteController('0','panel1');" class="aks-app-topnv__nav  cor-pointer w3-display-container">
						<i class="fas fa-align-center cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s3">
                    <div title="Back To Inbox" onclick="Records.APP.RightBar.remoteController('1','panel2');" class="aks-app-topnv__nav  cor-pointer w3-display-container">
						<i class="fas fa-images cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s3">
                    <div title="Back To Inbox" onclick="Records.APP.RightBar.remoteController('2','panel3');" class="aks-app-topnv__nav  cor-pointer w3-display-container">
						<i class="fas fa-cog cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s3">
                    <div title="Back To Inbox" onclick="Records.APP.RightBar.remoteController('3','panel4');" class="cor-pointer aks-app-topnv__nav" style="padding:2px;">
						<div id="getTheuseracutn" style="width:100%;height:100%;border-radius:50%;"></div>
					</div>
				</div>
			</div>
        </div>
       <div style="width:100%;height:5px;padding:2px;">
            <div id="rtg_pr" class=" cor-fadein-cnt" style="width:6px;height:6px;border-radius:50%;margin-left:30px;background-color:rgba(210, 20, 172, 1);"></div>
        </div>
   </div>
   <div class="aks-record-righ-nv-body">
       <!-- panel 1 -->
       <div id="panel1" class="panels__ w3-animate-opacity">
           <div class="aks-Records-all-width w3-text-white" style="padding:5px;">
                <!-- date and time -->
                <div class="aks-racords__rightnav__time">
                    <div class="cor-border-bottom" style="width:100%;height:30px;border-left:1px solid rgb(27, 230, 219);padding: 5px 10px;">
                        <span class=" aks-Records-color aks-Records-font-9 cor-box-shadow1 aks-Records-btn-inner-txt">DATE AND TIME</span>
                    </div>
                    <div style="width:100%;height:calc( 100% - 30px - 1px);padding:10px 30px;">
                        <span class=" aks-Records-color aks-Records-font-size-lg aks-Records-btn-inner-txt "><?=date("d F, Y")?></span> <span id="runTyme" class=" aks-Records-color aks-Records-font-size-lg aks-Records-btn-inner-txt "><i class="fas fa-cog fa-spin w3-small"></i></span>
                    </div>
                    <div style="width:100%;height:1px;display:flex;">
                        <div style="width:25%;height:inherit;background-color:rgb(233, 54, 84);"></div>
                        <div style="width:25%;height:inherit;background-color:rgb(233, 206, 54);"></div>
                        <div style="width:25%;height:inherit;background-color:rgb(98, 150, 15);"></div>
                        <div style="width:25%;height:inherit;background-color:rgb(20, 172, 164);"></div>
                    </div>
                </div>
                <!-- others -->
                <div class="aks-racords__rightnav__time w3-margin-top">
                    <div class="cor-border-bottom" style="width:100%;height:30px;border-left:1px solid rgb(27, 230, 219);padding: 5px 10px;">
                        <div class="aks-Records-module-font-12 cor-box-shadow1 cv2-txt-font-size"><small>TOTAL CANDIDATE</small>   (<strong><span id="getTextn1" class="tem-brac-col cor-text1-shaow">0</span></strong>)</div>
                    </div>
                    <div style="width:100%;height:calc( 100% - 30px );padding:5px 5px;">
                            <div id="getTotalC1" class="cor-text1-shaow w3-center">0</div>
                            <div class="cv2-progres-bars-cnt">
                                <div id="getIntWidth1" class="cor-text-col-bgr cv2-intrnal-border"></div>
                            </div>
                    </div>
                </div>
                <div class="aks-racords__rightnav__time  w3-margin-top">
                    <div class="cor-border-bottom" style="width:100%;height:30px;border-left:1px solid yellow;padding: 5px 10px;">
                        <div class="cor-text1-shaow aks-Records-module-font-12 cv2-txt-font-size"><small>TOTAL DIRECT ENTRY CANDIDATE</small> (<strong><span id="getdeTextn1" class="tem-brac-col cor-text1-shaow">0</span></strong>)</div>
                    </div>
                    <div class="w3-center" style="width:100%;height:calc( 100% - 30px );padding:5px 5px;">
                        <div id="TNumber1">0</div>
                            <div class="cv2-progres-bars-cnt">
                                <div id="getTDEC1" class="cor-text-col-bgr cv2-intrnal-border"></div>
                            </div>
                    </div>
                </div>
                <div class="w3-row w3-margin-top">
                    <div class="w3-col m6">
                        <div class="aks-Records__rt__" style="border-bottom:1px solid teal;">
                            <div class="cor-border-bottom" style="width:100%;height:30px;border-left:1px solid rgb(27, 230, 219);padding: 5px 10px;">
                                <div class="cor-text1-shaow  aks-Records-module-font-12"><small>ADMITTED(<strong><span id="getAddTextnR1" class="tem-brac-col cor-text1-shaow">0</span></strong>)</small></div>
                            </div>
                            <div class="w3-center" style="width:100%;height:calc( 100% - 30px );padding:2px;">
                                <div class="" id="shwReGPrinting">
                                    <div class="couxnterx1" style="position: relative; width:100px;margin:auto;height:89px">
                                        <canvas id="counterx1" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
                                        <canvas id="counter_bgx1" width = "100" height = "89"></canvas>
                                    </div>
                                </div>
                                <i onclick="GEN.Admin.Printers.admitToday('idGet_ui','script/printers/printDESlip.php?pr_id=15')" class="fas fa-print w3-small cor-margin-top cv2-hover-col cor-fadein-cnt"></i>
                            </div>
                        </div>
                    </div>
                    <div class="w3-col m6">
                        <div class="aks-Records__rt__ w3-right">
                            <div class="cor-border-bottom" style="width:100%;height:30px;border-left:1px solid brown;padding: 5px 10px;">
                                <div  class="cor-text1-shaow aks-Records-module-font-12"><small>NOT-ADMITTED(<strong><span id="getNotaAddTextnRx1" class="tem-brac-col cor-text1-shaow">0</span></strong>) </small></div>
                            </div>
                            <div class="w3-center" style="width:100%;height:calc( 100% - 30px );padding:2px;border-bottom:1px solid purple;">
                                <div class="" id="shwReGPrinting1x1">
                                    <div class="counterx1" style="position: relative; width:100px;margin:auto;height:89px">
                                        <canvas id="counter1x1" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
                                        <canvas id="counter1_bgx1" width = "100" height = "89"></canvas>
                                    </div>
                                </div>
                                <i onclick="GEN.Admin.Printers.admitToday('idGet_ui','script/printers/printDESlip.php?pr_id=16')" class="fas fa-print w3-small cor-margin-top cv2-hover-col cor-fadein-cnt"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- others -->
                <div class="w3-row w3-margin-top">
                    <div class="w3-col m6">
                        <div class="aks-Records__rt__">
                            <div class="cor-border-bottom" style="width:100%;height:30px;border-left:1px solid indigo;padding: 5px 10px;">
                                <div class="cor-text1-shaow aks-Records-module-font-12"><small>ADMISSIBLE(<strong><span id="getAddTextn" class="tem-brac-col cor-text1-shaow">0</span></strong>) </small></div>
                            </div>
                            <div class="w3-center" style="width:100%;height:calc( 100% - 30px );padding:2px;border-bottom:1px solid rgb(98, 150, 15);">
                                <div class="" id="shwReGPrinting12x1">
                                    <div class="couxnter123x1" style="position: relative; width:100px;margin:auto;height:89px">
                                        <canvas id="counter123x1" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
                                        <canvas id="counter123_bgx1" width = "100" height = "89"></canvas>
                                    </div>
                                </div>
                                <i onclick="GEN.Admin.Printers.admitToday('idGet_ui','script/printers/printDESlip.php?pr_id=22')" class="fas fa-print w3-small cor-margin-top cv2-hover-col cor-fadein-cnt"></i>
                            </div>
                        </div>
                    </div>
                    <div class="w3-col m6">
                        <div class="aks-Records__rt__ w3-right">
                            <div class="cor-border-bottom" style="width:100%;height:30px;border-left:1px solid blue;padding: 5px 10px;">
                                <div class="cor-text1-shaow aks-Records-module-font-12"><small>NOT-ADMISSIBLE(<strong><span id="getNotaAddTextnx1" class="tem-brac-col cor-text1-shaow">0</span></strong>)</small></div>
                            </div>
                            <div class="w3-center" style="width:100%;height:calc( 100% - 30px );padding:2px;border-bottom:1px solid rgb(233, 206, 54);">
                                <div class="" id="shwReGPrinting13x1">
                                    <div class="counter1234x1" style="position: relative; width:100px;margin:auto;height:89px">
                                        <canvas id="counter12345x1" style="position: absolute;z-index:2" width = "100" height = "89"></canvas>
                                        <canvas id="counter12345_bgx1" width = "100" height = "89"></canvas>
                                    </div>
                                </div>
                                <i onclick="GEN.Admin.Printers.admitToday('idGet_ui','script/printers/printDESlip.php?pr_id=70')" class="fas fa-print w3-small cor-margin-top cv2-hover-col cor-fadein-cnt"></i>
                            </div>
                        </div>
                    </div>
                </div>
           </div>
       </div>
       <!-- panel 2 -->
       <div id="panel2" class="panels__ cor-fadein-cnt" style="display:none;">Panel 2</div>
       <!-- panel 3 -->
       <div id="panel3" class="panels__ cor-fadein-cnt aks-Records-color w3-animate-opacity" style="display:none;">
       <div class="cv2-wdhd-cnt" style="padding: 0.1625em;">
                    <div class="w3-row cor-border-bottom w3-center">
                        <!-- <div class="cor-text1-shaow cv2-txt-font-size ">Personal Information</div> -->
                        <div class=" cv2-txt-font-size"><small><i>Update your name, phon numbers and email address</i></small></div>
                    </div>
                    <div class="w3-row">
                        <div class="w3-col s11">
                            <div class=""><strong><small>Name</small></strong></div>
                            <div class=""><small><i id="getFNm">Enefiok Duke</i></small></div>
                        </div>
                        <div class="w3-col s1" style="padding: 8px;">
                            <i class="fas fa-angle-right cor-pointer w3-large"></i>
                        </div>
                    </div>
                    <div class="w3-row cor-border-top">
                        <div class="w3-col s11">
                            <div class=""><strong><small>Contact Info</small></strong></div>
                            <div class=""><small><i>Manage your phone numbers and emals</i></small></div>
                        </div>
                        <div class="w3-col s1" style="padding: 8px;">
                            <i class="fas fa-angle-right cor-pointer w3-large"></i>
                        </div>
                    </div>
                    <div class="w3-row  cor-border-top w3-center">
                        <!-- <div class=" cv2-txt-font-size">Security and login</div> -->
                        <!-- <div class=" cv2-txt-font-size"><small><i>Change your password and take other actions </i></small></div> -->
                    </div>
                    <div class="w3-row">
                        <div class="w3-col s11">
                            <div class=""><strong><small>Change Password</small></strong></div>
                            <div class=""><small><i>It's a good idea to use strong password</i></small></div>
                        </div>
                        <div class="w3-col s1" style="padding: 8px;">
                            <i class="fas fa-angle-right cor-pointer w3-large"></i>
                        </div>
                    </div>
                </div>
        </div>
       <!-- panel 4 -->
       <div id="panel4" class="panels__ cor-fadein-cnt" style="display:none;">Panel 4</div>
   </div>
</div>