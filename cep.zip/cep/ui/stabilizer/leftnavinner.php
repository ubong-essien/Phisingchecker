<div id="hideThisL" class="adm-dontclose1 come-in-left cor-fadein-cnt aks-Records-all-width   aks-Records-pop-cnt-bgr-leftnav" style="padding:0.125em;box-shadow:var(--app-box-shadow-low);overflow:var(--app-auto);">
	<?php
	// sleep(1);
	require_once "../../engine/Robot.php";
	$privilege = json_decode($_POST['data']);
	$rst = $_->Select("appmenus_tb",'*',"Active = 1 AND ModuleID = ".trim($_->SqlSafe($privilege->moduleID))."");
	if($rst[1] > 0){
		$cnt = 1;
		$cnt1 = 0;
		$TB = '';
		$iniBgr = "";
		$iniBgrInCo = "";
		$countMenus = 1;
		//border-top-right-radius: 25px;border-bottom-right-radius: Records.APP.LeftBar.loadAjax 25px SubURL;
			$holdTNum = '';
			while($row = $rst[0]->fetch_assoc()){
				if($cnt1 == 0){$iniBgr = "aks-Records-module-bg-";$iniBgrInCo = "aks-txt-app-inner-discor-";}else{$iniBgr = "";$iniBgrInCo = "";}
				$holdTNum = $holdTNum==0?'':$holdTNum;
				$TB.='<div class="w3-row aks-Records-color" style="width:100%;">
							<div class="w3-col s12">
								<div title="'.$row['Title'].'" id="tr_'.$row['ID'].'" onclick="'.$row['JsFunction'].'(\'tr_'.$row['ID'].'\',\''.$row['MsgBoxDescr'].'\',\''.$row['Url'].'\',\'fixClor_'.$row['ID'].'\',\''.$row['Privilege'].'\')" class="w3-row adm__  cor-fadein-cnt aks-btn-width-height '.$iniBgr.'  cor-pointer aks-Records-order-hover-cnt aks-app-hover-xx" style="padding:5px;margin-top:5px;">
									<div class="w3-col s3">
										<div class="aks-app-ordering-cnt-border">
											<div class="aks-app-ordering-cnt aks-Records-heart-beat-inner cor-fadein-cnt '.$row['Color'].' w3-display-container">
												<i class="'.$row['Icon'].' w3-display-middle "></i>
											</div>
										</div>
									</div>
									<div class="w3-col s9">
										<div style="margin-top:2px;">
											<div class="w3-row">
												<div class="w3-col s10">
													<div class="aks-Records-btn-inner-txt- cor-text1-shaow xxx aks-Records-module-font-12">'.$row['Name'].'</div>
												</div>
												<div class="w3-col s2 w3-small">'.$holdTNum.'</div>
											</div>
											<div id="fixClor_'.$row['ID'].'" class="w3-small '.$iniBgrInCo.' aks-Records-color cor-text1-shaow xxyy  aks-font-hova cor-fadein-cnt">'.$row['Namedescrip'].'</div>
										</div>
									</div>
								</div>
							</div></div>';
				$cnt1++;
				$countMenus++;
				$holdTNum = '';
			}
		echo $TB;
	}else{
		die(json_encode(["SUCCESS" => ["Message" => "INVALID PARAMETER SUPPLIED"]]));
	}

	function computeNum($modeID){
		global $_;
		$rst = $_->Select("applications_tb","ID","$modeID");
		return $rst[1];
	}
?>
</div>