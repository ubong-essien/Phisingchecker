<?php
 require_once "engine/Robot.php";
//  $rst = $_->Select("applications_tb",'*',"Status = 1");
//     $TB = '';
//     if($rst[1] > 0){
// 		$num_rows_todisply = 15;//this is the number of rows to display
// 		$off_set_value =  (1 - 1) * ((int)$num_rows_todisply);
// 		$TB = '1 - '.$num_rows_todisply.' of '.$rst[1].'';
//     }
//     $TB = '';
?>
<div id="hideThisL" class="adm-dontclose1 cor-fadein-cnt aks-Records-all-width stp-border aks-Records-pop-cnt-bgr" style="padding:0.125em;box-shadow:var(--app-box-shadow-low);">
	<!-- CHAT ICT -->
	<div class="w3-row cor-border-bottom aks-app-cnt-smr" style="width:var(--app-width);height:40px;padding:0.25em;position:relative;background-color:#2d2d2d!important;box-shadow:0 2px 5px 0 rgb(0 0 0 / 16%), 0 2px 10px 0 rgb(0 0 0 / 12%);">
		<div class="w3-col l3 s6 m6">
			<div class="w3-row ">
				<div class="w3-col s2">
					<div title="Back To Home" onclick="Telemedicine.Stabilizer.backToHomePage('backToHomePage');" class="aks-app-topnv2 x__x__x aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
						<i class="fas fa-long-arrow-alt-left cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s2 w3-hide-small w3-hide-medium">
					<div title="Check Mails" class="aks-app-topnv2 aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
						<i class="fas fa-envelope w3-display-middle cor-fadein-cnt aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s2">
					<div onclick="Records.APP.TopBar2.refreshPage();" title="Refresh" class="aks-app-topnv2 w3-hide-small w3-hide-medium aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
						<i class="fas fa-redo-alt  cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s2">
					<!-- <div title="Add User" class="aks-app-topnv2 aks-app-smr-mar-left aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
						<i class="fas fa-user-plus cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div> -->
				</div>
				<div class="w3-col s2">
					<div title="Delete" onclick="Records.APP.TopBar2.disableRecords()" class="aks-app-topnv2 w3-hide x__x__x w3-hide-small w3-hide-medium aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
						<i class="fas fa-trash  cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s2">
					<div title="Archive" class="aks-app-topnv2 w3-hide-small w3-hide x__x__x w3-hide-medium aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
						<i class="fas fa-archive cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
			</div>
		</div>
		<div class="w3-col l5 s3 m3">
			<div class="w3-row">
				<div class="w3-col s10">
					<div title="Home" onclick="Telemedicine.Stabilizer.backToHomePage('backToHomePage');" class="aks-app-topnv2 aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
						<i class="fas fa-home  cor-fadein-cnt w3-display-middle aks-Records-color"></i>
					</div>
				</div>
				<div class="w3-col s2">
					<div class="cor-row ">
						<div class="cor-column" style="width:60%">
							<div style="width:100%;height:20px;position:relative;margin-top:5px;border-top-left-radius:20px;border-bottom-left-radius:20px;padding:0;" class="aks-app-left-blu w3-center aks-Records-color cor-border-top cor-border-left cor-border-bottom aks-app-adj-smr"><div class="aks-Records-btn-inner-txt aks-Records-font-11" style="position:absolute;top:0;left:10px;z-index:1;">1000</div></div>
						</div>
						<div class="cor-column" style="width:40%">
							<div class="aks-app-topnav-cnt-bel aks-app-topnv2 aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
								<i class="fas fa-bell cor-fadein-cnt w3-display-middle aks-Records-color"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="w3-col l4 s3 m3">
			<div class="w3-row">
				<div class="w3-col s2">
					&nbsp;
				</div>
				<div class="w3-col s1">
					&nbsp;
				</div>
				<div class="w3-col s7">
					<div id="getVisibility" class="w3-row aks-Records-color aks-Records-module-font-12" style="visibility:hidden;">
						<div class="w3-col s6">
							<input id="getTval" type="hidden" value="">
							<input id="getToDisply" type="hidden" value="">
							<div class="w3-hide-large">&nbsp;</div>
							<div id="getFrntEn" class="w3-right w3-hide-small w3-hide-medium" style="padding:5px;"></div>
						</div>
						<div class="w3-col s6">
							<div class="w3-row-padding">
								<div class="w3-col s6">
									<div title="Previous" onclick="Records.Engine.incrementMode(-1)" class="aks-app-topnv2 aks-app-transion-prop aks-Records-heart-beat w3-hide-small w3-hide-medium cor-pointer w3-display-container" style="border:none;">
										<i class="fas fa-angle-left w3-large w3-hide  cor-fadein-cnt w3-display-middle aks-Records-color"></i>
									</div>
								</div>
								<div class="w3-col s6">
									<div id="next___" title="Next" onclick="Records.Engine.incrementMode(1)" class="aks-app-topnv2 aks-app-transion-prop aks-Records-heart-beat w3-hide-small w3-hide-medium cor-pointer w3-display-container" style="border:none;">
										<i class="fas fa-angle-right w3-large w3-hide cor-fadein-cnt w3-display-middle aks-Records-color"></i>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="w3-col s2">
					<div class="w3-right" style="padding:0 0;margin-left:100px;">
						<div title="Lock Screen" class="aks-Records__smr__marleft aks-app-lock aks-app-topnv2 aks-app-transion-prop aks-Records-heart-beat cor-pointer w3-display-container">
							<i class="fas fa-lock  cor-fadein-cnt w3-display-middle aks-Records-color"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="cor-border-top1" style="width:var(--app-width);height:calc( 100% - 40px );">
		<div class="aks-Records-all-width cor-row">
			<div id="appSideNav" class="cor-column come-in-left-slow0 aks-app-leftnav-width-smr w3-hide-small w3-hide-medium cor-fadein-cnt" style="width:25%;height:100%;">
                <?php //require_once "leftnavinner.php";?>
            </div>
            <div class="cor-column cor-fadein-cnt aks-app-leftnav-width-smr-main" style="width:75%;height:100%;">
                <?php require_once "rightnavinner.php";?>
            </div>
		</div>
	</div>
</div>