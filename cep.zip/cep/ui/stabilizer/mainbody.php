<?php
    // require_once "engine/Robot.php";  
    // $rst = $_->Select("mainmenu_tb","*","Active = 1");  
    // $outP = '';
    // if($rst[1] > 0){
    //     while($row = $rst[0]->fetch_assoc()){
    //         $outP.=$row['Submenu'];;
    //     }
    // }else{die('No set up menu');} 
?>
<div class="aks-app-all-main-cnt w3-animate-opacity cor-fadein-cnt adm-dontclose1">
    <!--left nav-->
    <div class=" aks-app-topnav-cnt w3-card-4">
        <?php require_once "topnav.php";?>
    </div>
    <!-- concept height 10px -->
    <div class=" aks-app-topnav-cnt-1 w3-hide-small w3-hide-medium"></div>
     <!-- main-body -->
    <div class=" aks-app-main-cnt ">
        <div class="aks-Records-all-width cor-row">
            <div class="cor-column aks-app-cnt-smr" style="width:80%;height:100%;">
                <?php require_once "leftnav.php";?>
            </div>
            <div class="cor-column " style="width:20%;height:100%;">
                <?php require_once "rightnav.php";?>
            </div>
        </div>
    </div>
</div>