<div id="idGet_ui" class="stp-border spt-bigBox-cont2 w3-animate-zoom" style="display:none;">
    <div class="cor-border-bottom " style="height:30px;background-color: rgba(0, 0, 0,0.4);"><div class="w3-right w3-text-white "><button onclick="Records.Printer.closeWindow('idGet_ui','1')"  class="w3-button w3-small" style="padding:8.5px 13px;margin-right:1px;"><i class="fa fa-window-minimize"></i></button><button onclick="__I.toggleFullScreen()"  class="w3-button w3-small" style="padding:8.5px 13px;margin-right:1px;"><i class="fa fa-window-maximize"></i></button><button onclick="Records.Printer.closeWindow('idGet_ui','0')"  class="w3-button w3-small w3-red" style="padding:8.5px 13px;"><i class="fas fa-times"></i></button></div></div>
    <div class="w3-display-container w3-black" style="height:calc( 100% - 30px );">
        <i id="cogRoll" class="fas fa-spinner fa-pulse w3-text-indigo w3-xxlarge w3-text-white w3-display-middle" style="display:none;"></i>
        <div  class="w3-text-white" id="" style="height:100%;overflow-y:auto;overflow-x:hidden;">
            <iframe id="getPDFFile" src="" frameborder="0" style="width: 100%;height:100%;"></iframe>
        </div>
     </div>
</div>