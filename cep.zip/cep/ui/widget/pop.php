
<div id="sideNav_id__" class="spt-bigBox-cont-transp app-smr-padding adm-dontclose1 kab-adm-height" style="display: none;">
    <div class="cor-fadein-cnt app-smr-cnt kab-adm-height" style="position:absolute;left:50%;top:17%;transform:translate(-50%,-17%);width:100%;max-width:530px;background-color:var(--app-box-shadow-high);height:100%;max-height:660px;">
        <div class="" style="position: relative;width:100%;height:100%;padding:0;">
			<div style="position: relative;width:100%;height:100%;margin:auto;box-shadow:var(--app-box-shadow)">
                <div title="Close" class="adm-smr-bgr" onclick="Records.Engine.exitWindow('sideNav_id__');" style="position:absolute;top:2px;right:2px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 0.3);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow);">
                    <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                        <i class="fas fa-times w3-small w3-display-middle"></i>
                    </div>
                </div>
                <div class=" aks-app-color cor-border-bottom" style="width:100%;height:31px;padding:10px;box-shadow: var(--app-box-shadow-low);background-color: #444;">
                    <div id="holdHeader" class="aks-Records-font-14 aks-Records-btn-inner-txt cor-text1-shaow"></div>
                </div>
                <div class=" aks-app-topnav-cnt-1 cor-border-bottom" style="height:8px;"></div>
                <div class="w3-row w3-display-container w3-text-white" style="width:100%;height:calc( 100% - 31px - 8px );position:relative;background-color:#222;">
                    <div id="inerCntMotr" style="width:100%;height:calc( 100% );overflow:auto;">
                        <i class="fas fa-cog fa-spin w3-display-middle"></i>
                    </div>
                </div>
            </div>
		</div>
    </div>	
</div>

<!-- iphone users instructions -->
<div id="installContainerApple" class="spt-bigBox-cont-installer" style="display:none;">
    <div class="w3-display-container" style="width:100%;height:100%;">
        <div class="w3-display-middle w3-text-white w3-center w3-round" style="width:100%;max-width:300px;height:390px;background-color:#222;box-shadow: var(--app-box-shadow);position:relative;">
        <!-- close -->
			<div title="Close" class="adm-smr-bgr- aks-smr-clo-btn-" onclick="Records.Engine.exitWindow('installContainerApple');" style="position:absolute;top:-14px;right:-11px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 0.3);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow);">
            <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                <i class="fas fa-times w3-small w3-display-middle"></i>
            </div>
            </div>
            <div class="w3-row-padding" style="width:100%;height:120px;padding:30px 10px;">
                <div class=" w3-display-container"><div class="cor-border" style="width:70px;margin:auto;height:70px;border-radius:50%;"><i class="fab fa-apple w3-large w3-display-middle"></i></div></div>
                <!-- <i class="fa-brands fa-apple"></i> -->
            </div>
            <div class="w3-display-container aks-Records-module-font-light" style="width:100%;height:calc( 100% - 120px );">
                <div style="text-align:left;padding:20px;">
                    Welcome to AKSU Admission Installer<br>
                    This instruction is only for iphone users<br>
                    <div>> Using safari browser only</div>
                    <div>> Tap on the options icon</div>
                    <div>> Tap add to home screen</div>
                    <div>> Tap add</div>
                    <div>> Go to your home screen, and open the app</div>
                </div>
                <div class="w3-margin-top">
					<i class="fab fa-apple w3-xxlarge"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- cep -->
<div id="sideNav_id" class="spt-bigBox-cont aks-sen-smr-padding adm-dontclose1 kab-adm-height" style="display: none;">
    <div class="cor-fadein-cnt kab-adm-height vik-sen-plan-smr " style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:100%;max-width:950px;height:100%;max-height:550px;z-index:101;">
        <div class="aks-sen-smr-padding vik-popup-cnt- vik-animate-zoom " style="position: relative;width:100%;height:100%;">
			<div style="position: relative;width:100%;height:100%;margin:auto;box-shadow:var(--app-box-shadow)">
                <div title="Close" class="adm-smr-bgr" onclick="CEP.Engine.exitWindow('sideNav_id');" style="position:absolute;top:11px;right:4px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 0.3);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow);">
                    <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                        <i class="fas fa-times w3-small w3-display-middle"></i>
                    </div>
                </div>
                <div title="Lock" class="adm-smr-bgr" onclick="//CEP.Engine.exitWindow('sideNav_id');" style="position:absolute;top:11px;right:35px;width:25px;height:25px;padding:12px;z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;">
                    <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                        <i class="fas fa-lock w3-small w3-display-middle"></i>
                    </div>
                </div>
                <div class=" aks-app-color cor-border-bottom" style="width:100%;min-height:45px;padding:15px;background-color: #444; border-radius: 4px 4px 0px 0px;box-shadow: 0 2px 5px 0 rgb(0 0 0 / 16%), 0 2px 10px 0 rgb(0 0 0 / 12%);overflow: hidden;border-bottom:1px solid yellow">
                    <div class="aks-Records-font-14 aks-Records-btn-inner-txt cor-text1-shaow" style="display:flex;color:#fff;">
						<div id="holdPreviousIcon"></div>
                        <div class="">
                            <span id="holdHeader" class="vik-fontsize-txt-head-biger"></span>
                            <!-- <span class="fas fa-angle-double-right vik-Records-btn-inner-txt"></span> -->
                            <span id="holdHeader__inner" class="cep-fontsize-txt-head w3-animate-zoom"></span>
                        </div>
					</div>
                </div>
                <div class="w3-row w3-display-container w3-text-white" style="width:100%;height:calc( 100% - 40px - 34px);position:relative;padding:10px;background-color: #1c1a1a;">
                    <i id="hideMePls" class="fas fa-cog fa-spin w3-display-middle"></i>
                    <div id="inerCntMot" class="cep-pop-container w3-card adm-dontclose1" style="width:100%;height:calc( 100% );overflow:auto;background-color:#222;padding:5px;"></div>
                </div>
                <!-- bottom -->
                <div title="Close" class="adm-smr-bgr" onclick="//Records.Engine.exitWindow('sideNav_id');" style="display:flex;width:100%;height:35px;padding:4px 40px;background-color: #2d2d2d;box-shadow: 0 2px 5px 0 rgb(0 0 0 / 16%), 0 2px 10px 0 rgb(0 0 0 / 12%);overflow: hidden;">
					<!-- <div title="Close" class="adm-smr-bgr" onclick="CEP.Engine.exitWindow('sideNav_idcep');" style="position:absolute;bottom:-7px;right:4px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 0.3);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow);">
						<div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
							<i class="fas fa-power-off w3-small w3-display-middle"></i>
						</div>
					</div> -->
                </div>
				<!-- <div title="Close" class="adm-smr-bgr" onclick="CEP.Engine.exitWindow('sideNav_idcep');" style="position:absolute;bottom:0px;right:4px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 0.3);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;box-shadow:var(--app-box-shadow);">
                    <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                        <i class="fas fa-times w3-small w3-display-middle"></i>
                    </div>
                </div> -->
            </div>
		</div>
    </div>	
</div>
<!-- options -->
<div id="sideNav_idcep" class="spt-bigBox-cont-Spln-what adm-dontclose1" style="display: none;padding:10px;">
    <div class="cor-fadein-cnt" style="position:absolute;left:50%;top:40%;transform:translate(-50%,-40%);width:100%;max-width:350px;">
        <div class="" style="position: relative;width:100%;height:100%;padding:5px;">
			<div class="w3-round" style="position: relative;max-width:350px;height:220px;margin:auto;background-color:#222;box-shadow:var(--app-box-shadow)">
                <div title="Close" onclick="Records.Engine.exitWindow('sideNav_idcep');" style="position:absolute;top:-15px;right:-9px;width:25px;height:25px;padding:12px;border-radius:50%;background-color: rgba(255, 255, 255, 0.3);z-index:100;cursor:pointer;animation: projectUp 0.8s forwards ease-in-out 0.3s;">
                    <div class="w3-display-container" style="position:relative;width:100%;height:100%;color:#fff;">
                        <i class="fas fa-times w3-small w3-display-middle"></i>
                    </div>
                </div>
                <div class="cor-border-bottom aks-app-color" style="width:100%;height:55px;padding:10px;">
                    <div class="aks-records-module-font-12 aks-records-btn-inner-txt ">AMOUNT PAYABLE</div>
                    <div class="aks-records-module-font-12 aks-records-btn-inner-txt ">
                        <small class="w3-text-green w3-small">NGR</small> <span id="getAmtPayAble" class="aks-records-module-font aks-records-btn-inner-txt">15,700.00</span>
                    </div>
                </div>
                <div class="w3-row" style="width:100%;height:calc( 100% - 55px );padding:20px;">
                    <div id="getClickEvt__" class="w3-col s6 cor-pointer aks-app-color w3-center">
                        <div class="aks-racords-pay__ w3-round w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.1s;">
                            <i class="fas fa-credit-card w3-display-middle w3-xxlarge"></i>
                        </div>
                        <div class="aks-records-module-font-12 aks-records-btn-inner-txt">CARD</div>
                        <div class="aks-records-font-07 aks-records-btn-inner-txt">Pay via ATM Card</div>
                    </div>
                    <div id="getCliBankRep__" class="w3-col s6 cor-pointer aks-app-color w3-center">
                        <div class="aks-racords-pay__ w3-round w3-display-container" style="animation: projectUp 0.8s forwards ease-in-out 0.2s;">
                            <i class="fas fa-university w3-display-middle w3-xxlarge"></i>
                        </div>
                        <div class="aks-records-module-font-12 aks-records-btn-inner-txt">BANK</div>
                        <div class="aks-records-font-07 aks-records-btn-inner-txt">Pay via Bank</div>
                    </div>
                </div>
            </div>
		</div>
    </div>	
</div>
<!-- log me in cnt -->
<div id="sideNav_idcep____" class="spt-bigBox-cont-Spln-what adm-dontclose1" style="display: none;padding:10px;">
    <div class="cor-fadein-cnt" style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:700px;height:400px;">
        <div class=" w3-round-xxlarge" style="position: relative;width:100%;height:100%;padding:5px;background-color:#222;">
            <!-- image design 4px 4px 75% 10%-->
            login-in
            <div class="cep-projct-out-cnt" style="position:absolute;right:0;top:0;bottom:0;width:260px;background-color:rgb(131,187,48);border-radius: 0 32px 32px 0;box-shadow: var(--app-box-shadow-low);background-image:url('assets/images/login.png');background-repeat:no-repeat;background-size:cover;background-position:center;background-attachment:fixed;"></div>
        </div>
    </div>
</div>
<!-- log in -->
<div id="exitSubLogin__" class=" putme-loginPage-cont-log" style="display:none;">
	<div style="background-color: rgb(0, 0, 0);background-color: rgba(0, 0, 0,0.8);width:100%;height:100%;overflow:hidden;position:relative;">
		<!-- body -->
		<div class="cor-row">
			<div id="doorleft" class="cor-column-2c-lg come-in-left-slow" style="height: 100vh;background-image:url('assets/images/img300.jpg');background-repeat:no-repeat;background-size:cover;background-position:center;background-attachment:fixed;"></div>
			<div id="doorright" class="cor-column-2c-lg come-in-txt-right" style="height: 100vh;background-image:url('assets/images/img300.jpg');background-repeat:no-repeat;background-size:cover;background-position:center;background-attachment:fixed;"></div>
		</div>
		<div class="w3-center app-login-page">
			<div class="come-in-lefttxt-topp">
				<div id="rmovBgr" class="w3-display-container cor-mx-heit" style="max-width: 265px;margin:auto;height:265px;border-radius:50%;box-shadow: 0 2px 5px 0 rgb(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0,0,0,0.12); border: rgba(255,255,255,.09) thin solid;background-image:url('assets/images/<?=$_SESSION['LoginAppImage']?>');background-repeat:no-repeat;background-size:cover;background-position:center;">
					<img id="getUserPast" src="" width="100%" height="100%" alt="" style="border-radius:50%;display:none;margin-top:-1px;">
					<i id="getAt" class="fas fa-at- w3-display-middle kab-adm-font-colr-sm-wrdnews cor-text1-shaow w3-text-white" style="font-size: 7.5em;"></i>
				</div>
				<div id="" class="w3-text-white cor-text1-shaow aks-Records-module-font-12">WELCOME <span id="u_user_name">TO AKSU ADMISSION PORTAL</span></div>
			</div>
			<div>
				<form action="javascript:void(0)">
					<div class="cor-row kab-smr-idealgas-midd-prod">
						<div id="getPaswrdVer">
							<div class="come-in-left-slow" style="position: relative;z-index:1;"><div onclick="window.location='index.php';" title="RELOAD" class="cor-column w3-display-container cor-text-col-bgr- w3-pink cor-text1-shaow " style="width:10%;height:30px;border:none;outline:none;border-top-left-radius:5px;cursor:pointer;"><i class="fas fa-redo-alt w3-display-middle w3-small"></i></div>
							<div class="cor-column" style="width:80%;">
								<div style="width: 100%;"><input id="getUserN" class="w3-round" type="text" placeholder="Email" style="width: 98%;margin:auto;height:30px;border:none;outline:none;"></div>
							</div>
							<div onclick="Telemedicine.Login.verifyUrN()" title="SUBMIT" class="cor-column cor-text-col-bgr- w3-pink w3-display-container" style="width:10%;height:30px;border:none;outline:none;border-top-right-radius:5px;cursor:pointer;">
								<div id="showHC" class="w3-display-middle"><i class="fa fa-angle-right cor-text1-shaow "></i></div>
								<div id="hideCSpn" class="w3-display-middle" style="display: none;"><i class="fa fa-cog fa-spin cor-text1-shaow " ></i></div>
							</div></div>
							<div class="come-in-txt-right">
								<button onclick="Telemedicine.Login.verifyUrN();//__I.LoginDoorOpen('doorleft','doorright','exitSubLogin')" title="SUBMIT" class="w3-button cor-text-col-bgr- w3-pink cor-text1-shaow" style="width: 100%;padding:5px;margin-top:1.5px;border-bottom-right-radius:5px;border-bottom-left-radius:5px;"><small>SUBMIT</small></button>
							</div>
						</div>
						<div class="w3-text-white w3-margin-top"><a href="#"><small>Forgot Password?</small></a></div><br><br>
					</div>
				</form>
			</div>
			
		</div>
		<div style="position:absolute;left:50%;bottom:2%;transform:translate(-50%,-2%);">
			<div>
				<a href="javascript:Telemedicine.Login.applePhoneUsers()" title="For apple users, click here to learn how to install this application on your iphone!" class="w3-text-yellow aks-Records-font-14-light" style="text-decoration:none;"><i class="fab fa-apple w3-xlarge"></i> For apple users, click here!</a>
			</div><br><br><br><br>
			<div class="w3-text-white w3-center  cor-text1-shaow"><small><i class="fas fa-copyright w3-large spt-header-smr "></i><strong><?=$_SESSION['LoginCompanyName']?>-<?=date('Y')?></strong></small></div>
		</div>
	</div>
</div>