<div id="backToHomePage" class="cor-container-bg-black mva-zoom-bgimg0">
        <div class="aks-Records-all-width " style="padding:10px;background-color:var(--app-black-alpha-80);">
            <div class="aks-app-cnt-inner adm-dontclose1">
                <?php require_once "ui/stabilizer/mainbody.php";?>
            </div>
        </div>
</div>