<div class="aks-Records-all-width " style="padding:50px;background-color:var(--app-black-alpha-80);">
    <div class="aks-app-cnt-inner adm-dontclose1">
         <?php require_once "ui/body/mainbody.php";?>
    </div>
</div>
<div id="exitMenus" style="display: none;"><?php require_once "ui/widget/menus.php";?></div>